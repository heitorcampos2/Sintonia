import { api } from '../api.js';
import { openPlayer } from '../player.js';
import { S } from '../state.js';
import { btn, clear, confirmBox, empty, fmtBytes, fmtDate, h, iconBtn, pic, toast } from '../ui.js';
import { sectionHeader } from './common.js';

const STATUS = {
  queued: 'Na fila', downloading: 'Baixando', recording: 'Gravando', done: 'Concluído',
  error: 'Falhou', canceled: 'Cancelado',
};

export function render(root) {
  let tab = sessionStorage.getItem('sintonia.offTab') || 'download';
  let items = [];
  let timer = null;
  const seg = h('div.seg');
  const list = h('div.off-list');
  root.append(sectionHeader('Offline'), h('div.view-body', seg, list));

  function drawTabs() {
    clear(seg);
    [['download', 'Downloads'], ['rec', 'Gravações']].forEach(([id, label]) => {
      const n = items.filter((x) => x.type === id && ['downloading', 'recording', 'queued'].includes(x.status)).length;
      seg.append(h('button', { type: 'button', class: tab === id ? 'on' : '', onclick: () => { tab = id; sessionStorage.setItem('sintonia.offTab', id); draw(); } },
        label, n ? h('span.badge', String(n)) : null));
    });
  }

  function draw() {
    drawTabs();
    clear(list);
    const mine = items.filter((x) => x.type === tab);
    if (!mine.length) {
      list.append(tab === 'download'
        ? empty('Seus downloads aparecem aqui', 'Abra um filme ou episódio e toque em baixar. O arquivo fica salvo no aparelho onde o Sintonia roda.')
        : empty('Suas gravações aparecem aqui', 'No player de um canal ao vivo, toque em Gravar.'));
      return;
    }
    mine.forEach((it) => list.append(card(it)));
  }

  function card(it) {
    const active = ['downloading', 'recording', 'queued'].includes(it.status);
    const pct = it.total ? Math.min(100, (it.done / it.total) * 100) : 0;
    let detail = STATUS[it.status] || it.status;
    if (it.status === 'downloading') detail += it.total ? ` · ${Math.round(pct)}% de ${fmtBytes(it.total)}` : ` · ${fmtBytes(it.done)}`;
    else if (it.status === 'recording') {
      detail += ` · ${fmtBytes(it.done)}`;
      if (it.endsAt) detail += ` · termina às ${new Date(it.endsAt * 1000).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
    } else if (it.status === 'done') detail += ` · ${fmtBytes(it.done)} · ${fmtDate(it.finished || it.created)}`;
    else if (it.status === 'error') detail += it.error ? ` · ${it.error}` : '';
    if (it.status === 'done' && !it.exists) detail = 'Arquivo não encontrado (foi movido ou apagado)';
    const actions = h('div.off-act');
    if (it.status === 'done' && it.exists) {
      actions.append(btn('Assistir', { cls: 'primary sm', icon: 'play', onclick: () => openPlayer({ kind: 'file', item: { id: it.id, name: it.name }, file: it }) }));
      actions.append(iconBtn('download', 'Salvar neste aparelho', () => { const a = h('a', { href: `/files/${it.id}?dl=1`, download: '' }); document.body.append(a); a.click(); a.remove(); }));
    }
    if (active) actions.append(btn(it.type === 'rec' ? 'Parar' : 'Cancelar', { cls: 'ghost sm', icon: 'stop', onclick: async () => { await api.post(`/api/downloads/${it.id}/stop`); refresh(); } }));
    if (it.status === 'error' || it.status === 'canceled') actions.append(btn('Tentar de novo', { cls: 'ghost sm', icon: 'refresh', onclick: async () => { await api.post(`/api/downloads/${it.id}/retry`); refresh(); } }));
    if (!active) actions.append(iconBtn('trash', 'Apagar', async () => {
      if (!(await confirmBox(`Apagar "${it.name}"${it.exists ? ' e o arquivo salvo' : ''}?`, { ok: 'Apagar', danger: true }))) return;
      await api.del(`/api/downloads/${it.id}`);
      toast('Apagado');
      refresh();
    }));
    return h('div.off-card', { class: it.status },
      pic(it.img, it.name, 'off-pic'),
      h('div.off-main',
        h('strong', it.name),
        h('small', { class: it.status === 'error' ? 'err' : '' }, detail),
        active || it.status === 'downloading' ? h('div.bar.off-bar', { class: it.status === 'recording' || !it.total ? 'indet' : '' }, h('i', { style: { width: pct + '%' } })) : null,
        it.file ? h('small.path', it.file) : null),
      actions);
  }

  async function refresh() {
    try { items = await api.get('/api/downloads'); } catch { return; }
    items = items.filter((x) => !x.src || S.sources.some((s) => s.id === x.src) || x.status === 'done');
    draw();
    clearTimeout(timer);
    if (items.some((x) => ['downloading', 'recording', 'queued'].includes(x.status))) timer = setTimeout(refresh, 1500);
  }
  refresh();
  return () => clearTimeout(timer);
}
