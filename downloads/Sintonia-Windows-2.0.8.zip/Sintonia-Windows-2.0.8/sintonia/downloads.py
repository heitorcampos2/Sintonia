"""Downloads de filmes/episódios e gravação de canais ao vivo."""

import os
import re
import threading
import time
import urllib.parse
import uuid
from pathlib import Path

from . import net
from .store import JsonStore

CHUNK = 256 * 1024
MAX_PARALLEL = 2


def safe_name(name, default="video"):
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', " ", name or "").strip(" .")
    name = re.sub(r"\s+", " ", name)
    return (name or default)[:120]


def _attrs(line):
    return dict(re.findall(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', line))


class Job:
    def __init__(self):
        self.stop = threading.Event()


class DownloadManager:
    def __init__(self, data_dir, resolver, settings_getter):
        self.store = JsonStore(Path(data_dir) / "downloads.json", {"items": []})
        self.resolver = resolver
        self.settings = settings_getter
        self.jobs = {}
        self.lock = threading.RLock()
        self.sem = threading.Semaphore(MAX_PARALLEL)
        changed = False
        for it in self.store.data["items"]:
            if it["status"] in ("downloading", "queued", "recording"):
                it["status"] = "error"
                it["error"] = "Interrompido quando o Sintonia foi fechado"
                changed = True
        if changed:
            self.store.save()

    # --- pastas ---------------------------------------------------------------
    def _folder(self, rec):
        from .config import default_media_dir
        s = self.settings()
        if rec:
            d = s.get("recordDir") or os.path.join(default_media_dir(), "Gravações")
        else:
            d = s.get("downloadDir") or default_media_dir()
        Path(d).mkdir(parents=True, exist_ok=True)
        return Path(d)

    # --- consulta ---------------------------------------------------------------
    def list(self):
        with self.lock:
            out = []
            for it in self.store.data["items"]:
                d = dict(it)
                d.pop("ref", None)
                d["exists"] = bool(it.get("file")) and os.path.exists(it["file"])
                out.append(d)
            return out

    def get(self, job_id):
        for it in self.store.data["items"]:
            if it["id"] == job_id:
                return it
        return None

    def _set(self, job_id, **fields):
        with self.lock:
            it = self.get(job_id)
            if it:
                it.update(fields)
                if fields.get("status") in ("done", "error", "canceled", "recording", "downloading"):
                    self.store.save()

    # --- ações -----------------------------------------------------------------
    def add(self, src_id, kind, ref, meta, record_minutes=None):
        rec = kind == "live"
        job_id = uuid.uuid4().hex[:10]
        item = {
            "id": job_id, "type": "rec" if rec else "download", "src": src_id, "kind": kind,
            "itemId": ref.get("id"), "name": meta.get("name") or "Sem título", "img": meta.get("img") or "",
            "meta": meta, "ref": ref, "status": "queued", "done": 0, "total": 0, "file": "",
            "created": int(time.time()), "error": "",
            "endsAt": int(time.time() + record_minutes * 60) if rec and record_minutes else None,
        }
        with self.lock:
            self.store.data["items"].insert(0, item)
            self.store.save()
        self._start(item)
        return {k: v for k, v in item.items() if k != "ref"}

    def retry(self, job_id):
        it = self.get(job_id)
        if not it or it["status"] in ("downloading", "recording", "queued"):
            return False
        it.update(status="queued", error="", done=0)
        if it["type"] == "rec":
            it["endsAt"] = None
        self.store.save()
        self._start(it)
        return True

    def stop(self, job_id):
        job = self.jobs.get(job_id)
        if job:
            job.stop.set()
            return True
        return False

    def delete(self, job_id, remove_file=True):
        self.stop(job_id)
        with self.lock:
            it = self.get(job_id)
            if not it:
                return False
            if remove_file and it.get("file"):
                try:
                    os.unlink(it["file"])
                except OSError:
                    pass
            self.store.data["items"] = [x for x in self.store.data["items"] if x["id"] != job_id]
            self.store.save()
        return True

    def _start(self, item):
        job = Job()
        self.jobs[item["id"]] = job
        threading.Thread(target=self._run, args=(item, job), daemon=True).start()

    # --- execução ----------------------------------------------------------------
    def _run(self, item, job):
        rec = item["type"] == "rec"
        if not rec:
            self.sem.acquire()
        try:
            if job.stop.is_set():
                self._set(item["id"], status="canceled")
                return
            url, ua = self.resolver(item["src"], item["kind"], item["ref"])
            headers = {"User-Agent": ua} if ua else None
            meta = item.get("meta") or {}
            base = safe_name(meta.get("fileName") or item["name"])
            if rec:
                base += time.strftime(" - %Y-%m-%d %Hh%M")
            self._set(item["id"], status="recording" if rec else "downloading")
            resp = net.open_url(url, headers=headers, timeout=40)
            first = resp.read(CHUNK)
            ctype = resp.headers.get("Content-Type", "").lower()
            final = resp.geturl()
            if "mpegurl" in ctype or first.lstrip().startswith(b"#EXTM3U"):
                text = (first + resp.read()).decode("utf-8", "replace")
                resp.close()
                path = self._unique(self._folder(rec) / f"{base}.ts")
                self._set(item["id"], file=str(path))
                self._hls(item, job, text, final, path, headers, rec)
            else:
                ext = Path(urllib.parse.urlsplit(final).path).suffix.lower().lstrip(".") or meta.get("ext") or "mp4"
                if rec or ext in ("php", ""):
                    ext = "ts" if rec else (meta.get("ext") or "mp4")
                path = self._unique(self._folder(rec) / f"{base}.{ext}")
                total = int(resp.headers.get("Content-Length") or 0)
                self._set(item["id"], file=str(path), total=0 if rec else total)
                self._copy(item, job, resp, first, path, rec)
            if job.stop.is_set() and not rec:
                self._set(item["id"], status="canceled")
                try:
                    os.unlink(self.get(item["id"])["file"])
                except (OSError, TypeError, KeyError):
                    pass
            else:
                self._set(item["id"], status="done", finished=int(time.time()))
        except Exception as exc:  # noqa: BLE001
            self._set(item["id"], status="error", error=str(exc)[:300])
        finally:
            self.jobs.pop(item["id"], None)
            if not rec:
                self.sem.release()

    @staticmethod
    def _unique(path):
        if not path.exists():
            return path
        stem, suf = path.stem, path.suffix
        for i in range(2, 999):
            p = path.with_name(f"{stem} ({i}){suf}")
            if not p.exists():
                return p
        return path

    def _time_up(self, item):
        ends = self.get(item["id"]).get("endsAt")
        return bool(ends) and time.time() >= ends

    def _copy(self, item, job, resp, first, path, rec):
        done = 0
        last = 0
        with resp, open(path, "wb") as out:
            chunk = first
            while chunk:
                out.write(chunk)
                done += len(chunk)
                if time.time() - last > 1:
                    last = time.time()
                    self._set(item["id"], done=done)
                if job.stop.is_set() or (rec and self._time_up(item)):
                    break
                chunk = resp.read(CHUNK)
        self._set(item["id"], done=done, total=done if not rec else 0)

    def _hls(self, item, job, text, base_url, path, headers, rec):
        # escolhe a melhor variante de uma playlist mestre
        if "#EXT-X-STREAM-INF" in text:
            best, best_bw = None, -1
            lines = text.splitlines()
            for i, line in enumerate(lines):
                if line.startswith("#EXT-X-STREAM-INF"):
                    bw = int(_attrs(line).get("BANDWIDTH", "0").strip('"') or 0)
                    for nxt in lines[i + 1:]:
                        if nxt.strip() and not nxt.startswith("#"):
                            if bw > best_bw:
                                best, best_bw = urllib.parse.urljoin(base_url, nxt.strip()), bw
                            break
            if not best:
                raise net.FetchError("Playlist sem variantes reproduzíveis")
            base_url = best
            text = net.fetch_text(best, headers=headers)
        seen = set()
        done = 0
        last = 0
        with open(path, "wb") as out:
            while True:
                if "#EXT-X-KEY" in text and "METHOD=NONE" not in text:
                    raise net.FetchError("Este conteúdo é criptografado e não pode ser baixado")
                segs = []
                target = 6
                for line in text.splitlines():
                    s = line.strip()
                    if s.startswith("#EXT-X-TARGETDURATION:"):
                        target = max(1, int(float(s.split(":", 1)[1] or 6)))
                    elif s and not s.startswith("#"):
                        segs.append(urllib.parse.urljoin(base_url, s))
                new = [u for u in segs if u not in seen]
                total_segs = len(segs)
                for idx, seg in enumerate(new):
                    if job.stop.is_set() or (rec and self._time_up(item)):
                        return
                    data = net.fetch_bytes(seg, headers=headers, timeout=40)
                    out.write(data)
                    done += len(data)
                    seen.add(seg)
                    if time.time() - last > 1:
                        last = time.time()
                        if rec:
                            self._set(item["id"], done=done)
                        else:
                            self._set(item["id"], done=done, total=int(done / max(1, len(seen)) * total_segs))
                if not rec or "#EXT-X-ENDLIST" in text:
                    self._set(item["id"], done=done, total=done)
                    return
                for _ in range(target * 2):
                    if job.stop.is_set() or self._time_up(item):
                        return
                    time.sleep(0.5)
                text = net.fetch_text(base_url, headers=headers)
