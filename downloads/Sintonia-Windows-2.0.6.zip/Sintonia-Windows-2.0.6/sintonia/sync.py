"""Sincronização opcional entre dois Sintonia (ex.: tablet e PC).

Desligada por padrão. Quando ligada, este aparelho busca os dados do outro, junta com os
seus e (se o outro também tiver a sincronização ligada) envia o resultado de volta.
"""

import hashlib
import json
import threading
import time
import urllib.parse
import urllib.request

ITEMS = ("sources", "favorites", "history", "settings")
SETTINGS_KEYS = ("theme", "accent", "timeFormat", "startTab", "live", "series", "movies", "epg")


def identity(src):
    url = (src.get("url") or "").strip().lower().rstrip("/")
    for pre in ("http://", "https://"):
        if url.startswith(pre):
            url = url[len(pre):]
    key = "|".join([src.get("type", ""), url, (src.get("username") or "").lower(), (src.get("mac") or "").upper()])
    return hashlib.sha1(key.encode()).hexdigest()[:16]


class SyncError(Exception):
    pass


def export(app):
    sources = []
    users = {}
    for s in app.sources.data["items"]:
        ident = identity(s)
        sources.append({k: s.get(k, "") for k in ("type", "name", "url", "username", "password", "mac", "epgUrl", "ua")}
                       | {"ident": ident})
        u = app.user(s["id"]).data
        users[ident] = {k: u.get(k) for k in ("favorites", "history", "recent", "hidden", "pinned")}
    st = app.settings()
    return {"app": "sintonia", "version": 1, "at": int(time.time()), "device": app.device_name(),
            "accepts": bool(st.get("sync", {}).get("enabled")),
            "sources": sources, "users": users, "settings": {k: st.get(k) for k in SETTINGS_KEYS}}


def _union(a, b):
    out = list(a or [])
    seen = set(map(str, out))
    for x in b or []:
        if str(x) not in seen:
            out.append(x)
            seen.add(str(x))
    return out


def merge(app, data, items):
    if not isinstance(data, dict) or data.get("app") != "sintonia":
        raise SyncError("O endereço informado não é um Sintonia")
    stats = {"sources": 0, "favorites": 0, "history": 0, "settings": False}
    local = {identity(s): s for s in app.sources.data["items"]}

    if items.get("sources"):
        for rs in data.get("sources", []):
            if rs.get("ident") in local:
                continue
            new = {k: rs.get(k, "") for k in ("type", "name", "url", "username", "password", "mac", "epgUrl", "ua")}
            new["id"] = hashlib.sha1((rs.get("ident", "") + "local").encode()).hexdigest()[:8]
            new["created"] = int(time.time())

            def add(d, new=new):
                d["items"].append(new)
                if not d.get("active"):
                    d["active"] = new["id"]
            app.sources.update(add)
            local[rs["ident"]] = new
            stats["sources"] += 1

    for ident, ru in (data.get("users") or {}).items():
        src = local.get(ident)
        if not src or not isinstance(ru, dict):
            continue

        def apply(d, ru=ru):
            if items.get("favorites"):
                for kind in ("live", "movie", "series"):
                    before = len(d["favorites"].get(kind, []))
                    d["favorites"][kind] = _union(d["favorites"].get(kind), (ru.get("favorites") or {}).get(kind))
                    stats["favorites"] += len(d["favorites"][kind]) - before
                    d["pinned"][kind] = _union(d["pinned"].get(kind), (ru.get("pinned") or {}).get(kind))
                    d["hidden"][kind] = _union(d["hidden"].get(kind), (ru.get("hidden") or {}).get(kind))
            if items.get("history"):
                by = {(x.get("kind"), str(x.get("id"))): x for x in d["history"]}
                for x in ru.get("history") or []:
                    key = (x.get("kind"), str(x.get("id")))
                    if key not in by or (x.get("ts") or 0) > (by[key].get("ts") or 0):
                        if key not in by:
                            stats["history"] += 1
                        by[key] = x
                d["history"] = sorted(by.values(), key=lambda x: -(x.get("ts") or 0))[:300]
                d["recent"] = _union(d.get("recent"), ru.get("recent"))[:25]
        app.user(src["id"]).update(apply)

    if items.get("settings") and isinstance(data.get("settings"), dict):
        app.save_settings({k: v for k, v in data["settings"].items() if k in SETTINGS_KEYS and v is not None})
        stats["settings"] = True
    return stats


def _peer_url(peer, path):
    peer = (peer or "").strip().rstrip("/")
    if not peer:
        raise SyncError("Informe o endereço do outro aparelho")
    if "://" not in peer:
        peer = "http://" + peer
    parts = urllib.parse.urlsplit(peer)
    if not parts.port and parts.scheme == "http":
        peer = f"{parts.scheme}://{parts.hostname}:8787"
    return peer + path


def _request(cfg, path, body=None, timeout=20):
    headers = {"Content-Type": "application/json"}
    if cfg.get("password"):
        headers["X-Sintonia-Senha"] = cfg["password"]
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(_peer_url(cfg.get("peer"), path), data=data, headers=headers,
                                 method="POST" if body is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            msg = json.loads(exc.read().decode()).get("error")
        except Exception:  # noqa: BLE001
            msg = None
        raise SyncError(msg or f"O outro aparelho respondeu {exc.code}") from exc
    except (urllib.error.URLError, OSError, ValueError) as exc:
        raise SyncError("Não encontrei o outro Sintonia nesse endereço. Ele está aberto e na mesma rede Wi-Fi?") from exc


def test(cfg):
    st = _request(cfg, "/api/sync/export")
    return {"device": st.get("device"), "sources": len(st.get("sources", [])), "accepts": st.get("accepts")}


class Syncer:
    def __init__(self, app):
        self.app = app
        self.lock = threading.Lock()
        self.last = app.settings().get("sync", {}).get("last") or {}
        threading.Thread(target=self._auto, daemon=True).start()

    def cfg(self):
        return self.app.settings().get("sync", {})

    def run(self, manual=True):
        cfg = self.cfg()
        if not cfg.get("enabled"):
            raise SyncError("A sincronização está desligada")
        items = cfg.get("items") or {}
        with self.lock:
            remote = _request(cfg, "/api/sync/export")
            stats = merge(self.app, remote, items)
            pushed = False
            note = ""
            if remote.get("accepts"):
                try:
                    _request(cfg, "/api/sync/import", export(self.app), timeout=40)
                    pushed = True
                except SyncError as exc:
                    note = str(exc)
            else:
                note = "O outro aparelho está com a sincronização desligada: ele só enviou os dados, não recebeu."
            self.last = {"at": int(time.time()), "ok": True, "device": remote.get("device"), "stats": stats,
                         "pushed": pushed, "note": note, "manual": manual}
            self.app.save_settings({"sync": {"last": self.last}})
            return self.last

    def _auto(self):
        while True:
            time.sleep(60)
            cfg = self.cfg()
            if not (cfg.get("enabled") and cfg.get("auto") and cfg.get("peer")):
                continue
            if time.time() - (self.last.get("at") or 0) < int(cfg.get("everyMinutes") or 15) * 60:
                continue
            try:
                self.run(manual=False)
            except Exception as exc:  # noqa: BLE001
                self.last = {"at": int(time.time()), "ok": False, "error": str(exc), "manual": False}
