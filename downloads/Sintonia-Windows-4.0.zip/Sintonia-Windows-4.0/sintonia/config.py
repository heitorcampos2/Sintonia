"""Caminhos e configurações padrão."""

import os
from pathlib import Path


def data_dir(override=None):
    if override:
        p = Path(override).expanduser()
    elif os.environ.get("SINTONIA_DADOS"):
        p = Path(os.environ["SINTONIA_DADOS"]).expanduser()
    elif os.name == "nt":
        p = Path(os.environ.get("APPDATA") or Path.home()) / "Sintonia"
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
        p = Path(base) / "sintonia"
    p.mkdir(parents=True, exist_ok=True)
    return p


def default_media_dir(sub="Sintonia"):
    """No Android (udroid) prefere a pasta Download compartilhada, visível fora do Linux."""
    if os.environ.get("SINTONIA_MIDIA"):  # app Android: pasta do próprio app
        return str(Path(os.environ["SINTONIA_MIDIA"]) / sub)
    for cand in ("/sdcard/Download", "/storage/emulated/0/Download"):
        if os.path.isdir(cand) and os.access(cand, os.W_OK):
            return str(Path(cand) / sub)
    return str(Path.home() / "Downloads" / sub)


DEFAULT_SETTINGS = {
    "theme": "dark",
    "accent": "azul",
    "style": "neon",                                  # 4.0: padrão Neon + fundo Preto OLED + azul
    "bg": {"mode": "oled", "color": "#1e293b"},
    "appIcon": "padrao",
    "timeFormat": "24",
    "startTab": "live",
    "live": {"favFirst": True, "openGuide": False, "defaultCat": "", "sort": "remember", "showRecent": True},
    "series": {"favFirst": True, "defaultCat": "", "sort": "remember", "showRecent": True,
               "showPopular": False, "autoNext": True},
    "movies": {"favFirst": False, "defaultCat": "", "sort": "remember", "showRecent": True,
               "showPopular": False},
    "player": {"liveFormat": "ts", "useProxy": False, "userAgent": "", "resume": "ask",
               "subtitleLang": "", "audioLang": "", "aspect": "contain", "buffer": "max",
               "skipSeconds": 10, "controlsSeconds": 4, "landscape": True, "engine": "auto",
               "nativeTv": False, "tvPlayer": "live"},
    "epg": {"enabled": True, "refreshHours": 12, "offsetMinutes": 0},
    "downloadDir": "",
    "downloads": {"enabled": True},   # 3.1.38: Downloads e gravações (seção Offline) ligados/desligados
    "recordDir": "",
    "cacheHours": 12,
    "lastSort": {},
    "network": {"allowLan": False},
    "branding": {"enabled": False, "title": "", "logo": ""},
    # 2.3.9: seção Canais YouTube (Menu › Opcionais); 3.1.29: vem ligada, com a CNN Brasil na lista
    "youtube": {"enabled": True, "channels": [{"id": "UCvdwhh_fDyWccR42-rReZLw", "name": "CNN Brasil", "thumb": ""}, {"id": "UCZiYbVptd3PVPf4f6eR6UaQ", "name": "CazéTV", "thumb": ""}], "vodChannels": []},   # título e logo próprios na barra lateral
    "noListMode": False,  # 2.5.4: entrou sem lista ("acessar apenas Canais YouTube")
    "syncAsked": False,   # já perguntou na primeira abertura se quer sincronizar na rede   # outros aparelhos da rede só com a caixa marcada
    "sync": {"enabled": False, "peer": "", "password": "", "auto": False, "everyMinutes": 15,
             "items": {"sources": True, "favorites": True, "history": True, "settings": False}, "last": {}},
}


def merge_defaults(value, default):
    """Completa um dicionário salvo com as chaves novas do padrão."""
    if not isinstance(default, dict):
        return value if value is not None else default
    out = dict(default)
    if isinstance(value, dict):
        for k, v in value.items():
            if k in default and isinstance(default[k], dict):
                out[k] = merge_defaults(v, default[k])
            else:
                out[k] = v
    return out
