// Canais YouTube (2.3.9): opcional em Menu › Opcionais. CNN Brasil ao vivo + canais que você adicionar.
import { api } from '../api.js';
import { openPlayer } from '../player.js';
import { S, saveSettings } from '../state.js';
import { btn, clear, h, ic, menu, pic, spinner, toast } from '../ui.js';
import { sectionHeader } from './common.js';

const status = new Map();   // canal -> situação (ao vivo, título)

function channels() { return (S.settings.youtube && S.settings.youtube.channels) || []; }
async function saveChannels(list) { await saveSettings({ youtube: { channels: list } }); }
const has = (id) => channels().some((c) => c.id === id);
function vodChannels() { return (S.settings.youtube && S.settings.youtube.vodChannels) || []; }
async function saveVodChannels(list) { await saveSettings({ youtube: { vodChannels: list } }); }

/** Segurar o dedo / clique direito / tecla de menu abre as opções; toque normal faz a ação principal. */
function pressable(el, onTap, onHold) {
  let t = null, held = false;
  el.addEventListener('pointerdown', () => { held = false; clearTimeout(t); t = setTimeout(() => { held = true; onHold(); }, 550); });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => el.addEventListener(ev, () => clearTimeout(t)));
  el.addEventListener('click', (e) => { if (held) { e.preventDefault(); held = false; return; } onTap(); });
  el.addEventListener('contextmenu', (e) => { e.preventDefault(); clearTimeout(t); onHold(); });
  el.addEventListener('keydown', (e) => { if (e.key === 'ContextMenu') { e.preventDefault(); onHold(); } });
  return el;
}

async function play(ch) {
  const lives = channels().filter((c) => status.get(c.id)?.live);
  const list = (lives.some((c) => c.id === ch.id) ? lives : [ch]).map((c) => ({ id: `yt-${c.id}`, name: c.name, logo: c.thumb, yt: c.id, ytTitle: status.get(c.id)?.title || '' }));
  const it = list.find((x) => x.yt === ch.id);
  openPlayer({ kind: 'live', item: it, list });
}

// ---------------------------------------------------------------- 2.5.1: atalho SmartTube + pasta Canais (vídeos)
const ST_PKGS = 'org.smarttube.stable,org.smarttube.beta,com.teamsmart.videomanager.tv,com.liskovsoft.smarttubetv.beta';
const ST_URL = 'https://github.com/yuliskov/SmartTube/releases';
function openSmartTube() {
  const N = window.SintoniaApp;
  if (N && N.openApp) {
    let r = '';
    try { r = N.openApp(ST_PKGS, ST_URL); } catch { /* ok */ }
    if (!r) toast('O SmartTube não está instalado. Abrindo a página de download…');
    return;
  }
  window.open(ST_URL, '_blank', 'noopener');
}
const stBtn = () => btn('SmartTube', { cls: 'ghost st-btn', icon: 'play', title: 'Abrir o app SmartTube', onclick: openSmartTube });
/** A pasta de vídeos só existe no app Android (celular, tablet e TV). */
const VOD_OK = () => S.platform === 'android';

export function render(root, params) {
  if (params[0] === 'buscar') return searchPage(root, params[1] === 'videos');
  if (params[0] === 'canais' && VOD_OK()) return vodHome(root);
  if (params[0] === 'canal' && VOD_OK()) return channelPage(root, decodeURIComponent(params[1] || ''));
  if (params[0] === 'videos' && VOD_OK()) return videoSearchPage(root);
  const grid = h('div.yt-grid');
  root.append(sectionHeader('Canais YouTube', { middle: stBtn(), actions: [
    VOD_OK() ? btn('Canais (vídeos)', { cls: 'ghost', icon: 'film', onclick: () => { location.hash = '#/youtube/canais'; } }) : null,
    btn('Atualizar', { cls: 'ghost', icon: 'refresh', onclick: () => refresh(true) }),
    btn('Adicionar canal', { cls: 'primary', icon: 'plus', onclick: () => { location.hash = '#/youtube/buscar'; } })] }),
  h('div.view-body', h('p.hint', 'Toque num canal ao vivo para assistir. Segure (ou clique com o botão direito) para opções.'), grid));
  let alive = true;
  function draw() {
    clear(grid);
    const l = channels();
    if (!l.length) { grid.append(h('div.empty', 'Nenhum canal. Use "Adicionar canal" para buscar no YouTube.')); return; }
    const lv = l.filter((c) => status.get(c.id)?.live);
    [...lv, ...l.filter((c) => !lv.includes(c))].forEach((c) => {
      const st = status.get(c.id);
      const card = h('button.yt-card', { type: 'button' },
        h('div.yt-art', { class: st?.vid ? '' : 'noimg' }, st?.vid ? h('img', { src: `https://i.ytimg.com/vi/${st.vid}/mqdefault.jpg`, alt: '', loading: 'lazy', onerror: (e) => e.target.remove() }) : null,
          h('div.yt-ava', pic(c.thumb, c.name)), st?.live ? h('span.yt-live', 'AO VIVO') : null),
        h('div.yt-meta', h('strong', c.name), h('small', !st ? 'Verificando…' : st.live ? st.title : 'Sem transmissão ao vivo agora')));
      pressable(card, () => { if (st?.live) play(c); else toast(st ? `${c.name} não está ao vivo agora` : 'Verificando…'); }, () => options(c));
      grid.append(card);
    });
  }
  async function options(c) {
    const l = channels(), i = l.findIndex((x) => x.id === c.id), st = status.get(c.id);
    await menu([
      st?.live ? { label: 'Assistir ao vivo', icon: 'play', fn: () => play(c) } : null,
      { label: 'Ver de novo se está ao vivo', icon: 'refresh', fn: () => check(c, true) },
      i > 0 ? { label: 'Mover para cima', icon: 'chevL', fn: async () => { const n = [...l]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; await saveChannels(n); draw(); } } : null,
      i < l.length - 1 ? { label: 'Mover para baixo', icon: 'chevR', fn: async () => { const n = [...l]; [n[i + 1], n[i]] = [n[i], n[i + 1]]; await saveChannels(n); draw(); } } : null,
      { label: 'Remover dos Canais YouTube', icon: 'trash', fn: async () => { await saveChannels(l.filter((x) => x.id !== c.id)); draw(); } },
    ].filter(Boolean), { title: c.name });
  }
  async function check(c, force) {
    try { status.set(c.id, await api.get(`/api/yt/status?id=${encodeURIComponent(c.id)}${force ? '&force=1' : ''}`)); } catch { status.set(c.id, { live: false }); }
    if (alive) draw();
  }
  async function refresh(force) {
    draw();
    const l = channels();
    // canal sem foto (a CNN que já vem na lista): pega pela busca uma vez
    l.filter((c) => !c.thumb).forEach(async (c) => {
      try {
        const r = await api.get(`/api/yt/search?q=${encodeURIComponent(c.name)}`);
        const m = r.channels.find((x) => x.id === c.id);
        if (m && m.thumb) { await saveChannels(channels().map((x) => (x.id === c.id ? { ...x, thumb: m.thumb } : x))); if (alive) draw(); }
      } catch { /* fica com as iniciais */ }
    });
    l.forEach((c) => check(c, force));
  }
  refresh(false);
  return () => { alive = false; };
}

function searchPage(root, vodMode) {
  const listOf = () => (vodMode ? vodChannels() : channels());
  const saveList = (l) => (vodMode ? saveVodChannels(l) : saveChannels(l));
  const has = (id) => listOf().some((c) => c.id === id);
  const input = h('input.input', { type: 'search', placeholder: 'Nome do canal no YouTube', autocomplete: 'off' });
  const res = h('div.yt-results');
  const go = async () => {
    const q = input.value.trim();
    if (q.length < 2) { toast('Digite pelo menos 2 letras'); return; }
    clear(res).append(spinner());
    let r;
    try { r = await api.get(`/api/yt/search?q=${encodeURIComponent(q)}`); } catch (e) { clear(res).append(h('div.empty', `Não deu para buscar: ${e.message}`)); return; }
    show(r.channels);
  };
  function show(list) {
    clear(res);
    if (!list.length) { res.append(h('div.empty', 'Nenhum canal encontrado.')); return; }
    list.forEach((c) => {
      const el = h('button.yt-res', { type: 'button' }, h('span.yt-res-ava', pic(c.thumb, c.name)),
        h('span.yt-res-txt', h('strong', c.name), h('small', [has(c.id) ? '✓ Adicionado' : '', c.subs || ''].filter(Boolean).join(' · '))),
        has(c.id) ? ic('check') : ic('plus'));
      const opts = async () => {
        await menu([
          has(c.id) ? { label: vodMode ? 'Remover dos Canais' : 'Remover dos Canais YouTube', icon: 'trash', fn: async () => { await saveList(listOf().filter((x) => x.id !== c.id)); show(list); } }
            : { label: vodMode ? 'Adicionar aos Canais' : 'Adicionar aos Canais YouTube', icon: 'plus', fn: async () => { await saveList([...listOf(), { id: c.id, name: c.name, thumb: c.thumb }]); toast(`"${c.name}" adicionado`); show(list); } },
          vodMode ? { label: 'Ver vídeos do canal', icon: 'play', fn: () => { location.hash = `#/youtube/canal/${encodeURIComponent(c.id)}`; } } : { label: 'Ver se está ao vivo', icon: 'play', fn: async () => {
            try {
              const st = await api.get(`/api/yt/status?id=${encodeURIComponent(c.id)}&force=1`);
              status.set(c.id, st);
              if (st.live) play(c); else toast(`${c.name} não está ao vivo agora`);
            } catch (e) { toast(e.message); }
          } },
        ], { title: c.name });
      };
      pressable(el, opts, opts);
      res.append(el);
    });
  }
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
  root.append(sectionHeader(vodMode ? 'Adicionar canal (vídeos)' : 'Adicionar canal', { back: () => { location.hash = vodMode ? '#/youtube/canais' : '#/youtube'; } }),
    h('div.view-body.narrow', h('p.hint', 'Busque no YouTube e toque (ou segure) num canal para adicionar.'),
      h('div.yt-search', input, btn('Buscar', { cls: 'primary', icon: 'search', onclick: go })), res));
  setTimeout(() => input.focus(), 50);
}

// ---------------------------------------------------------------- pasta Canais (vídeos) — só app Android
function progAll() { try { return JSON.parse(localStorage.getItem('sintonia.ytprog') || '{}'); } catch { return {}; } }
export function ytSaveProg(v, pos, dur, done) {
  const all = progAll();
  all[v.id] = { pos: Math.floor(pos || 0), dur: Math.floor(dur || 0), done: !!done, t: Date.now(), title: v.title, thumb: v.thumb, dur2: v.dur || '', meta: v.meta || '' };
  const keys = Object.keys(all);
  if (keys.length > 400) keys.sort((a, b) => all[a].t - all[b].t).slice(0, keys.length - 400).forEach((k) => delete all[k]);
  try { localStorage.setItem('sintonia.ytprog', JSON.stringify(all)); } catch { /* sem espaço */ }
}
function playVideo(v, fromStart) {
  const p = progAll()[v.id];
  const startAt = !fromStart && p && !p.done && p.pos > 5 && (!p.dur || p.pos < p.dur - 15) ? p.pos : 0;
  openPlayer({ kind: 'ytv', item: { id: v.id, name: v.title, title: v.title, thumb: v.thumb, dur: v.dur, meta: v.meta }, startAt });
}
function videoCard(v, redraw) {
  const p = progAll()[v.id];
  const pct = p && p.dur ? Math.min(100, Math.round((p.pos * 100) / p.dur)) : 0;
  const card = h('button.yt-card.ytv-card', { type: 'button' },
    h('div.yt-art', h('img', { src: v.thumb, alt: '', loading: 'lazy', onerror: (e) => e.target.remove() }),
      v.dur ? h('span.yt-dur', v.dur) : null, p && p.done ? h('span.yt-seen', '✓ Assistido') : null,
      p && !p.done && pct > 0 ? h('div.yt-prog', h('i', { style: `width:${pct}%` })) : null),
    h('div.yt-meta', h('strong', v.title), h('small', v.meta || '')));
  pressable(card, () => playVideo(v), async () => {
    const q = progAll()[v.id];
    await menu([
      { label: 'Assistir', icon: 'play', fn: () => playVideo(v) },
      q && q.pos > 5 && !q.done ? { label: 'Começar do início', icon: 'replay', fn: () => playVideo(v, true) } : null,
      q && q.done ? { label: 'Marcar como não assistido', icon: 'close', fn: () => { ytSaveProg(v, 0, q.dur, false); redraw && redraw(); } }
        : { label: 'Marcar como assistido', icon: 'check', fn: () => { ytSaveProg(v, q ? q.dur : 0, q ? q.dur : 0, true); redraw && redraw(); } },
    ].filter(Boolean), { title: v.title });
  });
  return card;
}
/** Grade de vídeos com "Carregar mais". */
function videoGrid(body, load) {
  const grid = h('div.yt-grid.ytv-grid');
  const more = h('div.yt-more');
  body.append(grid, more);
  const items = [];
  let next = null;
  const draw = () => { clear(grid); items.forEach((v) => grid.append(videoCard(v, draw))); };
  async function page(token) {
    clear(more).append(spinner());
    let r;
    try { r = await load(token); } catch (e) { clear(more).append(h('div.empty', `Não deu para carregar: ${e.message}`)); return; }
    r.items.forEach((v) => { items.push(v); grid.append(videoCard(v, draw)); });
    next = r.next;
    clear(more);
    if (!items.length) more.append(h('div.empty', 'Nenhum vídeo encontrado.'));
    else if (next) more.append(btn('Carregar mais', { cls: 'ghost', icon: 'chevD', onclick: () => page(next) }));
  }
  page(null);
  // ao voltar do player, atualiza as barras de progresso
  const onFocus = () => draw();
  window.addEventListener('sintonia:playerclosed', onFocus);
  return () => window.removeEventListener('sintonia:playerclosed', onFocus);
}
function vodHome(root) {
  const body = h('div.view-body');
  root.append(sectionHeader('Canais', { middle: stBtn(), back: () => { location.hash = '#/youtube'; }, actions: [
    btn('Buscar vídeos', { cls: 'ghost', icon: 'search', onclick: () => { location.hash = '#/youtube/videos'; } }),
    btn('Adicionar canal', { cls: 'primary', icon: 'plus', onclick: () => { location.hash = '#/youtube/buscar/videos'; } })] }), body);
  function draw() {
    clear(body);
    const all = progAll();
    const cont = Object.keys(all).map((k) => ({ id: k, title: all[k].title, thumb: all[k].thumb, dur: all[k].dur2, meta: all[k].meta, t: all[k].t, p: all[k] }))
      .filter((x) => !x.p.done && x.p.pos > 5).sort((a, b) => b.t - a.t).slice(0, 12);
    if (cont.length) {
      const g = h('div.yt-grid.ytv-grid');
      cont.forEach((v) => g.append(videoCard(v, draw)));
      body.append(h('h2.sec-title', 'Continuar assistindo'), g);
    }
    body.append(h('h2.sec-title', 'Seus canais'));
    const l = vodChannels();
    if (!l.length) { body.append(h('p.hint', 'Nenhum canal ainda. Toque em "Adicionar canal", busque e segure o dedo num canal para adicionar.')); return; }
    const list = h('div.yt-results');
    l.forEach((c, i) => {
      const el = h('button.yt-res', { type: 'button' }, h('span.yt-res-ava', pic(c.thumb, c.name)), h('span.yt-res-txt', h('strong', c.name), h('small', 'Ver vídeos')), ic('chevR'));
      pressable(el, () => { location.hash = `#/youtube/canal/${encodeURIComponent(c.id)}`; }, async () => {
        await menu([
          { label: 'Ver vídeos', icon: 'play', fn: () => { location.hash = `#/youtube/canal/${encodeURIComponent(c.id)}`; } },
          i > 0 ? { label: 'Mover para cima', icon: 'chevL', fn: async () => { const n = [...l]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; await saveVodChannels(n); draw(); } } : null,
          i < l.length - 1 ? { label: 'Mover para baixo', icon: 'chevR', fn: async () => { const n = [...l]; [n[i + 1], n[i]] = [n[i], n[i + 1]]; await saveVodChannels(n); draw(); } } : null,
          { label: 'Remover dos Canais', icon: 'trash', fn: async () => { await saveVodChannels(l.filter((x) => x.id !== c.id)); draw(); } },
        ].filter(Boolean), { title: c.name });
      });
      list.append(el);
    });
    body.append(list);
  }
  draw();
  const onBack = () => draw();
  window.addEventListener('sintonia:playerclosed', onBack);
  return () => window.removeEventListener('sintonia:playerclosed', onBack);
}
function channelPage(root, id) {
  const c = vodChannels().find((x) => x.id === id) || { id, name: 'Canal' };
  const body = h('div.view-body');
  root.append(sectionHeader(c.name, { back: () => { location.hash = '#/youtube/canais'; }, actions: [
    vodChannels().some((x) => x.id === id) ? null : btn('Adicionar aos Canais', { cls: 'primary', icon: 'plus', onclick: async () => { await saveVodChannels([...vodChannels(), c]); toast('Adicionado'); } })] }), body);
  return videoGrid(body, (next) => api.get(`/api/yt/videos?id=${encodeURIComponent(id)}${next ? `&next=${encodeURIComponent(next)}` : ''}`));
}
function videoSearchPage(root) {
  const input = h('input.input', { type: 'search', placeholder: 'Buscar vídeos no YouTube', autocomplete: 'off' });
  const res = h('div');
  let stop = null;
  const go = () => {
    const q = input.value.trim();
    if (q.length < 2) { toast('Digite pelo menos 2 letras'); return; }
    if (stop) stop();
    clear(res);
    stop = videoGrid(res, (next) => api.get(`/api/yt/vsearch?q=${encodeURIComponent(q)}${next ? `&next=${encodeURIComponent(next)}` : ''}`));
  };
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
  root.append(sectionHeader('Buscar vídeos', { back: () => { location.hash = '#/youtube/canais'; } }),
    h('div.view-body', h('div.yt-search', input, btn('Buscar', { cls: 'primary', icon: 'search', onclick: go })), res));
  setTimeout(() => input.focus(), 50);
  return () => { if (stop) stop(); };
}
