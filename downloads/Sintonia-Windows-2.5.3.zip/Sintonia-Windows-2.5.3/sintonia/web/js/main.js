import { api } from './api.js';
import { closePlayer, isPlayerOpen } from './player.js';
import { S, loadState, loadUser, onChange, resetSourceData, saveSettings, src } from './state.js';
import { btn, clear, closeTopModal, h, ic, initials, menu, modal, toast } from './ui.js';
import { catPanel } from './views/common.js';
import * as detail from './views/detail.js';
import * as guide from './views/guide.js';
import * as live from './views/live.js';
import * as menuView from './views/menu.js';
import * as multi from './views/multi.js';
import * as offline from './views/offline.js';
import { prepare, renderWelcome } from './views/onboarding.js';
import * as search from './views/search.js';
import * as vod from './views/vod.js';
import * as youtube from './views/youtube.js';
import { startUpdateChecks } from './views/update.js';
import { TV, startHomeChannels } from './tv.js';
import { preload } from './engines.js';

const NAV = [
  ['live', 'tv', 'TV ao Vivo'],
  ['series', 'series', 'Séries'],
  ['movies', 'film', 'Filmes'],
  ['offline', 'offline', 'Offline'],
  ['search', 'search', 'Pesquisar'],
  ['menu', 'gear', 'Menu'],
];
/** 2.3.9: "Canais YouTube" depois de Filmes, quando ligado em Menu › Opcionais. */
function navItems() {
  if (!S.settings?.youtube?.enabled) return NAV;
  return [...NAV.slice(0, 3), ['youtube', 'youtube', 'Canais YouTube'], ...NAV.slice(3)];
}
const KIND_OF_ROUTE = { live: 'live', movies: 'movie', series: 'series', guide: 'live' };
const ROUTES = {
  live: (r, p) => live.render(r, p),
  movies: (r, p) => vod.render(r, p, 'movie'),
  series: (r, p) => vod.render(r, p, 'series'),
  movie: (r, p) => detail.renderMovie(r, p),
  serie: (r, p) => detail.renderSeries(r, p),
  offline: (r) => offline.render(r),
  search: (r) => search.render(r),
  menu: (r, p) => menuView.render(r, p),
  guide: (r) => guide.render(r),
  multi: (r) => multi.render(r),
  youtube: (r, p) => youtube.render(r, p),
};

const app = document.getElementById('app');
let shell = null;
let cleanup = null;
let panelKind = null;

function parseHash() {
  const parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  return { name: parts[0] || '', params: parts.slice(1) };
}

function startRoute() {
  const t = S.settings.startTab || 'live';
  return { live: 'live', series: 'series', movies: 'movies', search: 'search' }[t] || 'live';
}

// ---------------------------------------------------------------- estrutura
function buildShell() {
  clear(app);
  const nav = h('nav.nav', { 'aria-label': 'Navegação principal' },
    ...navItems().map(([id, icn, label]) => h('a.nav-item', { href: `#/${id}`, 'data-r': id }, ic(icn), h('span', label))));
  const cats = h('aside.catcol', { 'aria-label': 'Categorias' });
  const profile = h('button.profile', { type: 'button', onclick: profileMenu });
  const side = h('aside.side',
    h('div.brand', h('button.icon-btn.side-toggle', { type: 'button', 'aria-label': 'Recolher menu', onclick: () => document.body.classList.toggle('side-mini') }, ic('menu')),
      h('a.brand-name', { href: '#/' }, h('span.brand-mark', ic('signal')), h('span', 'Sintonia'))),
    nav, h('div.side-sep'), sideClock(), h('div.side-fill', h('div.side-brand')), profile);
  const view = h('div.view');
  const main = h('main.main', view);
  const bottom = h('nav.bottom-nav', ...navItems().map(([id, icn, label]) => h('a', { href: `#/${id}`, 'data-r': id }, ic(icn), h('span', label === 'TV ao Vivo' ? 'Ao vivo' : label === 'Canais YouTube' ? 'YouTube' : label))));
  const scrim = h('div.scrim', { onclick: () => document.body.classList.remove('drawer', 'catdrawer') });
  app.append(side, cats, main, bottom, scrim);
  shell = { side, nav, cats, profile, view, main, bottom };
  drawProfile();
  drawBranding();
}

/** 2.5.2: relógio em tempo real logo abaixo de Menu, na barra lateral. */
let clockTimer = 0;
function sideClock() {
  const hm = h('span.sc-hm'), sec = h('span.sc-s'), day = h('div.sc-day');
  const box = h('div.side-clock', { 'aria-live': 'off' }, h('div.sc-time', hm, sec), day);
  const p2 = (n) => String(n).padStart(2, '0');
  const tick = () => {
    const d = new Date();
    hm.textContent = p2(d.getHours()) + ':' + p2(d.getMinutes());
    sec.textContent = ':' + p2(d.getSeconds());
    const t = d.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short' }).replace(/\./g, '');
    if (day.textContent !== t) day.textContent = t.charAt(0).toUpperCase() + t.slice(1);
    box.title = d.toLocaleString('pt-BR');
  };
  tick();
  clearTimeout(clockTimer);
  const loop = () => { tick(); clockTimer = setTimeout(loop, 1000 - (Date.now() % 1000) + 5); };
  clockTimer = setTimeout(loop, 1000 - (Date.now() % 1000) + 5);
  return box;
}

/** Título e logo próprios no espaço livre da barra lateral (Menu › Tema e cores). */
function drawBranding() {
  const box = shell && shell.side.querySelector('.side-brand');
  if (!box) return;
  const b = S.settings.branding || {};
  clear(box);
  const on = b.enabled && (b.title || b.logo);
  box.hidden = !on;
  if (!on) return;
  if (b.logo) box.append(h('img.side-brand-logo', { src: b.logo, alt: '' }));
  if (b.title) box.append(h('div.side-brand-title', b.title));
}

/** Liga/desliga o item "Canais YouTube" do menu sem recarregar a página. */
function drawNav() {
  const items = navItems();
  if (shell.nav.children.length === items.length) return;
  clear(shell.nav).append(...items.map(([id, icn, label]) => h('a.nav-item', { href: `#/${id}`, 'data-r': id }, ic(icn), h('span', label))));
  clear(shell.bottom).append(...items.map(([id, icn, label]) => h('a', { href: `#/${id}`, 'data-r': id }, ic(icn), h('span', label === 'TV ao Vivo' ? 'Ao vivo' : label === 'Canais YouTube' ? 'YouTube' : label))));
  syncSide(parseHash().name);
}

function drawProfile() {
  const s = src();
  clear(shell.profile).append(h('span.avatar', initials(s ? s.name : '?')), h('span.profile-name', s ? s.name : 'Sem fonte'), ic('chevD', 'muted'));
}

async function profileMenu() {
  const items = S.sources.map((s) => ({ label: s.name, sub: { xtream: 'Xtream Codes', m3u: 'Playlist M3U', stalker: 'Portal Stalker' }[s.type], icon: 'user',
    checked: s.id === S.active, fn: () => { if (s.id !== S.active) menuView.switchSource(s.id); } }));
  items.push(null, { label: 'Gerenciar fontes', icon: 'sliders', fn: () => { location.hash = '#/menu/fontes'; } },
    { label: 'Adicionar fonte', icon: 'plus', fn: () => { location.hash = '#/menu/fonte/nova'; } });
  menu(items, { title: 'Fontes' });
}

function syncSide(name) {
  [...shell.nav.children, ...shell.bottom.children].forEach((a) => {
    const r = a.dataset.r;
    const on = r === name || (r === 'movies' && name === 'movie') || (r === 'series' && name === 'serie') || (r === 'live' && (name === 'guide' || name === 'multi'));
    a.classList.toggle('on', on);
    if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  const kind = KIND_OF_ROUTE[name] || null;
  if (kind !== panelKind) {
    panelKind = kind;
    clear(shell.cats);
    if (kind) shell.cats.append(catPanel(kind));
  } else if (kind && shell.cats.firstChild) shell.cats.firstChild.redraw();
  document.body.classList.toggle('no-cats', !kind);
}

function route() {
  if (!shell) return;
  let { name, params } = parseHash();
  if (!ROUTES[name]) {
    name = startRoute();
    history.replaceState(null, '', `#/${name}`);
    params = [];
  }
  if (isPlayerOpen()) closePlayer();
  if (cleanup) { try { cleanup(); } catch { /* ignora */ } cleanup = null; }
  closeTopModal();
  document.body.classList.remove('drawer', 'catdrawer');
  clear(shell.view);
  shell.view.className = `view v-${name}`;
  syncSide(name);
  shell.main.scrollTop = 0;
  const c = ROUTES[name](shell.view, params);
  if (typeof c === 'function') cleanup = c;
}

// ---------------------------------------------------------------- inicialização
async function enterApp() {
  resetSourceData();
  clear(app);
  await prepare(app);
  buildShell();
  route();
  if (!S.settings.syncAsked) setTimeout(askSyncOnce, 1500);
  if (!updatesStarted) { updatesStarted = true; setTimeout(startUpdateChecks, 3000); if (TV) startHomeChannels(); preload(S.settings?.player?.liveFormat); }
}
let updatesStarted = false;

/** Uma vez só (quem já usava antes da 2.0.7): pergunta se quer sincronizar com outros aparelhos da rede. */
function askSyncOnce() {
  saveSettings({ syncAsked: true }).catch(() => {});
  const m = modal(h('div',
    h('p.confirm-msg', 'Novidade: o Sintonia agora encontra sozinho os outros aparelhos com Sintonia no mesmo Wi-Fi e junta listas, favoritos e "continuar assistindo".'),
    h('p.hint', 'É opcional. Você pode ligar ou desligar quando quiser em Menu › Sincronizar aparelhos.'),
    h('div.modal-actions',
      btn('Agora não', { cls: 'ghost', onclick: () => m.close() }),
      btn('Ligar e procurar', { cls: 'primary', icon: 'wifi', onclick: () => { m.close(); location.hash = '#/menu/sincronizar'; } }))),
  { title: 'Sincronizar aparelhos?' });
}

function showLogin() {
  clear(app);
  const input = h('input.input', { type: 'password', placeholder: 'Senha', autocomplete: 'current-password' });
  const err = h('p.form-err');
  const go = async () => {
    try { await api.post('/api/login', { password: input.value }); location.reload(); } catch (e) { err.textContent = e.message; }
  };
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
  app.append(h('div.login', h('div.brand.big', h('span.brand-mark', ic('signal')), h('span', 'Sintonia')),
    h('p', 'Este Sintonia é protegido por senha.'), input, err, btn('Entrar', { cls: 'primary lg block', onclick: go })));
  input.focus();
}

async function boot() {
  try {
    await loadState();
  } catch (e) {
    if (e.status === 401) { showLogin(); return; }
    clear(app).append(h('div.fatal', ic('warning'), h('h2', 'Não foi possível falar com o servidor'), h('p', e.message),
      btn('Tentar de novo', { cls: 'primary', onclick: () => location.reload() })));
    return;
  }
  if (!S.sources.length) {
    clear(app);
    renderWelcome(app, () => { location.hash = '#/live'; enterApp(); });
    return;
  }
  await enterApp();
}

window.addEventListener('hashchange', route);
window.addEventListener('sintonia:auth', showLogin);
window.addEventListener('sintonia:source-changed', async () => {
  if (!S.sources.length) { location.hash = ''; boot(); return; }
  history.replaceState(null, '', `#/${startRoute()}`);
  await enterApp();
  toast(`Usando "${src()?.name}"`);
});
onChange((what) => {
  if (what === 'settings' && shell) { drawProfile(); drawBranding(); drawNav(); }
  // categoria escolhida fica destacada na coluna
  if ((what === 'cat' || what === 'cats' || what === 'settings') && shell && shell.cats.firstChild && shell.cats.firstChild.redraw) shell.cats.firstChild.redraw();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !isPlayerOpen()) {
    if (closeTopModal()) return;
    document.body.classList.remove('drawer', 'catdrawer');
  }
  if (e.key === '/' && !isPlayerOpen() && !e.target.closest('input, textarea, select')) {
    const s = document.querySelector('.view .search-box input');
    if (s) { e.preventDefault(); s.focus(); }
  }
});

window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); window.__sintoniaInstall = e; });
window.addEventListener('appinstalled', () => { window.__sintoniaInstall = null; });

if ('serviceWorker' in navigator && window.isSecureContext) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

boot();
export { loadUser };
