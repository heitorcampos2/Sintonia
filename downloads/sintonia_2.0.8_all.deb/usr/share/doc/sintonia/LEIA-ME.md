# Sintonia

Player IPTV que roda como servidor no Linux (inclusive Ubuntu no Android via udroid) e abre em qualquer navegador: no próprio aparelho, no Windows, na TV ou em outro celular da mesma rede.

O Sintonia não fornece canais nem conteúdo. Ele reproduz as listas que você adiciona (Xtream Codes, M3U/M3U8 ou Portal Stalker).

## Instalar

```bash
sudo apt install ./sintonia_1.0.0_all.deb
```

Precisa apenas do `python3` (já vem no Ubuntu). Nenhum pacote extra.

## Usar

```bash
sintonia --abrir
```

O terminal mostra os endereços, por exemplo:

- Neste aparelho: http://localhost:8787
- Na rede: http://192.168.0.15:8787 (abra este no Windows)

Também há um atalho "Sintonia" no menu de aplicativos.

Opções:

| Comando | O que faz |
|---|---|
| `sintonia --porta 8790` | Usa outra porta |
| `sintonia --senha 1234` | Pede senha para quem abrir pela rede |
| `sintonia --fundo` | Roda em segundo plano |
| `sintonia --parar` | Para a execução em segundo plano |
| `sintonia --host 127.0.0.1` | Aceita só este aparelho |

## Instalar como aplicativo no Windows

Abra o endereço da rede no Chrome ou no Edge.
- Chrome: menu ⋮ › Transmitir, salvar e compartilhar › Criar atalho… › marque "Abrir como janela".
- Edge: menu ··· › Aplicativos › Instalar este site como um aplicativo.

## Estabilidade da reprodução

Menu › Reprodutor de vídeo:

- **Latência baixa / Normal / Alto**: quanto vídeo o navegador guarda à frente.
- **Máximo** (padrão): guarda até 15 min à frente, insiste sem parar se a conexão cair; ao vivo ganha 5 s de reserva no servidor e reconexão automática.
- **Ultra extremo**: filmes e episódios são baixados inteiros, o mais rápido possível, para o aparelho do Sintonia. Sem internet, o vídeo segue até onde foi carregado e o download continua do mesmo ponto quando a conexão volta. Ao vivo ganha 15 s de reserva.

## Onde ficam os dados

- Configurações, favoritos e histórico: `~/.config/sintonia`
- Downloads e gravações: `/sdcard/Download/Sintonia` no Android, ou `~/Downloads/Sintonia`

## Estrutura do código

```
sintonia/
  cli.py            linha de comando
  server.py         servidor HTTP e rotas da API
  providers/        xtream.py, m3u.py, stalker.py
  catalog.py        cache dos catálogos
  epg.py            guia de programação (XMLTV)
  proxy.py          proxy de vídeo (CORS, HLS)
  streamcache.py    reserva de vídeo (modos Máximo e Ultra)
  downloads.py      downloads e gravações
  media.py          cache de imagens e bibliotecas de vídeo
  web/              interface (HTML, CSS, JavaScript em módulos)
```
