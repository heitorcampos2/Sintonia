"""Servidor HTTP do Sintonia: API JSON, proxy de vídeo e arquivos da interface."""

import gzip
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import socket
import threading
import time
import traceback
import urllib.error
import urllib.parse
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import VERSION, net, proxy
from .catalog import Catalog
from .config import DEFAULT_SETTINGS, data_dir, default_media_dir, merge_defaults
from .downloads import DownloadManager
from .epg import EpgIndex
from .media import ImageCache, Vendor
from .providers.base import ext_of
from .providers import effective_type, xtream_from_m3u
from .store import JsonStore
from .streamcache import LiveRelays, VodCache
from . import sync as syncmod
from . import update as updmod

WEB_DIR = Path(__file__).parent / "web"
KINDS = ("live", "movie", "series")
USER_DEFAULT = {
    "favorites": {"live": [], "movie": [], "series": []},
    "history": [],
    "recent": [],
    "hidden": {"live": [], "movie": [], "series": []},
    "pinned": {"live": [], "movie": [], "series": []},
}


class ApiError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def lan_addresses():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith("127."))


class App:
    def __init__(self, data=None, password=None, port=8787):
        self.dir = data_dir(data)
        self.port = port
        self.settings_store = JsonStore(self.dir / "settings.json", DEFAULT_SETTINGS)
        self.settings_store.data = merge_defaults(self.settings_store.data, DEFAULT_SETTINGS)
        # 2.0.5: novos padrões aplicados uma única vez (o usuário pode mudar depois)
        if not self.settings_store.data.get("_padroes205"):
            self.settings_store.data["player"]["useProxy"] = False
            self.settings_store.data["player"]["buffer"] = "max"
            self.settings_store.data["_padroes205"] = True
            self.settings_store.save()
        if not self.settings_store.data.get("deviceId"):
            self.settings_store.data["deviceId"] = uuid.uuid4().hex[:12]   # identifica este Sintonia na rede
            self.settings_store.save()
        self.sources = JsonStore(self.dir / "sources.json", {"items": [], "active": None})
        self.parental = JsonStore(self.dir / "parental.json",
                                  {"pinHash": "", "salt": "", "autoAdult": False, "locked": {}})
        self.users = {}
        self.catalogs = {}
        self.epgs = {}
        self.lock = threading.RLock()
        self.images = ImageCache(self.dir / "imagens")
        self.vendor = Vendor(self.dir / "vendor", WEB_DIR / "vendor")
        self.downloads = DownloadManager(self.dir, self.resolve, self.settings)
        self.vodcache = VodCache(self.dir / "cache" / "video")
        self.relays = LiveRelays()
        self.syncer = syncmod.Syncer(self)
        self.password = password or ""
        self.secret = secrets.token_hex(16)
        net.set_user_agent(self.settings()["player"].get("userAgent", ""))
        threading.Thread(target=self.vendor.prefetch, daemon=True).start()
        threading.Thread(target=self._warm_active, daemon=True).start()
        # 2.3.0: anuncia este Sintonia na rede (mDNS) para a sincronização achar na hora
        try:
            from . import mdns
            mdns.Responder(self.port, self.settings().get("deviceId", ""), self.device_name(), lan_addresses).start()
        except Exception:  # noqa: BLE001
            pass

    def _warm_active(self):
        """2.3.0: canais, filmes e séries da lista em uso já ficam prontos ao abrir o app."""
        src_id = self.sources.data.get("active")
        if not src_id:
            return
        try:
            self.catalog(src_id).warm()
        except Exception:  # noqa: BLE001
            pass

    def device_name(self):
        import platform
        name = os.environ.get("SINTONIA_NOME") or platform.node()
        if not name or name == "localhost":
            name = "Android" if os.environ.get("ANDROID_ROOT") else ("Windows" if os.name == "nt" else "Linux")
        return name

    # --- configurações ----------------------------------------------------------
    def settings(self):
        return self.settings_store.data

    def save_settings(self, patch):
        def apply(data):
            merged = merge_defaults(patch, data)
            data.clear()
            data.update(merge_defaults(merged, DEFAULT_SETTINGS))
            return data
        out = self.settings_store.update(apply)
        net.set_user_agent(out["player"].get("userAgent", ""))
        for c in self.catalogs.values():
            c.ttl = int(out.get("cacheHours", 12)) * 3600
        return out

    # --- fontes ----------------------------------------------------------------
    def source(self, src_id):
        for s in self.sources.data["items"]:
            if s["id"] == src_id:
                return s
        raise ApiError("Fonte não encontrada", 404)

    def catalog(self, src_id):
        with self.lock:
            cat = self.catalogs.get(src_id)
            if cat is None:
                src = self.source(src_id)
                cat = Catalog(src, self.dir / "cache" / src_id, int(self.settings().get("cacheHours", 12)))
                self.catalogs[src_id] = cat
            return cat

    def epg(self, src_id):
        with self.lock:
            e = self.epgs.get(src_id)
            if e is None:
                e = EpgIndex(self.dir / "cache" / src_id, src_id)
                self.epgs[src_id] = e
            return e

    def epg_url(self, src_id):
        src = self.source(src_id)
        if src.get("epgUrl"):
            return src["epgUrl"]
        try:
            return self.catalog(src_id).provider.epg_url()
        except Exception:  # noqa: BLE001
            return None

    def ensure_epg(self, src_id, force=False):
        if not self.settings()["epg"].get("enabled", True):
            return self.epg(src_id)
        e = self.epg(src_id)
        e.ensure(self.epg_url(src_id), int(self.settings()["epg"].get("refreshHours", 12)), force)
        return e

    def save_source(self, body):
        typ = body.get("type")
        if typ not in ("xtream", "m3u", "stalker"):
            raise ApiError("Escolha o tipo da fonte")
        url = (body.get("url") or "").strip()
        if not url:
            raise ApiError("Informe o endereço do servidor ou da lista")
        if typ == "xtream" and not (body.get("username") and body.get("password")):
            raise ApiError("Informe usuário e senha")
        if typ == "stalker" and not re.fullmatch(r"([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}", (body.get("mac") or "").strip()):
            raise ApiError("Informe um endereço MAC válido, como 00:1A:79:12:34:56")
        src_id = body.get("id") or uuid.uuid4().hex[:8]
        src = {
            "id": src_id, "type": typ, "name": (body.get("name") or "").strip() or "Minha lista",
            "url": url, "username": (body.get("username") or "").strip(),
            "password": body.get("password") or "", "mac": (body.get("mac") or "").strip().upper(),
            "epgUrl": (body.get("epgUrl") or "").strip(), "ua": (body.get("ua") or "").strip(),
            "created": int(time.time()),
        }
        # valida antes de salvar
        test = Catalog(src, self.dir / "cache" / f"_teste_{src_id}", 1)
        try:
            if typ == "m3u" and effective_type(src) == "xtream":
                test.provider.account()  # link de painel Xtream: valida pelo login
            elif typ == "m3u":
                data = test.provider.load("live")
                if not any(test.provider.load(k)["items"] for k in KINDS):
                    raise ApiError("A lista foi lida, mas não tem nenhum canal ou vídeo")
                del data
            else:
                test.provider.account()
        except ApiError:
            raise
        except net.FetchError as exc:
            raise ApiError(str(exc)) from exc
        except Exception as exc:  # noqa: BLE001
            raise ApiError(f"Não foi possível usar esta fonte: {exc}") from exc
        finally:
            _rmtree(self.dir / "cache" / f"_teste_{src_id}")

        def apply(data):
            items = data["items"]
            for i, s in enumerate(items):
                if s["id"] == src_id:
                    src["created"] = s.get("created", src["created"])
                    items[i] = src
                    break
            else:
                items.append(src)
            if not data.get("active"):
                data["active"] = src_id
        self.sources.update(apply)
        with self.lock:
            old = self.catalogs.pop(src_id, None)
            if old:
                old.invalidate()
            self.epgs.pop(src_id, None)
        return src

    def delete_source(self, src_id):
        def apply(data):
            data["items"] = [s for s in data["items"] if s["id"] != src_id]
            if data.get("active") == src_id:
                data["active"] = data["items"][0]["id"] if data["items"] else None
        self.sources.update(apply)
        with self.lock:
            self.catalogs.pop(src_id, None)
            self.epgs.pop(src_id, None)
            self.users.pop(src_id, None)
        _rmtree(self.dir / "cache" / src_id)
        try:
            (self.dir / "usuarios" / f"{src_id}.json").unlink()
        except OSError:
            pass

    # --- dados do usuário por fonte ------------------------------------------------
    def user(self, src_id):
        with self.lock:
            u = self.users.get(src_id)
            if u is None:
                u = JsonStore(self.dir / "usuarios" / f"{src_id}.json", USER_DEFAULT)
                u.data = merge_defaults(u.data, USER_DEFAULT)
                self.users[src_id] = u
            return u

    # --- reprodução --------------------------------------------------------------
    def resolve(self, src_id, kind, ref, fmt=None):
        src = self.source(src_id)
        cat = self.catalog(src_id)
        item = dict(ref)
        if kind in ("live", "movie"):
            found = cat.find(kind, str(ref.get("id")))
            if found:
                item = {**found, **{k: v for k, v in ref.items() if v not in (None, "")}}
        try:
            url = cat.provider.stream_url(kind, item, fmt)
        except net.FetchError as exc:
            raise ApiError(str(exc)) from exc
        except (ValueError, KeyError) as exc:
            raise ApiError("Este item não tem um endereço reproduzível") from exc
        return url, self.ua_for(src_id, item)

    def ua_for(self, src_id, item=None):
        src = self.source(src_id)
        ua = src.get("ua") or (item or {}).get("ua") or self.settings()["player"].get("userAgent") or ""
        if src.get("type") == "stalker" and not ua:
            from .providers.stalker import MAG_UA
            ua = MAG_UA
        return ua

    def play_info(self, src_id, kind, ref, fmt=None, reserve=True, ua_alt=False):
        if kind == "live" and not fmt:
            fmt = self.settings()["player"].get("liveFormat", "ts")
        if kind == "live" and not reserve:
            self.relays.stop_idle()
        url, ua = self.resolve(src_id, kind, ref, fmt)
        out = self.wrap_stream(src_id, url, ua, live=kind == "live", reserve=reserve, ua_alt=ua_alt)
        out["format"] = fmt
        return out

    def wrap_stream(self, src_id, url, ua, live, reserve=True, ua_alt=False):
        """Escolhe como o navegador vai receber o vídeo, conforme o modo de estabilidade."""
        ext = ext_of(url)
        if ext in ("m3u8", "m3u"):
            typ = "hls"
        elif ext == "ts":
            typ = "ts"
        elif ext in ("mp4", "m4v", "mkv", "webm", "mov", "avi", "mp3", "aac", "ogg"):
            typ = "native"
        else:
            typ = "auto"
        player = self.settings()["player"]
        mode = player.get("buffer", "max")
        use_proxy = player.get("useProxy", True)
        pid = src_id
        if ua_alt:  # segunda tentativa com User-Agent de navegador
            ua = net.BROWSER_UA
            pid = src_id + "~b"
        out = {"url": proxy.proxied(pid, url) if use_proxy or ua_alt else url, "direct": url, "type": typ,
               "live": live, "mode": mode, "reserve": None, "ua": "navegador" if ua_alt else (ua or net.user_agent())}
        if not reserve:
            pass
        elif live and mode in ("max", "ultra") and typ in ("ts", "auto"):
            self.vodcache.stop_all()  # a conta pode ter só 1 conexão: libera a do filme
            r = self.relays.start(url, ua, 15 if mode == "ultra" else 5, 160 if mode == "ultra" else 64)
            out.update(url=f"/relay/{r.id}/{proxy.basename(url, 'canal').rsplit('.', 1)[0]}.ts", type="ts",
                       reserve={"kind": "live", "id": r.id, "cushion": r.cushion})
        elif not live and mode in ("high", "max", "ultra") and typ in ("native", "ts", "auto"):
            # reserva no servidor: uma só conexão com o provedor, baixando à frente na velocidade
            # máxima e retomando do mesmo byte se a internet cair
            self.relays.stop_all()
            ahead = {"high": 160, "max": 900}.get(mode)
            job = self.vodcache.start(url, ua, ahead * 1024 * 1024 if ahead else None)
            out.update(url=f"/vod/{job.id}/{proxy.basename(url)}", type="ts" if typ == "ts" else ("native" if typ == "auto" else typ),
                       reserve={"kind": "vod", "id": job.id})
        return out

    # --- controle parental -----------------------------------------------------------
    def _hash_pin(self, pin, salt):
        return hashlib.sha256((salt + str(pin)).encode()).hexdigest()

    def check_pin(self, pin):
        p = self.parental.data
        if not p.get("pinHash"):
            return True
        return hmac.compare_digest(p["pinHash"], self._hash_pin(pin or "", p.get("salt", "")))

    def parental_public(self):
        p = self.parental.data
        return {"hasPin": bool(p.get("pinHash")), "autoAdult": bool(p.get("autoAdult")),
                "locked": p.get("locked", {})}

    # --- estado geral ------------------------------------------------------------------
    def state(self):
        return {
            "version": VERSION,
            "settings": self.settings(),
            "sources": [{**s, "engine": effective_type(s)} for s in self.sources.data["items"]],
            "active": self.sources.data.get("active"),
            "parental": self.parental_public(),
            "urls": [f"http://{ip}:{self.port}" for ip in lan_addresses()],
            "port": self.port,
            "mediaDir": default_media_dir(),
            "device": self.device_name(),
            "platform": "windows" if os.name == "nt" else "linux",
            "dataDir": str(self.dir),
        }


def _rmtree(path):
    path = Path(path)
    if not path.exists():
        return
    for root, dirs, files in os.walk(path, topdown=False):
        for f in files:
            try:
                os.unlink(os.path.join(root, f))
            except OSError:
                pass
        for d in dirs:
            try:
                os.rmdir(os.path.join(root, d))
            except OSError:
                pass
    try:
        os.rmdir(path)
    except OSError:
        pass


# ======================================================================================
# Rotas
# ======================================================================================

ROUTES = []


def route(method, pattern):
    rx = re.compile("^" + pattern + "$")

    def deco(fn):
        ROUTES.append((method, rx, fn))
        return fn
    return deco


def _now():
    return int(time.time())


@route("GET", r"/api/state")
def r_state(app, h, m, q, body):
    return app.state()


@route("POST", r"/api/login")
def r_login(app, h, m, q, body):
    if not app.password:
        return {"ok": True}
    if not hmac.compare_digest(str(body.get("password", "")), app.password):
        raise ApiError("Senha incorreta", 401)
    h.set_cookie = h.auth_token()
    return {"ok": True}


@route("POST", r"/api/settings")
def r_settings(app, h, m, q, body):
    return app.save_settings(body)


@route("POST", r"/api/sources")
def r_save_source(app, h, m, q, body):
    return app.save_source(body)


# ---- exportar / importar listas (arquivo, texto ou QR) ----
EXPORT_KEYS = ("type", "name", "url", "username", "password", "mac", "epgUrl", "ua")


@route("GET", r"/api/sources/export")
def r_export_sources(app, h, m, q, body):
    ids = [x for x in (q.get("ids") or "").split(",") if x]
    out = []
    for s in app.sources.data["items"]:
        if ids and s["id"] not in ids:
            continue
        out.append({k: s.get(k) for k in EXPORT_KEYS if s.get(k)})
    return {"sintonia": "lista", "v": 1, "sources": out}


@route("POST", r"/api/sources/import")
def r_import_sources(app, h, m, q, body):
    """Adiciona listas exportadas por outro Sintonia (sem duplicar as que já existem)."""
    items = body.get("sources") or []
    if body.get("m3uText"):
        # arquivo .m3u escolhido no aparelho: guarda uma cópia e usa o caminho como endereço
        folder = app.dir / "listas"
        folder.mkdir(parents=True, exist_ok=True)
        fid = uuid.uuid4().hex[:8]
        path = folder / f"{fid}.m3u"
        path.write_text(body["m3uText"], encoding="utf-8")
        items = [{"type": "m3u", "name": (body.get("name") or "Lista importada").strip(), "url": str(path)}]
    if not isinstance(items, list) or not items:
        raise ApiError("Não encontrei nenhuma lista para importar")
    have = {syncmod.identity(s) for s in app.sources.data["items"]}
    added, skipped, ids = 0, 0, []
    for it in items:
        if not isinstance(it, dict) or it.get("type") not in ("xtream", "m3u", "stalker") or not (it.get("url") or "").strip():
            skipped += 1
            continue
        if syncmod.identity(it) in have:
            skipped += 1
            continue
        src = {k: (it.get(k) or "").strip() if k != "password" else (it.get(k) or "") for k in EXPORT_KEYS}
        src["name"] = src["name"] or "Lista importada"
        src["mac"] = src["mac"].upper()
        src["id"] = uuid.uuid4().hex[:8]
        src["created"] = int(time.time())

        def add(d, src=src):
            d["items"].append(src)
            if not d.get("active"):
                d["active"] = src["id"]
        app.sources.update(add)
        have.add(syncmod.identity(src))
        ids.append(src["id"])
        added += 1
    return {"added": added, "skipped": skipped, "ids": ids, "active": app.sources.data.get("active")}


@route("DELETE", r"/api/sources/(\w+)")
def r_del_source(app, h, m, q, body):
    app.delete_source(m.group(1))
    return {"ok": True, "active": app.sources.data.get("active")}


@route("POST", r"/api/sources/(\w+)/activate")
def r_activate(app, h, m, q, body):
    src_id = m.group(1)
    app.source(src_id)
    app.sources.update(lambda d: d.__setitem__("active", src_id))
    return {"ok": True}


@route("POST", r"/api/sources/(\w+)/refresh")
def r_refresh(app, h, m, q, body):
    src_id = m.group(1)
    app.catalog(src_id).invalidate()
    app.ensure_epg(src_id, force=True)
    return {"ok": True}


@route("GET", r"/api/src/(\w+)/account")
def r_account(app, h, m, q, body):
    try:
        return app.catalog(m.group(1)).account(force=q.get("force") == "1")
    except net.FetchError as exc:
        raise ApiError(str(exc), 502) from exc


@route("GET", r"/api/src/(\w+)/catalog/(live|movie|series)")
def r_catalog(app, h, m, q, body):
    cat = app.catalog(m.group(1))
    kind = m.group(2)
    try:
        data = cat.get(kind, q.get("cat") or None, force=q.get("force") == "1")
    except net.FetchError as exc:
        raise ApiError(str(exc), 502) from exc
    if kind == "live":
        app.ensure_epg(m.group(1))
    return {"categories": data["categories"], "items": data["items"], "lazy": cat.is_lazy(kind)}


@route("GET", r"/api/src/(\w+)/(movie|series)/([^/]+)")
def r_details(app, h, m, q, body):
    try:
        return app.catalog(m.group(1)).details(m.group(2), urllib.parse.unquote(m.group(3)))
    except net.FetchError as exc:
        raise ApiError(str(exc), 502) from exc


@route("POST", r"/api/src/(\w+)/play")
def r_play(app, h, m, q, body):
    kind = body.get("kind")
    if kind not in ("live", "movie", "episode"):
        raise ApiError("Tipo inválido")
    return app.play_info(m.group(1), kind, body.get("ref") or {}, body.get("fmt"), not body.get("noReserve"),
                         bool(body.get("uaAlt")))


@route("POST", r"/api/src/(\w+)/catchup")
def r_catchup(app, h, m, q, body):
    src_id = m.group(1)
    cat = app.catalog(src_id)
    item = cat.find("live", str(body.get("id"))) or body.get("ref") or {}
    start, stop = int(body.get("start", 0)), int(body.get("stop", 0))
    offset = int(app.settings()["epg"].get("offsetMinutes", 0)) * 60
    minutes = max(1, (stop - start) // 60)
    url = cat.provider.catchup_url(item, start - offset, minutes)
    if not url:
        raise ApiError("Este canal não tem replay disponível")
    return app.wrap_stream(src_id, url, app.ua_for(src_id, item), live=False)


def _match_channels(epg, channels):
    """Associa cada canal ao id do XMLTV (pelo tvg-id ou pelo nome)."""
    names = None
    out = {}
    for ch in channels:
        key = ch.get("epg") or ""
        if key and key in epg.progs:
            out[ch["id"]] = key
            continue
        if names is None:
            names = {}
            for cid, nm in epg.names.items():
                names.setdefault(_norm(nm), cid)
        k = _norm(ch.get("name", ""))
        if k in names:
            out[ch["id"]] = names[k]
    return out


def _norm(name):
    name = name.lower()
    name = re.sub(r"\b(fhd|uhd|hd|sd|4k|h265|hevc|\[.*?\]|\(.*?\))\b", " ", name)
    return re.sub(r"[^a-z0-9]+", "", name)


@route("POST", r"/api/src/(\w+)/epg/now")
def r_epg_now(app, h, m, q, body):
    epg = app.ensure_epg(m.group(1))
    offset = int(app.settings()["epg"].get("offsetMinutes", 0)) * 60
    mapping = _match_channels(epg, body.get("channels") or [])
    nn = epg.now_next(set(mapping.values()), offset)
    return {"status": epg.status(), "data": {cid: nn[x] for cid, x in mapping.items() if x in nn}}


@route("POST", r"/api/src/(\w+)/epg/grid")
def r_epg_grid(app, h, m, q, body):
    epg = app.ensure_epg(m.group(1))
    offset = int(app.settings()["epg"].get("offsetMinutes", 0)) * 60
    start, end = int(body.get("from", _now() - 3600)), int(body.get("to", _now() + 6 * 3600))
    mapping = _match_channels(epg, body.get("channels") or [])
    return {"status": epg.status(),
            "data": {cid: epg.programmes(x, start, end, offset) for cid, x in mapping.items()}}


@route("POST", r"/api/src/(\w+)/epg/channel")
def r_epg_channel(app, h, m, q, body):
    src_id = m.group(1)
    epg = app.ensure_epg(src_id)
    offset = int(app.settings()["epg"].get("offsetMinutes", 0)) * 60
    ch = body.get("channel") or {}
    start = int(body.get("from", _now() - 2 * 86400))
    end = int(body.get("to", _now() + 86400))
    mapping = _match_channels(epg, [ch])
    progs = epg.programmes(mapping[ch["id"]], start, end, offset) if ch.get("id") in mapping else []
    if not progs:
        try:
            cat = app.catalog(src_id)
            item = cat.find("live", str(ch.get("id"))) or ch
            progs = cat.provider.short_epg(item, 20)
        except Exception:  # noqa: BLE001
            progs = []
    return {"status": epg.status(), "data": progs}


@route("GET", r"/api/src/(\w+)/epg/status")
def r_epg_status(app, h, m, q, body):
    return app.epg(m.group(1)).status()


@route("POST", r"/api/src/(\w+)/epg/refresh")
def r_epg_refresh(app, h, m, q, body):
    return app.ensure_epg(m.group(1), force=True).status()


@route("GET", r"/api/src/(\w+)/epg/search")
def r_epg_search(app, h, m, q, body):
    epg = app.ensure_epg(m.group(1))
    offset = int(app.settings()["epg"].get("offsetMinutes", 0)) * 60
    return {"status": epg.status(), "data": epg.search(q.get("q", ""), offset),
            "names": {}}


@route("GET", r"/api/src/(\w+)/cast")
def r_cast(app, h, m, q, body):
    return app.catalog(m.group(1)).search_cast(q.get("q", ""))


@route("GET", r"/api/stream/(live|vod)/(\w+)")
def r_stream_status(app, h, m, q, body):
    obj = (app.relays if m.group(1) == "live" else app.vodcache).get(m.group(2))
    if not obj:
        raise ApiError("Reserva encerrada", 404)
    return obj.status()


# --- reiniciar (para aplicar atualizações sem fechar nada) ------------------------------

@route("POST", r"/api/restart")
def r_restart(app, h, m, q, body):
    import subprocess
    import sys
    env = dict(os.environ, SINTONIA_REINICIO="1")
    args = [sys.executable, "-m", "sintonia"] + [a for a in sys.argv[1:] if a not in ("--abrir", "--janela")]
    flags = 0
    if os.name == "nt":
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    subprocess.Popen(args, cwd=os.getcwd(), env=env, close_fds=True, creationflags=flags,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
    threading.Timer(0.7, lambda: os._exit(0)).start()
    return {"ok": True}


@route("GET", r"/api/update/check")
def r_update_check(app, h, m, q, body):
    return updmod.check(force=q.get("force") == "1")


@route("POST", r"/api/update/apply")
def r_update_apply(app, h, m, q, body):
    """Atualiza pelo GitHub e reabre o Sintonia (só pedido deste aparelho)."""
    if h.client_address[0] not in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
        raise ApiError("A atualização só pode ser feita no próprio aparelho", 403)
    try:
        ver = updmod.apply()
    except updmod.UpdateError as exc:
        raise ApiError(str(exc)) from exc
    updmod.restart_soon()
    return {"ok": True, "version": ver}


@route("POST", r"/api/quit")
def r_quit(app, h, m, q, body):
    """Encerra o servidor (usado pelo atalho "Parar o Sintonia"). Só aceita pedidos deste aparelho."""
    if h.client_address[0] not in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
        raise ApiError("Só pode ser parado no próprio aparelho", 403)
    threading.Timer(0.4, lambda: os._exit(0)).start()
    return {"ok": True}


# --- diagnóstico de canal ---------------------------------------------------------------

def _mask(url, src):
    out = url
    extra = xtream_from_m3u(src.get("url")) or {}
    for secret in (src.get("password"), src.get("username"), extra.get("password"), extra.get("username")):
        if secret and len(secret) > 2:
            out = out.replace(urllib.parse.quote(secret, safe=""), "•••").replace(secret, "•••")
    return out


def _probe(url, ua):
    t0 = time.time()
    r = {"ua": "VLC" if "VLC" in (ua or "") else ("navegador" if "Mozilla" in (ua or "") else (ua or "padrão")[:30])}
    try:
        with net.open_url(url, headers={"User-Agent": ua} if ua else None, timeout=10) as resp:
            head = resp.read(4096)
            r.update(status=getattr(resp, "status", 200), ctype=resp.headers.get("Content-Type", ""),
                     final=resp.geturl(), bytes=len(head))
            if head[:1] == b"\x47" and (len(head) < 189 or head[188:189] == b"\x47"):
                r["kind"] = "vídeo MPEG-TS válido"
            elif head.lstrip()[:7] == b"#EXTM3U":
                r["kind"] = "playlist HLS"
            elif not head:
                r["kind"] = "resposta vazia"
            else:
                r["kind"] = "conteúdo inesperado: " + head[:120].decode("utf-8", "replace").replace("\n", " ")
    except urllib.error.HTTPError as exc:
        r.update(status=exc.code, kind=f"recusado ({exc.code} {exc.reason})")
    except Exception as exc:  # noqa: BLE001
        r.update(status=0, kind=f"sem resposta: {exc}")
    r["ms"] = int((time.time() - t0) * 1000)
    return r


@route("POST", r"/api/src/(\w+)/diagnose")
def r_diagnose(app, h, m, q, body):
    src_id = m.group(1)
    src = app.source(src_id)
    ref = {"id": str(body.get("id")), "cmd": body.get("cmd")}
    tests = []
    for fmt in ("ts", "m3u8"):
        try:
            url, ua = app.resolve(src_id, "live", ref, fmt)
        except ApiError as exc:
            tests.append({"fmt": fmt, "kind": str(exc)})
            continue
        uas = [ua or net.user_agent()]
        if net.BROWSER_UA not in uas:
            uas.append(net.BROWSER_UA)
        for u in uas:
            r = _probe(url, u)
            r.update(fmt=fmt.upper(), url=_mask(url, src), final=_mask(r.get("final") or "", src))
            tests.append(r)
        if effective_type(src) == "m3u":
            break
    vendor = {n: bool(app.vendor.get(n)) for n in ("hls.min.js", "mpegts.js")}
    return {"tests": tests, "vendor": vendor, "proxy": app.settings()["player"].get("useProxy", True),
            "buffer": app.settings()["player"].get("buffer"), "ua": app.settings()["player"].get("userAgent") or net.user_agent()}


# --- sincronização opcional -----------------------------------------------------------

@route("GET", r"/api/sync/export")
def r_sync_export(app, h, m, q, body):
    if not app.settings().get("sync", {}).get("enabled"):
        raise ApiError("A sincronização está desligada no outro aparelho. Ligue em Menu › Sincronizar aparelhos.", 403)
    return syncmod.export(app)


@route("POST", r"/api/sync/import")
def r_sync_import(app, h, m, q, body):
    cfg = app.settings().get("sync", {})
    if not cfg.get("enabled"):
        raise ApiError("A sincronização está desligada neste aparelho", 403)
    try:
        return syncmod.merge(app, body, cfg.get("items") or {})
    except syncmod.SyncError as exc:
        raise ApiError(str(exc)) from exc


@route("GET", r"/api/sync/hello")
def r_sync_hello(app, h, m, q, body):
    return syncmod.hello(app)


@route("GET", r"/api/sync/whoami")
def r_sync_whoami(app, h, m, q, body):
    """Endereço deste Sintonia na rede (para o QR de parear)."""
    return {"self": syncmod.hello(app), "urls": [f"{ip}:{app.port}" for ip in lan_addresses()]}


@route("POST", r"/api/sync/discover")
def r_sync_discover(app, h, m, q, body):
    return {"devices": syncmod.discover(app, lan_addresses()), "self": syncmod.hello(app),
            "urls": [f"{ip}:{app.port}" for ip in lan_addresses()]}


@route("POST", r"/api/sync/test")
def r_sync_test(app, h, m, q, body):
    try:
        return syncmod.test({**app.settings().get("sync", {}), **body})
    except syncmod.SyncError as exc:
        raise ApiError(str(exc), 502) from exc


@route("POST", r"/api/sync/now")
def r_sync_now(app, h, m, q, body):
    try:
        result = app.syncer.run()
    except syncmod.SyncError as exc:
        raise ApiError(str(exc), 502) from exc
    with app.lock:
        app.catalogs.clear()
    return result


# --- dados do usuário ---------------------------------------------------------------

@route("GET", r"/api/src/(\w+)/user")
def r_user(app, h, m, q, body):
    return app.user(m.group(1)).data


@route("POST", r"/api/src/(\w+)/user/fav")
def r_fav(app, h, m, q, body):
    kind, item_id, on = body.get("kind"), str(body.get("id")), bool(body.get("on"))
    if kind not in KINDS:
        raise ApiError("Tipo inválido")

    def apply(d):
        lst = d["favorites"].setdefault(kind, [])
        if on and item_id not in lst:
            lst.insert(0, item_id)
        if not on and item_id in lst:
            lst.remove(item_id)
        return d["favorites"]
    return app.user(m.group(1)).update(apply)


@route("POST", r"/api/src/(\w+)/user/progress")
def r_progress(app, h, m, q, body):
    kind = body.get("kind")
    if kind not in ("movie", "episode"):
        raise ApiError("Tipo inválido")
    entry = {k: body.get(k) for k in ("kind", "id", "name", "img", "pos", "dur", "seriesId", "seriesName",
                                       "season", "episode", "ext", "ref")}
    entry["id"] = str(entry["id"])
    entry["ts"] = _now()

    def apply(d):
        hist = [x for x in d["history"] if not (x.get("kind") == kind and str(x.get("id")) == entry["id"])]
        hist.insert(0, entry)
        d["history"] = hist[:300]
        return entry
    return app.user(m.group(1)).update(apply)


@route("POST", r"/api/src/(\w+)/user/forget")
def r_forget(app, h, m, q, body):
    ids = {str(x) for x in body.get("ids") or []}

    def apply(d):
        d["history"] = [x for x in d["history"] if str(x.get("id")) not in ids and str(x.get("seriesId")) not in ids]
        return d["history"]
    return app.user(m.group(1)).update(apply)


@route("POST", r"/api/src/(\w+)/user/recent")
def r_recent(app, h, m, q, body):
    item_id = str(body.get("id"))

    def apply(d):
        d["recent"] = [item_id] + [x for x in d["recent"] if x != item_id][:24]
        return d["recent"]
    return app.user(m.group(1)).update(apply)


@route("POST", r"/api/src/(\w+)/user/recent/remove")
def r_recent_remove(app, h, m, q, body):
    item_id = str(body.get("id"))

    def apply(d):
        d["recent"] = [x for x in d["recent"] if x != item_id]
        return d["recent"]
    return app.user(m.group(1)).update(apply)


@route("POST", r"/api/src/(\w+)/user/clear")
def r_clear(app, h, m, q, body):
    what = body.get("what", "all")

    def apply(d):
        if what in ("live", "all"):
            d["recent"] = []
        if what in ("movie", "all"):
            d["history"] = [x for x in d["history"] if x.get("kind") != "movie"]
        if what in ("series", "all"):
            d["history"] = [x for x in d["history"] if x.get("kind") != "episode"]
        return d
    return app.user(m.group(1)).update(apply)


def _toggle_list(field):
    def handler(app, h, m, q, body):
        kind, cat, on = body.get("kind"), str(body.get("cat")), bool(body.get("on"))
        if kind not in KINDS:
            raise ApiError("Tipo inválido")

        def apply(d):
            lst = d[field].setdefault(kind, [])
            if on and cat not in lst:
                lst.append(cat)
            if not on and cat in lst:
                lst.remove(cat)
            return d[field]
        return app.user(m.group(1)).update(apply)
    return handler


route("POST", r"/api/src/(\w+)/user/hidden")(_toggle_list("hidden"))
route("POST", r"/api/src/(\w+)/user/pinned")(_toggle_list("pinned"))


@route("POST", r"/api/src/(\w+)/user/hidden-bulk")
def r_hidden_bulk(app, h, m, q, body):
    kind = body.get("kind")
    if kind not in KINDS:
        raise ApiError("Tipo inválido")
    cats = [str(c) for c in body.get("cats") or []]

    def apply(d):
        d["hidden"][kind] = cats
        return d["hidden"]
    return app.user(m.group(1)).update(apply)


# --- controle parental ------------------------------------------------------------------

@route("POST", r"/api/parental/verify")
def r_pin_verify(app, h, m, q, body):
    return {"ok": app.check_pin(body.get("pin"))}


@route("POST", r"/api/parental/pin")
def r_pin_set(app, h, m, q, body):
    if not app.check_pin(body.get("old")):
        raise ApiError("O PIN atual está incorreto", 403)
    new = str(body.get("new") or "")
    if new and not re.fullmatch(r"\d{4,8}", new):
        raise ApiError("O PIN precisa ter de 4 a 8 números")

    def apply(d):
        if new:
            d["salt"] = secrets.token_hex(8)
            d["pinHash"] = app._hash_pin(new, d["salt"])
        else:
            d["pinHash"], d["salt"], d["locked"], d["autoAdult"] = "", "", {}, False
    app.parental.update(apply)
    return app.parental_public()


@route("POST", r"/api/parental/lock")
def r_pin_lock(app, h, m, q, body):
    if not app.check_pin(body.get("pin")):
        raise ApiError("PIN incorreto", 403)
    src, kind, cat, on = body.get("src"), body.get("kind"), str(body.get("cat")), bool(body.get("on"))

    def apply(d):
        lst = d.setdefault("locked", {}).setdefault(src, {}).setdefault(kind, [])
        if on and cat not in lst:
            lst.append(cat)
        if not on and cat in lst:
            lst.remove(cat)
    app.parental.update(apply)
    return app.parental_public()


@route("POST", r"/api/parental/settings")
def r_pin_settings(app, h, m, q, body):
    if not app.check_pin(body.get("pin")):
        raise ApiError("PIN incorreto", 403)
    app.parental.update(lambda d: d.__setitem__("autoAdult", bool(body.get("autoAdult"))))
    return app.parental_public()


# --- escolher pasta (downloads e gravações) ------------------------------------------------

def _is_local(h):
    ip = (h.client_address[0] or "").replace("::ffff:", "")
    return ip in ("127.0.0.1", "::1") or ip.startswith("127.")


def _writable(path):
    try:
        p = Path(path)
        if not p.is_dir():
            return False
        test = p / f".sintonia-teste-{uuid.uuid4().hex[:6]}"
        test.write_bytes(b"ok")
        test.unlink()
        return True
    except OSError:
        return False


def _places(app):
    """Atalhos para pastas comuns de cada sistema (e pendrives/cartões no Android e no Linux)."""
    out = []

    def add(name, path):
        try:
            if path and os.path.isdir(path) and all(x["path"] != str(path) for x in out):
                out.append({"name": name, "path": str(path)})
        except OSError:
            pass
    try:
        os.makedirs(default_media_dir(), exist_ok=True)
    except OSError:
        pass
    add("Pasta padrão do Sintonia", default_media_dir())
    if os.environ.get("ANDROID_ROOT") or os.environ.get("SINTONIA_MIDIA"):
        # pastas do app em cada armazenamento: gravam sem pedir permissão (inclusive pendrive na TV)
        for i, v in enumerate((os.environ.get("SINTONIA_VOLUMES") or "").split("\n")):
            if v.strip():
                add("Memória interna (pasta do app)" if i == 0 else f"Pendrive / cartão {i} (pasta do app)", v.strip())
        base = "/storage/emulated/0"
        add("Downloads (memória interna)", base + "/Download")
        add("Filmes (memória interna)", base + "/Movies")
        add("Memória interna", base)
        try:
            for d in sorted(os.listdir("/storage")):
                if d not in ("emulated", "self") and os.path.isdir("/storage/" + d):
                    add(f"Pendrive / cartão ({d})", "/storage/" + d)
        except OSError:
            pass
    elif os.name == "nt":
        home = Path.home()
        add("Downloads", home / "Downloads")
        add("Vídeos", home / "Videos")
        add("Área de Trabalho", home / "Desktop")
        import string
        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            if os.path.isdir(drive):
                add(f"Disco {letter}:", drive)
    else:
        home = Path.home()
        add("Pasta pessoal", home)
        add("Downloads", home / "Downloads")
        add("Vídeos", home / "Videos")
        for d in ("/sdcard/Download", "/sdcard", "/media", "/mnt"):
            add(d, d)
        for root in ("/media", "/run/media"):
            try:
                for u in os.listdir(root):
                    for d in os.listdir(os.path.join(root, u)):
                        add(f"Pendrive ({d})", os.path.join(root, u, d))
            except OSError:
                pass
    return out


@route("GET", r"/api/fs/browse")
def r_fs_browse(app, h, m, q, body):
    if not _is_local(h):
        raise ApiError("Escolha a pasta no próprio aparelho onde o Sintonia está instalado", 403)
    path = q.get("path") or ""
    if not path:
        path = app.settings().get("downloadDir") or default_media_dir()
        if not os.path.isdir(path):
            path = os.path.dirname(path) if os.path.isdir(os.path.dirname(path)) else str(Path.home())
    path = os.path.abspath(path)
    try:
        names = sorted((n for n in os.listdir(path) if not n.startswith(".") and os.path.isdir(os.path.join(path, n))),
                       key=str.lower)
        err = ""
    except PermissionError:
        names, err = [], "Sem permissão para abrir esta pasta"
    except OSError as exc:
        names, err = [], str(exc)
    parent = os.path.dirname(path.rstrip("\\/")) or None
    if parent == path:
        parent = None
    return {"path": path, "parent": parent, "dirs": names[:2000], "writable": _writable(path), "error": err,
            "places": _places(app), "sep": os.sep, "android": bool(os.environ.get("SINTONIA_MIDIA"))}


@route("POST", r"/api/fs/mkdir")
def r_fs_mkdir(app, h, m, q, body):
    if not _is_local(h):
        raise ApiError("Só no próprio aparelho", 403)
    parent = body.get("path") or ""
    name = re.sub(r'[\\/:*?"<>|]+', "", (body.get("name") or "").strip())[:80]
    if not name or not os.path.isdir(parent):
        raise ApiError("Nome inválido")
    new = os.path.join(parent, name)
    try:
        os.makedirs(new, exist_ok=True)
    except OSError as exc:
        raise ApiError(f"Não consegui criar a pasta ({exc})") from exc
    return {"path": new}


@route("POST", r"/api/fs/pick")
def r_fs_pick(app, h, m, q, body):
    """Janela "Escolher pasta" do próprio Windows."""
    if os.name != "nt" or not _is_local(h):
        raise ApiError("Disponível só no Windows", 400)
    import base64
    import subprocess
    start = (body.get("path") or "").replace("'", "''")
    ps = ("Add-Type -AssemblyName System.Windows.Forms;[Console]::OutputEncoding=[Text.Encoding]::UTF8;"
          "$d=New-Object System.Windows.Forms.FolderBrowserDialog;$d.Description='Pasta do Sintonia';"
          f"$d.SelectedPath='{start}';$d.ShowNewFolderButton=$true;"
          "$f=New-Object System.Windows.Forms.Form;$f.TopMost=$true;"
          "if($d.ShowDialog($f) -eq 'OK'){$d.SelectedPath}")
    enc = base64.b64encode(ps.encode("utf-16-le")).decode()
    r = subprocess.run(["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                       capture_output=True, timeout=600, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return {"path": r.stdout.decode("utf-8", "replace").strip().lstrip("\ufeff")}


# --- player nativo do Android TV (ExoPlayer) ------------------------------------------------

@route("POST", r"/api/src/(\w+)/native")
def r_native(app, h, m, q, body):
    """Endereços diretos do provedor para o player nativo da TV (com a lista de canais para trocar no controle)."""
    src_id = m.group(1)
    kind = body.get("kind")
    if kind not in ("live", "movie", "episode"):
        raise ApiError("Tipo inválido")
    ref = body.get("ref") or {}
    pref = app.settings()["player"].get("liveFormat", "ts")
    other = "m3u8" if pref == "ts" else "ts"
    url, ua = app.resolve(src_id, kind, ref, pref if kind == "live" else None)
    out = {"url": url, "ua": ua, "alt": "", "channels": []}
    if kind == "live":
        cat = app.catalog(src_id)
        prov = cat.provider
        try:
            out["alt"] = prov.stream_url("live", cat.find("live", str(ref.get("id"))) or ref, other)
        except Exception:  # noqa: BLE001
            pass
        cheap = effective_type(app.source(src_id)) != "stalker"   # no Stalker cada endereço é uma consulta
        # endereços montados direto (sem consultar nada): a lista inteira fica pronta em milissegundos
        for c in (body.get("list") or [])[:400]:
            cid = str(c.get("id"))
            if not cheap and cid != str(ref.get("id")):
                continue
            item = cat.find("live", cid) or {"id": cid}
            try:
                u = url if cid == str(ref.get("id")) else prov.stream_url("live", item, pref)
                a = prov.stream_url("live", item, other)
            except Exception:  # noqa: BLE001
                continue
            out["channels"].append({"id": cid, "name": c.get("name") or "", "url": u, "alt": a, "fav": bool(c.get("fav"))})
    return out


# --- downloads e gravações ---------------------------------------------------------------

@route("GET", r"/api/downloads")
def r_downloads(app, h, m, q, body):
    return app.downloads.list()


@route("POST", r"/api/downloads")
def r_add_download(app, h, m, q, body):
    kind = body.get("kind")
    if kind not in ("movie", "episode"):
        raise ApiError("Só filmes e episódios podem ser baixados")
    app.source(body.get("src"))
    return app.downloads.add(body["src"], kind, body.get("ref") or {}, body.get("meta") or {})


@route("POST", r"/api/recordings")
def r_add_recording(app, h, m, q, body):
    app.source(body.get("src"))
    minutes = int(body.get("minutes") or 0) or None
    return app.downloads.add(body["src"], "live", body.get("ref") or {}, body.get("meta") or {}, minutes)


@route("POST", r"/api/downloads/(\w+)/stop")
def r_stop_download(app, h, m, q, body):
    return {"ok": app.downloads.stop(m.group(1))}


@route("POST", r"/api/downloads/(\w+)/retry")
def r_retry_download(app, h, m, q, body):
    return {"ok": app.downloads.retry(m.group(1))}


@route("DELETE", r"/api/downloads/(\w+)")
def r_del_download(app, h, m, q, body):
    return {"ok": app.downloads.delete(m.group(1), q.get("keep") != "1")}


# ======================================================================================
# Handler HTTP
# ======================================================================================

STATIC_TYPES = {
    ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8", ".webmanifest": "application/manifest+json",
    ".svg": "image/svg+xml", ".png": "image/png", ".json": "application/json",
    ".woff2": "font/woff2", ".ico": "image/x-icon",
}


class Handler(BaseHTTPRequestHandler):
    server_version = "Sintonia/" + VERSION
    protocol_version = "HTTP/1.1"
    app = None  # definido em make_server

    def log_message(self, fmt, *args):  # silencioso; erros vão para stderr pelo except
        pass

    def auth_token(self):
        return hmac.new(self.app.secret.encode(), self.app.password.encode(), "sha256").hexdigest()

    def authed(self):
        if not self.app.password:
            return True
        hdr = self.headers.get("X-Sintonia-Senha")
        if hdr and hmac.compare_digest(hdr, self.app.password):
            return True
        cookie = self.headers.get("Cookie", "")
        m = re.search(r"sintonia_auth=([0-9a-f]+)", cookie)
        return bool(m) and hmac.compare_digest(m.group(1), self.auth_token())

    # --- respostas ------------------------------------------------------------
    def _loopback(self):
        ip = (self.client_address[0] or "").replace("::ffff:", "")
        return ip.startswith("127.") or ip == "::1"

    def send_json(self, data, status=200):
        raw = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        # no próprio aparelho (app Android, janela do PC) comprimir só gasta processador
        gz = "gzip" in self.headers.get("Accept-Encoding", "") and len(raw) > 2048 and not self._loopback()
        if gz:
            raw = gzip.compress(raw, 5)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        if gz:
            self.send_header("Content-Encoding", "gzip")
        if self.path.startswith("/api/sync/"):
            self.send_header("Access-Control-Allow-Origin", "*")
        if getattr(self, "set_cookie", None):
            self.send_header("Set-Cookie", f"sintonia_auth={self.set_cookie}; Path=/; Max-Age=31536000; SameSite=Lax")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def send_bytes(self, data, ctype, cache="no-cache", status=200):
        gz = ctype.startswith(("text/", "application/json", "application/manifest", "image/svg")) \
            and "gzip" in self.headers.get("Accept-Encoding", "") and len(data) > 1024 and not self._loopback()
        if gz:
            data = _gz_cached(data)
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", cache)
        etag = getattr(self, "_etag", None)
        if etag:
            self.send_header("ETag", etag)
            self._etag = None
        if gz:
            self.send_header("Content-Encoding", "gzip")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def send_file_range(self, path, ctype):
        size = os.path.getsize(path)
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        status = 200
        if rng:
            mm = re.match(r"bytes=(\d*)-(\d*)", rng)
            if mm:
                if mm.group(1):
                    start = int(mm.group(1))
                    if mm.group(2):
                        end = min(int(mm.group(2)), size - 1)
                elif mm.group(2):
                    start = max(0, size - int(mm.group(2)))
                status = 206
        if start > end:
            self.send_response(416)
            self.send_header("Content-Range", f"bytes */{size}")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(path, "rb") as fh:
                fh.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = fh.read(min(256 * 1024, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, OSError):
            self.close_connection = True

    # --- métodos --------------------------------------------------------------
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Range, X-Sintonia-Senha")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def lan_blocked(self, path):
        """Acesso de outro aparelho da rede só se a caixa estiver marcada (a sincronização tem a própria chave)."""
        ip = (self.client_address[0] or "").replace("::ffff:", "")
        if ip in ("127.0.0.1", "::1", "localhost") or ip.startswith("127."):
            return False
        st = self.app.settings()
        if (st.get("network") or {}).get("allowLan"):
            return False
        if path.startswith("/api/sync/") and (st.get("sync") or {}).get("enabled"):
            return False
        return True

    def _dispatch(self, method):
        self.set_cookie = None
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        if self.lan_blocked(path):
            body = ("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width'>"
                    "<body style='font-family:system-ui;background:#0b0e14;color:#eef2f8;padding:40px;line-height:1.5'>"
                    "<h2>Este Sintonia não está liberado para outros aparelhos</h2>"
                    "<p>No aparelho onde o Sintonia está aberto, vá em <b>Menu › Instalar e outros aparelhos</b> e marque "
                    "<b>Permitir que outros aparelhos da rede usem este Sintonia</b>.</p>").encode("utf-8")
            self.send_response(403)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        query = {k: v[-1] for k, v in urllib.parse.parse_qs(parsed.query).items()}
        try:
            if path.startswith("/api/"):
                return self._api(method, path, query)
            if path.startswith("/p/"):
                if not self.authed():
                    return self.send_error(401)
                parts = path.split("/", 4)
                if len(parts) < 4:
                    return self.send_error(404)
                src_id, _, alt = parts[2].partition("~")
                token = parts[3]
                ua = ""
                try:
                    src = self.app.source(src_id)
                    ua = src.get("ua") or self.app.settings()["player"].get("userAgent") or ""
                    if src.get("type") == "stalker" and not ua:
                        from .providers.stalker import MAG_UA
                        ua = MAG_UA
                except ApiError:
                    pass
                if alt == "b":
                    ua = net.BROWSER_UA
                return proxy.handle(self, parts[2], token, ua or None)
            if path.startswith("/relay/") or path.startswith("/vod/"):
                if not self.authed():
                    return self.send_error(401)
                parts = path.split("/")
                if len(parts) < 3:
                    return self.send_error(404)
                if parts[1] == "relay":
                    return self.app.relays.serve(self, parts[2])
                return self.app.vodcache.serve(self, parts[2])
            if path.startswith("/img/"):
                if not self.authed():
                    return self.send_error(401)
                got = self.app.images.get(path[5:].split("/", 1)[0])
                if not got:
                    self.send_response(404)
                    self.send_header("Content-Length", "0")
                    self.send_header("Cache-Control", "max-age=600")
                    self.end_headers()
                    return
                return self.send_bytes(got[0], got[1], "public, max-age=604800")
            if path.startswith("/files/"):
                if not self.authed():
                    return self.send_error(401)
                it = self.app.downloads.get(path.split("/")[2])
                if not it or not it.get("file") or not os.path.exists(it["file"]):
                    return self.send_error(404, "Arquivo não encontrado")
                ext = os.path.splitext(it["file"])[1].lower()
                ctype = {".ts": "video/mp2t", ".mkv": "video/webm", ".mp4": "video/mp4"}.get(
                    ext, mimetypes.guess_type(it["file"])[0] or "application/octet-stream")
                if query.get("dl") == "1":
                    ctype = "application/octet-stream"
                return self.send_file_range(it["file"], ctype)
            if path.startswith("/vendor/"):
                data = self.app.vendor.get(path[8:])
                if data is None:
                    return self.send_error(404)
                return self.send_bytes(data, "text/javascript; charset=utf-8", "public, max-age=86400")
            return self._static(path)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
        except Exception:  # noqa: BLE001
            traceback.print_exc()
            try:
                self.send_json({"error": "Erro interno do servidor"}, 500)
            except OSError:
                pass

    def _api(self, method, path, query):
        if not self.authed() and path not in ("/api/login", "/api/state", "/api/sync/hello"):
            return self.send_json({"error": "Entre com a senha do Sintonia", "auth": True}, 401)
        if path == "/api/state" and not self.authed():
            return self.send_json({"auth": True, "version": VERSION}, 401)
        body = {}
        if method in ("POST", "DELETE"):
            length = int(self.headers.get("Content-Length") or 0)
            if length:
                raw = self.rfile.read(min(length, 20 * 1024 * 1024))
                try:
                    body = json.loads(raw.decode("utf-8")) or {}
                except ValueError:
                    return self.send_json({"error": "JSON inválido"}, 400)
        for m_, rx, fn in ROUTES:
            if m_ != method:
                continue
            mm = rx.match(path)
            if mm:
                try:
                    return self.send_json(fn(self.app, self, mm, query, body))
                except ApiError as exc:
                    return self.send_json({"error": str(exc)}, exc.status)
                except net.FetchError as exc:
                    return self.send_json({"error": str(exc)}, 502)
        return self.send_json({"error": "Rota não encontrada"}, 404)

    def _static(self, path):
        if path in ("", "/"):
            path = "/index.html"
        target = (WEB_DIR / path.lstrip("/")).resolve()
        if WEB_DIR.resolve() not in target.parents or not target.is_file():
            target = WEB_DIR / "index.html"  # rotas da interface
        ext = target.suffix.lower()
        ctype = STATIC_TYPES.get(ext) or mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        cache = "no-cache" if ext in (".html", ".js", ".css", ".webmanifest") else "public, max-age=86400"
        st = target.stat()
        etag = f'"{VERSION}-{int(st.st_mtime)}-{st.st_size}"'
        if self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", cache)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self._etag = etag
        self.send_bytes(_static_cached(target, st), ctype, cache)


# arquivos da interface e versões comprimidas ficam na memória (não lê do disco nem comprime a cada pedido)
_STATIC = {}
_GZ = {}


def _static_cached(path, st):
    key = (str(path), st.st_mtime, st.st_size)
    hit = _STATIC.get(key)
    if hit is None:
        hit = path.read_bytes()
        if len(_STATIC) > 200:
            _STATIC.clear()
        _STATIC[key] = hit
    return hit


def _gz_cached(data):
    if len(data) > 4 * 1024 * 1024:
        return gzip.compress(data, 5)
    key = hashlib.sha1(data).digest()
    hit = _GZ.get(key)
    if hit is None:
        hit = gzip.compress(data, 6)
        if len(_GZ) > 200:
            _GZ.clear()
        _GZ[key] = hit
    return hit


class Server(ThreadingHTTPServer):
    daemon_threads = True
    # no Windows, reutilizar o endereço deixaria abrir dois Sintonia na mesma porta
    allow_reuse_address = os.name != "nt"
    request_queue_size = 64


def make_server(app, host="0.0.0.0", port=8787):
    handler = type("SintoniaHandler", (Handler,), {"app": app})
    return Server((host, port), handler)
