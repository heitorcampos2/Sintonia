"""Descoberta na rede por mDNS / DNS-SD (2.3.0), só com a biblioteca padrão.

Cada Sintonia anuncia o serviço _sintonia._tcp.local; quem procura pergunta uma vez e recebe a
resposta na hora, sem varrer a rede inteira. Se nada responder (rede que bloqueia multicast),
a sincronização continua usando a varredura antiga.
"""

import socket
import struct
import threading
import time

GROUP = "224.0.0.251"
PORT = 5353
SERVICE = "_sintonia._tcp.local"
T_A, T_PTR, T_TXT, T_SRV, T_ANY = 1, 12, 16, 33, 255


# ------------------------------------------------------------------ montagem / leitura de pacotes
def _name(n):
    out = b""
    for part in n.rstrip(".").split("."):
        b = part.encode("utf-8")[:63]
        out += bytes([len(b)]) + b
    return out + b"\x00"


def _rr(name, rtype, data, ttl=120, flush=False):
    cls = 1 | (0x8000 if flush else 0)
    return _name(name) + struct.pack("!HHIH", rtype, cls, ttl, len(data)) + data


def _read_name(buf, off, depth=0):
    labels = []
    jumped = False
    end = off
    while True:
        if off >= len(buf) or depth > 20:
            raise ValueError("nome inválido")
        ln = buf[off]
        if ln == 0:
            off += 1
            break
        if ln & 0xC0 == 0xC0:
            ptr = ((ln & 0x3F) << 8) | buf[off + 1]
            if not jumped:
                end = off + 2
            jumped = True
            off = ptr
            depth += 1
            continue
        labels.append(buf[off + 1:off + 1 + ln].decode("utf-8", "replace"))
        off += 1 + ln
    return ".".join(labels), (end if jumped else off)


def parse(buf):
    """(id, flags, perguntas[(nome, tipo, qu)], registros[(nome, tipo, dados_brutos, inicio_dados)])"""
    pid, flags, qd, an, ns, ar = struct.unpack("!HHHHHH", buf[:12])
    off = 12
    qs = []
    for _ in range(qd):
        n, off = _read_name(buf, off)
        t, c = struct.unpack("!HH", buf[off:off + 4])
        off += 4
        qs.append((n.lower(), t, bool(c & 0x8000)))
    rrs = []
    for _ in range(an + ns + ar):
        n, off = _read_name(buf, off)
        t, c, ttl, ln = struct.unpack("!HHIH", buf[off:off + 10])
        off += 10
        rrs.append((n.lower(), t, buf[off:off + ln], off))
        off += ln
    return pid, flags, qs, rrs


# ------------------------------------------------------------------ anúncio (responde a quem procura)
class Responder:
    def __init__(self, app_port, device_id, device_name, ips_fn):
        self.port = int(app_port)
        self.id = device_id or "sintonia"
        self.name = (device_name or "Sintonia").replace(".", " ")[:40]
        self.ips_fn = ips_fn
        self.sock = None

    def start(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except OSError:
                    pass
            s.bind(("", PORT))
            mreq = struct.pack("4s4s", socket.inet_aton(GROUP), socket.inet_aton("0.0.0.0"))
            s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
            self.sock = s
        except OSError:
            return False   # porta 5353 indisponível neste sistema: segue só com a varredura
        threading.Thread(target=self._loop, daemon=True).start()
        return True

    def answer(self):
        inst = f"{self.name} ({self.id[-4:]}).{SERVICE}"
        host = f"sintonia-{self.id}.local"
        recs = [_rr(SERVICE, T_PTR, _name(inst), 4500)]
        recs.append(_rr(inst, T_SRV, struct.pack("!HHH", 0, 0, self.port) + _name(host), 120, True))
        txt = b"".join(bytes([len(x)]) + x for x in (f"id={self.id}".encode(), f"port={self.port}".encode(), b"app=sintonia"))
        recs.append(_rr(inst, T_TXT, txt, 4500, True))
        for ip in self.ips_fn():
            try:
                recs.append(_rr(host, T_A, socket.inet_aton(ip), 120, True))
            except OSError:
                pass
        return struct.pack("!HHHHHH", 0, 0x8400, 0, len(recs), 0, 0) + b"".join(recs)

    def _loop(self):
        while True:
            try:
                data, addr = self.sock.recvfrom(9000)
                _pid, flags, qs, _ = parse(data)
            except Exception:  # noqa: BLE001 - pacote estranho: ignora
                continue
            if flags & 0x8000:
                continue   # é resposta, não pergunta
            want = [q for q in qs if q[0] == SERVICE.lower() and q[1] in (T_PTR, T_ANY)]
            if not want:
                continue
            pkt = self.answer()
            try:
                # quem pediu resposta direta (bit QU) ou porta diferente de 5353 recebe direto
                if any(q[2] for q in want) or addr[1] != PORT:
                    self.sock.sendto(pkt, addr)
                else:
                    self.sock.sendto(pkt, (GROUP, PORT))
            except OSError:
                pass


# ------------------------------------------------------------------ busca
def query(timeout=1.6):
    """Pergunta quem tem _sintonia._tcp na rede. Devolve [('ip', porta, id)]."""
    q = struct.pack("!HHHHHH", 0, 0, 1, 0, 0, 0) + _name(SERVICE) + struct.pack("!HH", T_PTR, 0x8001)  # 0x8000 = QU
    found = {}
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
        s.settimeout(0.3)
        s.bind(("", 0))
    except OSError:
        return []
    end = time.time() + timeout
    sent = 0
    try:
        while time.time() < end:
            if sent < 2 and time.time() > end - timeout + sent * 0.5:
                try:
                    s.sendto(q, (GROUP, PORT))
                except OSError:
                    pass
                sent += 1
            try:
                data, addr = s.recvfrom(9000)
            except (socket.timeout, OSError):
                continue
            try:
                _pid, flags, _qs, rrs = parse(data)
            except Exception:  # noqa: BLE001
                continue
            srv, ips, ids = {}, {}, {}
            for name, t, raw, start in rrs:
                if t == T_SRV and len(raw) >= 6:
                    port = struct.unpack("!H", raw[4:6])[0]
                    target, _ = _read_name(data, start + 6)
                    srv[name] = (port, target.lower())
                elif t == T_A and len(raw) == 4:
                    ips.setdefault(name, []).append(socket.inet_ntoa(raw))
                elif t == T_TXT:
                    i = 0
                    while i < len(raw):
                        ln = raw[i]
                        kv = raw[i + 1:i + 1 + ln].decode("utf-8", "replace")
                        if kv.startswith("id="):
                            ids[name] = kv[3:]
                        i += 1 + ln
            for inst, (port, target) in srv.items():
                if not inst.endswith(SERVICE.lower()):
                    continue
                cand = ips.get(target) or [addr[0]]
                for ip in cand:
                    found[(ip, port)] = ids.get(inst, "")
    finally:
        s.close()
    return [(ip, port, i) for (ip, port), i in found.items()]
