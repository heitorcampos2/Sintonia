"""Cache dos catálogos de cada fonte (memória + disco)."""

import json
import os
import threading
import time
from pathlib import Path

from .providers import make_provider


class Catalog:
    def __init__(self, source, cache_dir, ttl_hours=12):
        self.source = source
        self.dir = Path(cache_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.ttl = ttl_hours * 3600
        self.provider = make_provider(source)
        # se o tipo de leitura mudou (ex.: M3U de painel Xtream passou a ser lido como Xtream), descarta o cache antigo
        marker = self.dir / "provider.txt"
        try:
            old = marker.read_text().strip()
        except OSError:
            old = ""
        if old != self.provider.kind:
            for f in self.dir.glob("*.json"):
                try:
                    f.unlink()
                except OSError:
                    pass
            try:
                marker.write_text(self.provider.kind)
            except OSError:
                pass
        self._mem = {}
        self._index = {}
        self._lock = threading.RLock()
        self._kind_locks = {}
        self._details = None
        self._account = None
        self._refreshing = set()

    # --- utilidades ---------------------------------------------------------
    def _file(self, key):
        safe = key.replace("/", "_").replace(":", "_")
        return self.dir / f"{safe}.json"

    def _klock(self, key):
        with self._lock:
            if key not in self._kind_locks:
                self._kind_locks[key] = threading.Lock()
            return self._kind_locks[key]

    def _read_disk(self, key, allow_stale=False):
        f = self._file(key)
        try:
            stale = time.time() - f.stat().st_mtime > self.ttl
            if stale and not allow_stale:
                return None
            with open(f, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if allow_stale:
                return data, stale
            return data
        except (OSError, ValueError):
            return (None, True) if allow_stale else None

    def _refresh_later(self, key, kind, cat):
        """2.3.0: lista vencida abre na hora com a cópia guardada; a nova vem em segundo plano."""
        with self._lock:
            if key in self._refreshing:
                return
            self._refreshing.add(key)

        def run():
            try:
                self.get(kind, cat, force=True)
            except Exception:  # noqa: BLE001 - servidor fora do ar: fica a cópia guardada
                pass
            finally:
                with self._lock:
                    self._refreshing.discard(key)
        threading.Thread(target=run, daemon=True).start()

    def _write_disk(self, key, data):
        f = self._file(key)
        tmp = f.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, f)

    # --- API ------------------------------------------------------------------
    def is_lazy(self, kind):
        return kind in getattr(self.provider, "lazy_kinds", ())

    def warm(self):
        """Carrega ao vivo, filmes e séries ao abrir o app (do disco, ou do servidor se não houver cópia)."""
        for kind in ("live", "movie", "series"):
            if self.is_lazy(kind):
                continue
            try:
                self.get(kind)
            except Exception:  # noqa: BLE001
                pass

    def get(self, kind, cat=None, force=False):
        key = kind if not (self.is_lazy(kind) and cat) else f"{kind}__{cat}"
        with self._klock(key):
            if not force:
                if key in self._mem:
                    return self._mem[key]
                disk, stale = self._read_disk(key, allow_stale=True)
                if disk is not None:
                    self._remember(key, kind, disk)
                    meta = self._read_disk("meta", allow_stale=True)[0]
                    if meta and hasattr(self.provider, "_header") and not self.provider._header:
                        self.provider._header = meta.get("header") or {}
                    if stale:
                        self._refresh_later(key, kind, cat)
                    return disk
            if hasattr(self.provider, "load_all") and not self.is_lazy(kind):
                all_kinds = self.provider.load_all()
                self._write_disk("meta", {"header": getattr(self.provider, "_header", {})})
                for k, d in all_kinds.items():
                    self._write_disk(k, d)
                    self._remember(k, k, d)
                return all_kinds[kind]
            data = self.provider.load(kind, cat if self.is_lazy(kind) else None)
            self._write_disk(key, data)
            self._remember(key, kind, data)
            return data

    def _remember(self, key, kind, data):
        self._mem[key] = data
        idx = self._index.setdefault(kind, {})
        for it in data.get("items", []):
            idx[it["id"]] = it

    def find(self, kind, item_id):
        idx = self._index.get(kind)
        if idx is None or item_id not in idx:
            if not self.is_lazy(kind):
                self.get(kind)
            idx = self._index.get(kind, {})
        return idx.get(item_id)

    def invalidate(self):
        with self._lock:
            self._mem.clear()
            self._index.clear()
            self._account = None
            for f in self.dir.glob("*.json"):
                if f.name not in ("details.json",):
                    try:
                        f.unlink()
                    except OSError:
                        pass
            self.provider = make_provider(self.source)

    def account(self, force=False):
        if self._account and not force and time.time() - self._account[0] < 600:
            return self._account[1]
        info = self.provider.account()
        self._account = (time.time(), info)
        return info

    # --- detalhes (filmes/séries) ---------------------------------------------
    def _details_store(self):
        if self._details is None:
            try:
                with open(self.dir / "details.json", "r", encoding="utf-8") as fh:
                    self._details = json.load(fh)
            except (OSError, ValueError):
                self._details = {}
        return self._details

    def _save_details(self):
        d = self._details_store()
        if len(d) > 4000:
            for k in sorted(d, key=lambda k: d[k].get("_t", 0))[: len(d) - 3500]:
                d.pop(k, None)
        self._write_disk("details", d)

    def details(self, kind, item_id):
        key = f"{kind}:{item_id}"
        store = self._details_store()
        cached = store.get(key)
        if cached and time.time() - cached.get("_t", 0) < self.ttl:
            return cached["data"]
        if kind == "movie":
            data = self.provider.movie_info(item_id)
        else:
            data = self.provider.series_info(item_id)
        with self._lock:
            store[key] = {"_t": time.time(), "data": data}
            self._save_details()
        return data

    def search_cast(self, q):
        q = q.lower().strip()
        out = []
        for key, v in self._details_store().items():
            data = v.get("data") or {}
            info = data.get("info", data)
            cast = (info.get("cast") or "") + " " + (info.get("director") or "")
            if q and q in cast.lower():
                kind, _, item_id = key.partition(":")
                out.append({"kind": kind, "id": item_id, "cast": info.get("cast") or ""})
        return out[:200]
