"""Acesso HTTP aos provedores (somente biblioteca padrão)."""

import gzip
import ipaddress
import json
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request
import zlib

# Muitos provedores IPTV só liberam a TV ao vivo para players conhecidos (VLC, apps de IPTV)
# e recusam User-Agent de navegador. Por isso o padrão imita o VLC.
DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/138.0 Safari/537.36")

_state = {"ua": DEFAULT_UA}

_insecure = ssl.create_default_context()
_insecure.check_hostname = False
_insecure.verify_mode = ssl.CERT_NONE


# ---------------------------------------------------------------- DNS seguro (2.2.5)
# Alguns DNS de provedor de internet/roteador não encontram o endereço do servidor da lista
# (ex.: domínios .zip). Os apps de IPTV usam DNS próprio; aqui, quando o DNS do sistema
# não acha o nome, perguntamos ao DNS seguro da Cloudflare e do Google (DNS por HTTPS).
_DOH = (
    ("https://1.1.1.1/dns-query?name={}&type={}", {"Accept": "application/dns-json"}),
    ("https://8.8.8.8/resolve?name={}&type={}", {}),
    ("https://1.0.0.1/dns-query?name={}&type={}", {"Accept": "application/dns-json"}),
)
_dns_cache = {}
_dns_lock = threading.Lock()
_sys_getaddrinfo = socket.getaddrinfo


def _is_ip(host):
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def doh_resolve(host, timeout=6):
    """IPs (v4, depois v6) do nome pelo DNS por HTTPS. Lista vazia se não achar."""
    now = time.time()
    with _dns_lock:
        hit = _dns_cache.get(host)
        if hit and hit[0] > now:
            return hit[1]
    ctx = ssl.create_default_context()
    for qtype in ("A", "AAAA"):
        for url, hdr in _DOH:
            try:
                req = urllib.request.Request(url.format(host, qtype), headers=dict(hdr, **{"User-Agent": "Sintonia"}))
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
                    data = json.loads(r.read().decode("utf-8", "replace"))
            except Exception:  # noqa: BLE001
                continue
            want = 1 if qtype == "A" else 28
            ips = [a["data"] for a in data.get("Answer") or [] if a.get("type") == want and _is_ip(str(a.get("data", "")))]
            if ips:
                ttl = max(60, min(3600, min(int(a.get("TTL", 300)) for a in data["Answer"] if a.get("type") == want)))
                with _dns_lock:
                    _dns_cache[host] = (now + ttl, ips)
                return ips
            if data.get("Status") == 0:
                break  # o DNS respondeu, só não tem este tipo
    return []


_sys_fail = {}   # 2.3.2: nomes que o DNS da rede não acha (ele demora ~3 s para desistir) -> direto ao DNS seguro por 30 min


def _getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):  # noqa: A002
    name = host.decode() if isinstance(host, bytes) else host
    key = (name or "").rstrip(".").lower()
    if key in _sys_fail and _sys_fail[key] > time.time():
        try:
            return _from_doh(key, port, family, type, proto, flags)
        except socket.gaierror:
            pass
    if not name or _is_ip(name) or "." not in name or name.endswith((".local", ".lan", ".localhost")) or key == "localhost":
        return _sys_getaddrinfo(host, port, family, type, proto, flags)
    with _dns_lock:
        hit = _dns_cache.get(key)
    if hit and hit[0] > time.time():
        try:
            return _from_doh(key, port, family, type, proto, flags)
        except socket.gaierror:
            pass
    # 2.3.2: pergunta ao DNS da rede e ao DNS seguro ao mesmo tempo (o da rede tem 0,25 s de vantagem)
    import queue
    q = queue.Queue()

    def sys_job():
        try:
            q.put(("ok", _sys_getaddrinfo(host, port, family, type, proto, flags)))
        except socket.gaierror as exc:
            _sys_fail[key] = time.time() + 1800
            q.put(("err", exc))
        except Exception as exc:  # noqa: BLE001
            q.put(("err", exc))

    def doh_job():
        try:
            q.put(("ok", _from_doh(key, port, family, type, proto, flags)))
        except Exception as exc:  # noqa: BLE001
            q.put(("err", exc))

    threading.Thread(target=sys_job, daemon=True).start()
    try:
        kind, val = q.get(timeout=0.25)
        if kind == "ok":
            return val
        first_err = val
        pending = 1
    except queue.Empty:
        first_err = None
        pending = 2
    threading.Thread(target=doh_job, daemon=True).start()
    while pending:
        try:
            kind, val = q.get(timeout=20)
        except queue.Empty:
            break
        pending -= 1
        if kind == "ok":
            return val
        first_err = first_err or val
    if isinstance(first_err, socket.gaierror):
        raise first_err
    raise socket.gaierror(socket.EAI_NONAME, "nome não encontrado")


def _from_doh(name, port, family, type, proto, flags):  # noqa: A002
    ips = doh_resolve(name)
    if not ips:
        raise socket.gaierror(socket.EAI_NONAME, "nome não encontrado")
    out = []
    for ip in ips:
        fam = socket.AF_INET6 if ":" in ip else socket.AF_INET
        if family not in (0, socket.AF_UNSPEC, fam):
            continue
        try:
            out.extend(_sys_getaddrinfo(ip, port, fam, type, proto, flags | socket.AI_NUMERICHOST))
        except socket.gaierror:
            continue
    if not out:
        raise socket.gaierror(socket.EAI_NONAME, "nome não encontrado")
    return out


socket.getaddrinfo = _getaddrinfo


def set_user_agent(ua):
    _state["ua"] = ua.strip() if ua and ua.strip() else DEFAULT_UA


def user_agent():
    return _state["ua"]


class FetchError(Exception):
    pass


def _is_ssl_error(exc):
    reason = getattr(exc, "reason", exc)
    return isinstance(reason, ssl.SSLError) or isinstance(exc, ssl.SSLError)


def open_url(url, headers=None, timeout=25, data=None, method=None):
    """Abre a URL. Muitos servidores IPTV têm certificado vencido: tenta de novo sem validar."""
    h = {"User-Agent": user_agent(), "Accept": "*/*", "Accept-Encoding": "identity"}
    if headers:
        h.update({k: v for k, v in headers.items() if v is not None})
    req = urllib.request.Request(url, headers=h, data=data, method=method)
    # Servidor atrás da Cloudflare às vezes responde 520-524/502-504 (servidor da lista demorou):
    # tenta de novo até 3 vezes, como os apps de IPTV.
    attempts = 3 if (method or "GET").upper() == "GET" and data is None else 1
    for i in range(attempts):
        try:
            return _open_once(req, url, timeout)
        except urllib.error.HTTPError as exc:
            if exc.code not in _RETRY_CODES or i == attempts - 1:
                raise
            exc.close()
        except (TimeoutError, socket.timeout):
            if i == attempts - 1:
                raise
        time.sleep(0.6 * (i + 1))
    raise FetchError("sem resposta")


_RETRY_CODES = {502, 503, 504, 520, 521, 522, 523, 524}


def _open_once(req, url, timeout):
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError:
        raise
    except Exception as exc:  # noqa: BLE001
        if url.lower().startswith("https") and _is_ssl_error(exc):
            return urllib.request.urlopen(req, timeout=timeout, context=_insecure)
        raise


def _decode_body(raw, encoding):
    encoding = (encoding or "").lower()
    if encoding == "gzip" or raw[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(raw)
        except OSError:
            return raw
    if encoding == "deflate":
        try:
            return zlib.decompress(raw)
        except zlib.error:
            return zlib.decompress(raw, -zlib.MAX_WBITS)
    return raw


def fetch_bytes(url, headers=None, timeout=30, max_bytes=None):
    try:
        with open_url(url, headers=headers, timeout=timeout) as resp:
            raw = resp.read(max_bytes) if max_bytes else resp.read()
            return _decode_body(raw, resp.headers.get("Content-Encoding"))
    except urllib.error.HTTPError as exc:
        raise FetchError(f"O servidor respondeu {exc.code} ({exc.reason})") from exc
    except urllib.error.URLError as exc:
        raise FetchError(f"Não foi possível conectar: {exc.reason}") from exc
    except (TimeoutError, OSError) as exc:
        raise FetchError(f"Falha de rede: {exc}") from exc


def fetch_text(url, headers=None, timeout=30):
    raw = fetch_bytes(url, headers=headers, timeout=timeout)
    for enc in ("utf-8-sig", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def fetch_json(url, headers=None, timeout=30):
    text = fetch_text(url, headers=headers, timeout=timeout).strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except ValueError as exc:
        raise FetchError("Resposta inválida do servidor (não é JSON)") from exc
