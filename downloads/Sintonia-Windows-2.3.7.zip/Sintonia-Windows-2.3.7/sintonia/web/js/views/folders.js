// Escolher a pasta dos downloads e das gravações (funciona no Windows, Linux, Android e Android TV)
import { api } from '../api.js';
import { S, saveSettings } from '../state.js';
import { btn, clear, h, ic, modal, promptBox, toast } from '../ui.js';

const ANDROID = !!(window.SintoniaApp && window.SintoniaApp.hasStorage);

/** No Android, pastas fora do app pedem a permissão "Acesso a todos os arquivos". */
export function storageAccess() {
  if (!ANDROID) return true;
  try { return !!window.SintoniaApp.hasStorage(); } catch { return true; }
}
export function askStorage() {
  try { window.SintoniaApp.askStorage(); } catch { /* app antigo */ }
}

/** Abre o navegador de pastas. Resolve com o caminho escolhido ou null. */
export function folderPicker(title, current) {
  return new Promise((resolve) => {
    let cur = null;
    let chosen = null;
    const pathEl = h('div.fp-path');
    const list = h('div.fp-list');
    const places = h('div.fp-places');
    const warn = h('div.fp-warn');
    const useBtn = btn('Usar esta pasta', { cls: 'primary', icon: 'check', onclick: () => { chosen = cur.path; m.close(); } });
    const go = async (path) => {
      clear(list).append(h('div.loading', h('span.spin')));
      try {
        cur = await api.get(`/api/fs/browse?path=${encodeURIComponent(path || '')}`);
      } catch (e) {
        clear(list).append(h('p.muted.pad', e.message));
        return;
      }
      pathEl.textContent = cur.path;
      clear(list);
      if (cur.parent) list.append(h('button.fp-item.up', { type: 'button', onclick: () => go(cur.parent) }, ic('arrowL'), h('span', 'Voltar para a pasta acima')));
      cur.dirs.forEach((d) => list.append(h('button.fp-item', { type: 'button', onclick: () => go(cur.path.replace(/[\\/]+$/, '') + cur.sep + d) }, ic('folder'), h('span', d))));
      if (!cur.dirs.length) list.append(h('p.muted.fp-empty', cur.error || 'Nenhuma subpasta aqui.'));
      clear(places);
      cur.places.forEach((p) => places.append(h('button.fp-place', { type: 'button', class: cur.path === p.path ? 'on' : '', onclick: () => go(p.path) }, p.name)));
      clear(warn);
      useBtn.disabled = !cur.writable;
      if (!cur.writable) {
        warn.append(h('span', ic('warning'), cur.android && !storageAccess()
          ? ' Para salvar fora da pasta do app, o Android precisa da permissão "Acesso a todos os arquivos".'
          : ' Não dá para gravar nesta pasta. Escolha outra.'));
        if (cur.android && !storageAccess()) {
          warn.append(btn('Dar permissão', { cls: 'sm', onclick: () => {
            askStorage();
            toast('Ative "Permitir acesso para gerenciar todos os arquivos" e volte para o Sintonia.', { ms: 7000 });
            const back = () => { if (!document.hidden) { document.removeEventListener('visibilitychange', back); go(cur.path); } };
            document.addEventListener('visibilitychange', back);
          } }));
        }
      }
      setTimeout(() => (list.querySelector('.fp-item') || useBtn).focus(), 30);
    };
    const tools = h('div.fp-tools',
      btn('Nova pasta', { cls: 'ghost sm', icon: 'plus', onclick: async () => {
        const name = await promptBox('Nome da nova pasta', { title: 'Nova pasta', placeholder: 'Ex.: Sintonia' });
        if (!name) return;
        try { const r = await api.post('/api/fs/mkdir', { path: cur.path, name }); go(r.path); } catch (e) { toast(e.message, { type: 'error' }); }
      } }),
      btn('Digitar caminho', { cls: 'ghost sm', icon: 'edit', onclick: async () => {
        const v = await promptBox('Caminho da pasta', { title, value: cur ? cur.path : '' });
        if (v) go(v.trim());
      } }),
      navigator.userAgent.includes('Windows') ? btn('Janela do Windows…', { cls: 'ghost sm', icon: 'folder', onclick: async () => {
        try { const r = await api.post('/api/fs/pick', { path: cur ? cur.path : '' }); if (r.path) go(r.path); } catch (e) { toast(e.message, { type: 'error' }); }
      } }) : null);
    const m = modal(h('div.fp',
      h('div.fp-side', h('small.fp-lbl', 'Atalhos'), places),
      h('div.fp-main', pathEl, warn, list, tools,
        h('div.modal-actions', btn('Cancelar', { cls: 'ghost', onclick: () => m.close() }), useBtn))),
    { title, cls: 'wide fp-modal', noFocus: true, onClose: () => resolve(chosen) });
    go(current || '');
  });
}

// ---------- pasta dos downloads / gravações ----------
const KEY = { download: 'downloadDir', rec: 'recordDir' };
const LABEL = { download: 'Pasta dos downloads', rec: 'Pasta das gravações' };

export function defaultFolder(kind) {
  const base = S.mediaDir || '';
  if (kind !== 'rec') return base;
  return base + (base.includes('\\') ? '\\' : '/') + 'Gravações';
}
export function folderOf(kind) { return (S.settings && S.settings[KEY[kind]]) || defaultFolder(kind); }

export async function changeFolder(kind) {
  const p = await folderPicker(LABEL[kind], folderOf(kind));
  if (!p) return null;
  await saveSettings({ [KEY[kind]]: p });
  toast(`${LABEL[kind]}: ${p}`, { type: 'ok', ms: 4000 });
  return p;
}

export async function resetFolder(kind) {
  await saveSettings({ [KEY[kind]]: '' });
  toast(`${LABEL[kind]}: voltou para a padrão`);
}

/** Barra "Salvando em …  [Trocar pasta] [Padrão]" (página Offline e Configurações). */
export function folderBar(kind, onChange) {
  const box = h('div.folder-bar');
  const draw = () => {
    clear(box);
    const custom = !!(S.settings && S.settings[KEY[kind]]);
    box.append(...[ic('folder'), h('div.fb-txt', h('small', kind === 'rec' ? 'Gravações salvas em' : 'Downloads salvos em'), h('span', folderOf(kind))),
      btn('Trocar pasta', { cls: 'sm', icon: 'edit', onclick: async () => { if (await changeFolder(kind)) { draw(); if (onChange) onChange(); } } }),
      custom ? btn('Padrão', { cls: 'ghost sm', onclick: async () => { await resetFolder(kind); draw(); if (onChange) onChange(); } }) : null].filter(Boolean));
  };
  draw();
  return box;
}
