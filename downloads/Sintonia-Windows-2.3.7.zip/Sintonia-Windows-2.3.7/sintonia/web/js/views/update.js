// Atualização pelo GitHub: 🔁 no canto superior direito quando sai versão nova
import { api } from '../api.js';
import { btn, h, modal, toast } from '../ui.js';

let info = null;

// Sugestão: Spectra Launcher (tela inicial para Android TV, do mesmo autor)
export const SPECTRA = {
  page: 'https://github.com/heitorcampos2/Spectra-launcher',
  apk: 'https://github.com/heitorcampos2/Spectra-launcher/releases/latest/download/SpectraLauncher.apk',
};

/** Cartão "Spectra Launcher" com botão de instalar (Android) ou abrir no GitHub. */
export function spectraCard(onDone) {
  const isAndroidApp = !!(window.SintoniaApp && window.SintoniaApp.installUpdate);
  return h('div.spectra-card',
    h('div.spectra-txt',
      h('strong', 'Spectra Launcher'),
      h('small', 'Sugestão: tela inicial para Android TV, do mesmo criador do Sintonia. Mostra "Continuar assistindo" e os canais do Sintonia direto na tela inicial.')),
    isAndroidApp
      ? btn('Instalar', { cls: 'ghost sm', icon: 'download', onclick: () => { window.SintoniaApp.installUpdate(SPECTRA.apk); toast('Baixando o Spectra Launcher… quando terminar, o Android pede para instalar.', { ms: 6000 }); if (onDone) onDone(); } })
      : btn('Ver no GitHub', { cls: 'ghost sm', icon: 'external', onclick: () => window.open(SPECTRA.page, '_blank') }));
}

// Sugestão: SmartTube (YouTube sem anúncios para Android TV), versão estável oficial do GitHub
export const SMARTTUBE = {
  page: 'https://github.com/yuliskov/SmartTube',
  apk: 'https://github.com/yuliskov/SmartTube/releases/download/latest/smarttube_stable.apk',
};

export function smartTubeCard(onDone) {
  const isAndroidApp = !!(window.SintoniaApp && window.SintoniaApp.installUpdate);
  return h('div.spectra-card',
    h('div.spectra-txt',
      h('strong', 'SmartTube (estável)'),
      h('small', 'Sugestão: YouTube para Android TV sem anúncios, com SponsorBlock. Baixa a última versão estável direto do GitHub oficial (yuliskov/SmartTube).')),
    isAndroidApp
      ? btn('Instalar', { cls: 'ghost sm', icon: 'download', onclick: () => { window.SintoniaApp.installUpdate(SMARTTUBE.apk); toast('Baixando o SmartTube… quando terminar, o Android pede para instalar.', { ms: 6000 }); if (onDone) onDone(); } })
      : btn('Ver no GitHub', { cls: 'ghost sm', icon: 'external', onclick: () => window.open(SMARTTUBE.page, '_blank') }));
}

export function smartTubeModal() {
  let m;
  m = modal(h('div.upd-box', smartTubeCard(() => m.close()),
    h('p.hint', 'No PC: abra a página do GitHub, baixe o smarttube_stable.apk e instale na TV/TV box (pendrive ou app Downloader).')),
  { title: 'Sugestão de app', cls: 'share-modal' });
}

export function spectraModal() {
  let m;
  m = modal(h('div.upd-box', spectraCard(() => m.close()),
    h('p.hint', 'Na TV ou TV box: baixe o SpectraLauncher.apk pela página do GitHub (ou pelo Sintonia no Android TV, em Configurações) e instale.')),
  { title: 'Sugestão de app', cls: 'share-modal' });
}
let badge = null;

function drawBadge() {
  if (badge) { badge.remove(); badge = null; }
  if (!info || !info.available) return;
  badge = h('button.upd-badge', { type: 'button', title: `Atualização disponível: versão ${info.latest}`, 'aria-label': `Atualizar para a versão ${info.latest}`, onclick: () => updateModal() },
    h('span.upd-ic', '🔁'), h('span.upd-txt', `Versão ${info.latest}`));
  document.body.append(badge);
}

/** Consulta o GitHub (o servidor guarda a resposta por algumas horas). */
export async function checkUpdate(force) {
  try {
    info = await api.get(`/api/update/check${force ? '?force=1' : ''}`);
  } catch { info = null; }
  drawBadge();
  return info;
}

export function startUpdateChecks() {
  checkUpdate();
  setInterval(() => checkUpdate(), 6 * 3600 * 1000);
}

async function waitNewVersion(target) {
  const t0 = Date.now();
  while (Date.now() - t0 < 90000) {
    await new Promise((r) => setTimeout(r, 1500));
    try {
      const r = await fetch('/api/state', { cache: 'no-store' });
      const d = await r.json();
      if (d.version === target) return true;
    } catch { /* reabrindo */ }
  }
  return false;
}

export async function updateModal() {
  if (!info) await checkUpdate(true);
  if (!info) { toast('Não consegui consultar as atualizações agora.', { type: 'error' }); return; }
  if (!info.available) {
    toast(info.error || `Você já está na versão mais nova (${info.current}).`, { type: info.error ? 'error' : 'ok', ms: 5000 });
    return;
  }
  const notes = h('ul.upd-notes', ...(info.notes || []).map((n) => h('li', n)));
  const acts = h('div.modal-actions');
  const isAndroidApp = !!(window.SintoniaApp && window.SintoniaApp.installUpdate);
  let m;
  if (isAndroidApp && info.files.android) {
    acts.append(btn('Baixar e instalar', { cls: 'primary', icon: 'download', onclick: () => {
      window.SintoniaApp.installUpdate(info.files.android);
      toast('Baixando a versão nova… quando terminar, o Android pede para instalar.', { ms: 7000 });
      m.close();
    } }));
  } else if (info.canApply) {
    acts.append(btn('Atualizar agora', { cls: 'primary', icon: 'refresh', onclick: async (e) => {
      const b = e.currentTarget;
      b.disabled = true;
      b.textContent = 'Baixando…';
      try {
        const r = await api.post('/api/update/apply');
        b.textContent = 'Reabrindo…';
        const ok = await waitNewVersion(r.version);
        if (ok) location.reload();
        else toast('Atualizado. Feche e abra o Sintonia de novo.', { ms: 8000 });
      } catch (err) {
        toast(err.message, { type: 'error', ms: 7000 });
        b.disabled = false;
        b.textContent = 'Atualizar agora';
      }
    } }));
  }
  acts.prepend(btn('Ver no GitHub', { cls: 'ghost', onclick: () => window.open(info.page, '_blank') }));
  m = modal(h('div.upd-box',
    h('p', `Você está na ${info.current}. A versão `, h('strong', info.latest), info.date ? ` saiu em ${info.date.split('-').reverse().join('/')}.` : ' está disponível.'),
    notes.childElementCount ? notes : null,
    !info.canApply && !isAndroidApp ? h('p.hint', 'Neste aparelho, baixe o pacote novo no GitHub e instale por cima.') : null,
    h('p.hint', 'Suas listas, favoritos e configurações continuam.'),
    acts,
    h('div.upd-sep', 'Sugestões'),
    spectraCard(() => m.close()),
    smartTubeCard(() => m.close())), { title: '🔁 Atualização disponível', cls: 'share-modal' });
}
