// Exportar / importar listas (arquivo, texto, QR) e procurar outros Sintonia na rede
import { api } from '../api.js';
import { S, loadState, saveSettings } from '../state.js';
import { btn, clear, copyText, downloadText, h, ic, modal, promptBox, spinner, toast } from '../ui.js';

// ---------------------------------------------------------------- QR
let qrLoad = null;
function loadQr() {
  if (window.SintoniaQR) return Promise.resolve(window.SintoniaQR);
  if (!qrLoad) {
    qrLoad = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = '/js/lib/qr.js';
      s.onload = () => resolve(window.SintoniaQR);
      s.onerror = () => { qrLoad = null; reject(new Error('Não consegui carregar o gerador de QR')); };
      document.head.append(s);
    });
  }
  return qrLoad;
}

/** Texto curto (sem campos vazios) que vai no arquivo e no QR. */
export function packLists(sources) {
  return JSON.stringify({ sintonia: 'lista', v: 1, sources: sources.map((x) => {
    const o = {};
    ['type', 'name', 'url', 'username', 'password', 'mac', 'epgUrl', 'ua'].forEach((k) => { if (x[k]) o[k] = x[k]; });
    return o;
  }) });
}

/** Entende o que foi colado, lido no QR ou aberto do arquivo. */
export function parseLists(text, fileName) {
  const t = String(text || '').trim().replace(/^﻿/, '');
  if (!t) throw new Error('Nada para importar');
  if (t[0] === '{' || t[0] === '[') {
    let d;
    try { d = JSON.parse(t); } catch { throw new Error('O arquivo não é uma lista do Sintonia válida'); }
    if (d && d.sintonia === 'sync' && d.peer) return { pair: d };
    const list = Array.isArray(d) ? d : d.sources || (d.type ? [d] : null);
    if (!list || !list.length) throw new Error('Não encontrei listas nesse conteúdo');
    return { sources: list };
  }
  if (/^#EXTM3U/i.test(t) || /#EXTINF/i.test(t)) {
    return { m3uText: t, name: (fileName || 'Lista importada').replace(/\.(m3u8?|txt)$/i, '') };
  }
  const first = t.split(/\s+/)[0];
  if (/^https?:\/\//i.test(first)) {
    try {
      const u = new URL(first);
      const user = u.searchParams.get('username');
      const pass = u.searchParams.get('password');
      if (user && pass) return { sources: [{ type: 'xtream', name: u.hostname, url: `${u.protocol}//${u.host}`, username: user, password: pass }] };
      return { sources: [{ type: 'm3u', name: u.hostname, url: first }] };
    } catch { /* cai no erro abaixo */ }
  }
  throw new Error('Não reconheci esse conteúdo. Use um arquivo exportado pelo Sintonia, um .m3u ou um link de lista.');
}

async function doImport(payload) {
  if (payload.pair) return pairWith(payload.pair);
  const r = await api.post('/api/sources/import', payload);
  await loadState();
  if (r.added) toast(`${r.added} lista${r.added > 1 ? 's' : ''} importada${r.added > 1 ? 's' : ''}${r.skipped ? ` (${r.skipped} já existia${r.skipped > 1 ? 'm' : ''})` : ''}`, { type: 'ok' });
  else toast('Essas listas já estavam no Sintonia.');
  window.dispatchEvent(new CustomEvent('sintonia:source-changed'));
  return r;
}

// ---------------------------------------------------------------- exportar
export async function exportModal(ids) {
  const d = await api.get(`/api/sources/export${ids && ids.length ? `?ids=${ids.join(',')}` : ''}`);
  if (!d.sources.length) { toast('Nenhuma lista para exportar'); return; }
  const text = packLists(d.sources);
  const qrBox = h('div.qr-box', spinner());
  const names = d.sources.map((x) => x.name).join(', ');
  modal(h('div.share-box',
    h('p', d.sources.length === 1 ? `Lista "${names}"` : `${d.sources.length} listas: ${names}`),
    qrBox,
    h('p.hint', 'No outro aparelho: Menu › Fontes e playlists › Importar lista › Ler QR com a câmera. Também dá para levar o arquivo.'),
    h('p.hint.warn', ic('shield'), ' Contém usuário e senha da lista. Mostre só para aparelhos seus.'),
    h('div.modal-actions',
      btn('Copiar texto', { cls: 'ghost', icon: 'copy', onclick: () => copyText(text) }),
      btn('Baixar arquivo', { cls: 'primary', icon: 'download', onclick: () => downloadText('sintonia-lista.json', text, 'application/json') }))),
  { title: 'Exportar lista', cls: 'share-modal' });
  try {
    const QR = await loadQr();
    clear(qrBox).innerHTML = QR.svg(text, { level: text.length > 1200 ? 'L' : 'M' });
  } catch (e) {
    clear(qrBox).append(h('p.form-err', text.length > 2900 ? 'Lista grande demais para QR. Use o arquivo.' : e.message));
  }
}

// ---------------------------------------------------------------- importar
function canScan() {
  if (window.SintoniaApp && window.SintoniaApp.scanQr) { try { return window.SintoniaApp.hasCamera ? !!window.SintoniaApp.hasCamera() : true; } catch { return true; } }
  return 'BarcodeDetector' in window && !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) && window.isSecureContext;
}

/** Lê um QR: no app Android usa o leitor do celular; no navegador, a câmera com o detector do Chrome. */
export function scanQr() {
  return new Promise((resolve, reject) => {
    if (window.SintoniaApp && window.SintoniaApp.scanQr) {
      window.sintoniaQrResult = (txt) => { window.sintoniaQrResult = null; if (txt) resolve(txt); else reject(new Error('Leitura cancelada')); };
      window.SintoniaApp.scanQr();
      return;
    }
    const video = h('video.qr-cam', { playsinline: true, muted: true, autoplay: true });
    let stream = null;
    let timer = null;
    let done = false;
    const stop = () => { clearInterval(timer); if (stream) stream.getTracks().forEach((t) => t.stop()); };
    const m = modal(h('div.share-box', video, h('p.hint', 'Aponte a câmera para o QR do outro aparelho.')),
      { title: 'Ler QR', cls: 'share-modal', onClose: () => { stop(); if (!done) reject(new Error('Leitura cancelada')); } });
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false }).then(async (s) => {
      stream = s;
      video.srcObject = s;
      const det = new window.BarcodeDetector({ formats: ['qr_code'] });
      timer = setInterval(async () => {
        if (video.readyState < 2) return;
        try {
          const codes = await det.detect(video);
          if (codes.length && !done) { done = true; stop(); m.close(); resolve(codes[0].rawValue); }
        } catch { /* tenta de novo */ }
      }, 300);
    }).catch(() => { done = true; m.close(); reject(new Error('Não consegui abrir a câmera. Libere a permissão e tente de novo.')); });
  });
}

export function importModal() {
  const file = h('input', { type: 'file', accept: '.json,.m3u,.m3u8,.txt,application/json,text/plain', hidden: true });
  const area = h('textarea.input', { rows: 4, placeholder: 'Cole aqui o texto exportado, um link de lista (http://…/get.php?username=…) ou um link .m3u', spellcheck: 'false' });
  const err = h('p.form-err', { role: 'alert' });
  let m;
  const run = async (text, name) => {
    err.textContent = '';
    try {
      const payload = parseLists(text, name);
      await doImport(payload);
      m.close();
    } catch (e) { err.textContent = e.message; }
  };
  file.addEventListener('change', async () => {
    const f = file.files && file.files[0];
    file.value = '';
    if (f) run(await f.text(), f.name);
  });
  const opts = h('div.import-opts',
    h('button.import-opt', { type: 'button', onclick: () => file.click() }, ic('folder'), h('strong', 'Escolher arquivo'), h('small', '.json do Sintonia ou .m3u')),
    canScan() ? h('button.import-opt', { type: 'button', onclick: async () => {
      try { const t = await scanQr(); run(t, 'QR'); } catch (e) { if (!/cancelada/.test(e.message)) err.textContent = e.message; }
    } }, ic('camera'), h('strong', 'Ler QR com a câmera'), h('small', 'do outro aparelho')) : null);
  m = modal(h('div.share-box', opts,
    h('label.field', h('span.field-label', 'Ou cole o texto / link'), area),
    err, file,
    !canScan() ? h('p.hint', 'Para ler QR, use o Sintonia no celular Android (Menu › Fontes e playlists › Importar lista).') : null,
    h('div.modal-actions', btn('Importar texto', { cls: 'primary', icon: 'download', onclick: () => run(area.value) }))),
  { title: 'Importar lista', cls: 'share-modal' });
}

// ---------------------------------------------------------------- outros aparelhos na rede
/**
 * Caixa "Procurar na rede": lista os Sintonia com a sincronização ligada e sincroniza com o escolhido.
 * onSynced(resultado) é chamado depois da primeira sincronização.
 */
export function deviceFinder({ onSynced, autoStart } = {}) {
  const list = h('div.dev-list');
  const me = h('p.hint');
  const search = async () => {
    clear(list).append(h('div.dev-searching', spinner(), h('span', 'Procurando outros Sintonia nesta rede…')));
    let r;
    try {
      if (!S.settings.sync?.enabled) await saveSettings({ sync: { enabled: true }, syncAsked: true });
      r = await api.post('/api/sync/discover');
    } catch (e) { clear(list).append(h('p.form-err', e.message)); return; }
    me.textContent = r.urls && r.urls.length ? `Este aparelho: ${r.self.device} · ${r.urls[0]}` : '';
    clear(list);
    if (!r.devices.length) {
      list.append(h('div.dev-empty', ic('wifi'),
        h('div', h('strong', 'Nenhum outro Sintonia encontrado'),
          h('small', 'No outro aparelho, abra o Sintonia e ligue Menu › Sincronizar aparelhos. Os dois precisam estar no mesmo Wi-Fi.'))),
      btn('Procurar de novo', { cls: 'ghost sm', icon: 'refresh', onclick: search }));
      return;
    }
    r.devices.forEach((d) => {
      const b = btn('Sincronizar', { cls: 'primary sm', onclick: async () => {
        let password = '';
        if (d.needsPassword) {
          password = await promptBox('Esse Sintonia tem senha. Digite a senha dele:', { type: 'password' });
          if (password == null) return;
        }
        b.disabled = true;
        b.textContent = 'Sincronizando…';
        try {
          await saveSettings({ sync: { enabled: true, peer: d.address, password, auto: true }, syncAsked: true });
          const res = await api.post('/api/sync/now');
          await loadState();
          toast(`Sincronizado com ${d.device}`, { type: 'ok' });
          if (onSynced) onSynced(res, d);
        } catch (e) {
          toast(e.message, { type: 'error', ms: 6000 });
        } finally { b.disabled = false; b.textContent = 'Sincronizar'; }
      } });
      const on = S.settings.sync?.peer === d.address;
      list.append(h('div.dev-item', { class: on ? 'on' : '' }, ic('devices'),
        h('div.dev-txt', h('strong', d.device || d.address), h('small', `${d.address} · ${d.sources} lista${d.sources === 1 ? '' : 's'}${on ? ' · conectado' : ''}`)), b));
    });
  };
  const box = h('div.dev-finder', list, me);
  if (autoStart) search(); else list.append(btn('Procurar aparelhos na rede', { cls: 'primary block', icon: 'wifi', onclick: search }));
  box.search = search;
  return box;
}

// ---------------------------------------------------------------- parear por QR (sem digitar IP)
/** Liga a sincronização com o aparelho do QR e já sincroniza. */
export async function pairWith(pair) {
  await saveSettings({ sync: { enabled: true, peer: pair.peer, password: pair.password || '', auto: true }, syncAsked: true });
  const r = await api.post('/api/sync/now');
  await loadState();
  toast(`Sincronizado com ${pair.device || pair.peer}`, { type: 'ok' });
  window.dispatchEvent(new CustomEvent('sintonia:source-changed'));
  return r;
}

/** Mostra o QR deste aparelho: o outro lê e conecta sozinho. */
export async function syncQrModal() {
  if (!S.settings.sync?.enabled) await saveSettings({ sync: { enabled: true }, syncAsked: true });
  const me = await api.get('/api/sync/whoami');
  if (!me.urls.length) { toast('Este aparelho não está em nenhuma rede Wi-Fi agora.', { type: 'error' }); return; }
  const text = JSON.stringify({ sintonia: 'sync', v: 1, peer: me.urls[0], device: me.self.device });
  const qrBox = h('div.qr-box', spinner());
  modal(h('div.share-box', qrBox,
    h('p', h('strong', me.self.device), ` · ${me.urls[0]}`),
    h('p.hint', 'No celular ou tablet: Menu › Sincronizar aparelhos na rede › Ler QR do outro aparelho. Os dois precisam estar no mesmo Wi-Fi.')),
  { title: 'QR para sincronizar', cls: 'share-modal' });
  const QR = await loadQr();
  clear(qrBox).innerHTML = QR.svg(text);
}

/** Lê o QR de outro Sintonia e sincroniza com ele. */
export async function scanPair() {
  const t = await scanQr();
  const p = parseLists(t);
  if (p.pair) return pairWith(p.pair);
  return doImport(p);   // era o QR de uma lista: importa
}
export { canScan };
