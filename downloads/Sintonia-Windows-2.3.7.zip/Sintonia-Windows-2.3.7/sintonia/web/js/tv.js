// Android TV: a mesma interface do celular/tablet, navegada pelo controle remoto (direcional, OK e Voltar).
// Também monta os canais da tela inicial do Android TV e abre os itens clicados lá.
import { currentPlayer, isPlayerOpen, openPlayer } from './player.js';
import { S, canResume, catalog, isFinished, loadCatalog, progressOf } from './state.js';

export const TV = /SintoniaTV/.test(navigator.userAgent) || /[?&]tv=1\b/.test(location.search);
const NATIVE = window.SintoniaNative || null;

// TV box e celulares com pouca memória: sem efeitos de vidro/desfoque (pesam na placa de vídeo)
if (TV || (navigator.deviceMemory && navigator.deviceMemory <= 2)) document.body.classList.add('lowfx');

if (TV) {
  document.body.classList.add('tv');
  // tela de 1280 px de largura: o layout de tablet deitado, ampliado para a TV
  let vp = document.querySelector('meta[name="viewport"]');
  if (!vp) { vp = document.createElement('meta'); vp.name = 'viewport'; document.head.append(vp); }
  vp.content = 'width=1280, user-scalable=no';
}

// ------------------------------------------------------------------ navegação espacial
const FOCUSABLE = 'a[href], button, input, select, textarea, summary, [tabindex]:not([tabindex="-1"])';

function visible(el, r) {
  if (el.disabled) return false;
  r = r || el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return false;
  // checkVisibility é nativo (rápido); evita getComputedStyle em centenas de itens a cada tecla
  if (el.checkVisibility) return el.checkVisibility({ opacityProperty: true, visibilityProperty: true });
  if (el.closest('[hidden], [inert]')) return false;
  const st = getComputedStyle(el);
  return st.visibility !== 'hidden' && +st.opacity !== 0;
}

/** Camada de cima: janela aberta > painel do player > player > app. */
function layer() {
  const backs = document.querySelectorAll('#overlay-root .modal-back');
  if (backs.length) return backs[backs.length - 1];
  const pl = document.querySelector('.player');
  if (pl) {
    const side = pl.querySelector('.pl-side.open');
    return side || pl;
  }
  const search = document.querySelector('.search-ov');
  return search || document.getElementById('app') || document.body;
}

function candidates(root) {
  return [...root.querySelectorAll(FOCUSABLE)].filter((x) => !(x.type === 'range' && x.closest('.player')) && visible(x));
}

/** Melhor item na direção, entre `list` (só olha o que está perto da tela). */
function pick(dir, cur, a, list) {
  const ax = a.left + a.width / 2; const ay = a.top + a.height / 2;
  const far = innerHeight * 2.5;
  let best = null; let bestD = Infinity;
  for (const x of list) {
    if (x === cur || cur.contains(x) || x.contains(cur)) continue;
    const b = x.getBoundingClientRect();
    if (b.bottom < -far || b.top > innerHeight + far || b.width < 2 || b.height < 2) continue;
    const bx = b.left + b.width / 2; const by = b.top + b.height / 2;
    let main; let side; let ok;
    if (dir === 'down') { ok = b.top >= a.bottom - 6 || (by > ay + 8 && b.top > a.top + 4); main = by - ay; side = bx - ax; }
    else if (dir === 'up') { ok = b.bottom <= a.top + 6 || (by < ay - 8 && b.bottom < a.bottom - 4); main = ay - by; side = bx - ax; }
    else if (dir === 'right') { ok = b.left >= a.right - 6 || (bx > ax + 8 && b.left > a.left + 4); main = bx - ax; side = by - ay; }
    else { ok = b.right <= a.left + 6 || (bx < ax - 8 && b.right < a.right - 4); main = ax - bx; side = by - ay; }
    if (!ok || main <= 0) continue;
    // prefere o que está na mesma linha/coluna (o "alinhado")
    const overlap = dir === 'up' || dir === 'down'
      ? Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left))
      : Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const d = main + Math.abs(side) * (overlap > 0 ? 0.6 : 2.4);
    if (d < bestD && visible(x, b)) { bestD = d; best = x; }
  }
  return best;
}

function scroller(el) {
  for (let p = el && el.parentElement; p && p !== document.body; p = p.parentElement) {
    const st = getComputedStyle(p);
    if (/(auto|scroll)/.test(st.overflowY) && p.scrollHeight > p.clientHeight + 4) return p;
  }
  return null;
}

export function focusEl(el) {
  if (!el) return;
  el.focus({ preventScroll: true });
  el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

export function moveFocus(dir, root = layer()) {
  const cur = document.activeElement;
  if (!cur || cur === document.body || !root.contains(cur) || !visible(cur)) {
    const view = root.querySelector('.view');
    const first = (view && candidates(view)[0]) || candidates(root)[0];
    if (first) focusEl(first);
    return !!first;
  }
  const a = cur.getBoundingClientRect();
  // 1º os vizinhos do mesmo grupo (lista de canais, grade de capas, abas): rápido mesmo com milhares de itens
  const sibs = cur.parentElement ? [...cur.parentElement.children].filter((x) => x !== cur && x.matches(FOCUSABLE)) : [];
  let best = sibs.length ? pick(dir, cur, a, sibs) : null;
  if (!best) best = pick(dir, cur, a, root.querySelectorAll(FOCUSABLE));
  if (best) { focusEl(best); return true; }
  // nada naquela direção: rola a lista (carrega mais itens) e tenta de novo
  const sc = scroller(cur);
  if (sc && (dir === 'down' || dir === 'up')) {
    const before = sc.scrollTop;
    sc.scrollBy({ top: dir === 'down' ? 320 : -320 });
    if (sc.scrollTop !== before) setTimeout(() => moveFocus(dir, root), 180);
    return true;
  }
  return false;
}

const DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
const isText = (el) => el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && !['checkbox', 'radio', 'range', 'button', 'submit', 'color'].includes(el.type)));
let playerNav = false;
let lastMove = 0;   // controles do player abertos pelo OK (setas navegam em vez de avançar/trocar canal)

function onKeyCapture(e) {
  const pl = document.querySelector('.player');
  const modalOpen = document.querySelector('#overlay-root .modal-back');
  if (!pl || modalOpen) return;
  const p = currentPlayer();
  const k = e.key;
  // teclas de mídia do controle
  const media = { MediaPlayPause: 'toggle', MediaPlay: 'toggle', MediaPause: 'toggle', MediaFastForward: 'fwd', MediaRewind: 'rew', ChannelUp: 'chUp', ChannelDown: 'chDown', MediaTrackNext: 'next', MediaTrackPrevious: 'prev' }[k];
  if (media && p) {
    e.preventDefault(); e.stopImmediatePropagation();
    if (media === 'toggle') p.togglePlay();
    else if (media === 'fwd' && p.vod) p.seekBy(p.skip);
    else if (media === 'rew' && p.vod) p.seekBy(-p.skip);
    else if (media === 'chUp') p.step(-1);
    else if (media === 'chDown' || media === 'next') p.step(1);
    else if (media === 'prev') p.step(-1);
    p.showUi();
    return;
  }
  const sideOpen = pl.querySelector('.pl-side.open');
  if (k === 'Escape' || k === 'Backspace' || k === 'GoBack') {
    if (sideOpen) return;                                   // o player fecha o painel
    if (playerNav || pl.classList.contains('ui-on')) {       // primeiro esconde os controles
      e.preventDefault(); e.stopImmediatePropagation();
      playerNav = false;
      pl.classList.remove('ui-on');
      pl.focus({ preventScroll: true });
      return;
    }
    return;                                                 // controles escondidos: fecha o player
  }
  if (sideOpen) {
    if (DIRS[k]) { e.preventDefault(); e.stopImmediatePropagation(); moveFocus(DIRS[k], sideOpen); }
    return;
  }
  if (!playerNav) {
    if (k === 'Enter' || k === ' ' || (k === 'ArrowDown' && !(p && p.live)) || k === 'ContextMenu') {
      e.preventDefault(); e.stopImmediatePropagation();
      playerNav = true;
      if (p) p.showUi();
      focusEl(pl.querySelector('.pl-play') || candidates(pl)[0]);
    }
    return;                                                  // setas: avançar/voltar e trocar de canal
  }
  if (DIRS[k]) {
    e.preventDefault(); e.stopImmediatePropagation();
    if (!pl.contains(document.activeElement) || document.activeElement === pl) focusEl(pl.querySelector('.pl-play'));
    else moveFocus(DIRS[k], pl);
    if (p) p.showUi();
  } else if (k === 'Enter' || k === ' ') {
    e.stopImmediatePropagation();                            // o botão focado recebe o clique normal
    if (p) setTimeout(() => p.showUi(), 0);
  }
}

function onKey(e) {
  if (e.defaultPrevented || isPlayerOpen() && !document.querySelector('#overlay-root .modal-back')) return;
  const t = document.activeElement;
  const dir = DIRS[e.key];
  if (dir) {
    if (isText(t) && (dir === 'left' || dir === 'right')) return;   // move o cursor no texto
    // tecla segurada: no máximo ~14 passos por segundo (a TV não engasga e o foco não "some")
    const now = performance.now();
    if (e.repeat && now - lastMove < 70) { e.preventDefault(); return; }
    lastMove = now;
    if (t && t.tagName === 'SELECT') return;
    if (t && t.matches('input[type="range"]') && (dir === 'left' || dir === 'right')) return;
    e.preventDefault();
    moveFocus(dir);
    return;
  }
  if (e.key === 'Enter') {
    if (isText(t)) { if (NATIVE && NATIVE.keyboard) NATIVE.keyboard(); return; }
    if (t && t !== document.body && !t.matches('a[href], button, input, select, textarea, summary')) { e.preventDefault(); t.click(); }
    return;
  }
  if (e.key === 'ContextMenu' && t && t !== document.body) {
    e.preventDefault();
    const r = t.getBoundingClientRect();
    t.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 }));
  }
}

/** Depois de trocar de tela, deixa o foco no primeiro item do conteúdo. */
function focusView() {
  setTimeout(() => {
    const a = document.activeElement;
    if (isPlayerOpen() || document.querySelector('#overlay-root .modal-back')) return;
    if (a && a !== document.body && document.body.contains(a) && visible(a)) return;
    const view = document.querySelector('.view');
    const first = view && candidates(view).find((x) => !x.matches('input'));
    focusEl(first || document.querySelector('.nav-item.on') || document.querySelector('.nav-item'));
  }, 450);
}

if (TV) {
  window.addEventListener('keydown', onKeyCapture, true);
  document.addEventListener('keydown', onKey);
  window.addEventListener('hashchange', focusView);
  let backTo = null;   // item que abriu o player: o foco volta para ele ao fechar
  document.addEventListener('focusin', (e) => { if (!e.target.closest('.player, #overlay-root')) backTo = e.target; });
  window.addEventListener('sintonia:player-closed', () => {
    playerNav = false;
    setTimeout(() => { if (backTo && document.body.contains(backTo) && visible(backTo)) focusEl(backTo); else focusView(); }, 250);
  });
  // o player esconde os controles sozinho: volta para o modo "setas avançam"
  new MutationObserver(() => {
    const pl = document.querySelector('.player');
    if (playerNav && pl && !pl.classList.contains('ui-on') && !pl.querySelector('.pl-side.open')) playerNav = false;
  }).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['class'] });
  // fechou uma janela: o foco volta para a tela (o controle nunca fica "perdido")
  new MutationObserver(() => {
    if (!document.querySelector('#overlay-root .modal-back')) focusView();
  }).observe(document.getElementById('overlay-root') || document.body, { childList: true });
  focusView();
}

// ------------------------------------------------------------------ canais na tela inicial do Android TV
function link(q) {
  return `sintonia://open?${Object.keys(q).map((k) => `${k}=${encodeURIComponent(q[k])}`).join('&')}`;
}
const clean = (n) => String(n || '').replace(/\s*[(\[](19|20)\d\d[)\]]\s*$/, '');
const fmt = (s) => { s = Math.floor(s || 0); const hh = Math.floor(s / 3600); const mm = Math.floor((s % 3600) / 60); const ss = s % 60; return (hh ? `${hh}:${String(mm).padStart(2, '0')}` : String(mm)) + `:${String(ss).padStart(2, '0')}`; };

let homeT = null;
export function pushHome() {
  if (!NATIVE || !NATIVE.updateHome || !S.user) return;
  clearTimeout(homeT);
  homeT = setTimeout(buildHome, 2500);
}
function buildHome() {
  const out = { continuar: [], favoritos: [], sugestoes: [] };
  const seen = new Set();
  for (const e of S.user.history || []) {
    const ep = e.kind === 'episode';
    const key = ep ? `s${e.seriesId}` : `m${e.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    if (!canResume(e) || isFinished(e)) continue;
    out.continuar.push({ key: e.kind + e.id, type: ep ? 'episode' : 'movie', title: clean(ep ? e.seriesName : e.name),
      desc: (ep ? `T${e.season} E${e.episode} · ` : '') + `Continuar de ${fmt(e.pos)}`, img: e.img || '', pos: e.pos, dur: e.dur, t: (e.ts || 0) * 1000 || Date.now(),
      uri: link(ep ? { a: 'resume', k: 'episode', id: e.id, s: e.seriesId || '', n: e.seriesName || '' } : { a: 'resume', k: 'movie', id: e.id }) });
    if (out.continuar.length >= 20) break;
  }
  const live = catalog('live');
  if (live) {
    for (const id of (S.user.favorites?.live || []).slice(0, 25)) {
      const ch = live.byId.get(String(id));
      if (ch) out.favoritos.push({ key: `live${ch.id}`, type: 'live', title: ch.name, desc: 'Ao vivo', img: ch.logo || '', uri: link({ a: 'play', k: 'live', id: ch.id }) });
    }
  }
  for (const kind of ['movie', 'series']) {
    const c = catalog(kind);
    if (!c || c.lazy) continue;
    c.items.filter((it) => it.poster && (it.rating || 0) >= 6.5).sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 12).forEach((it) => {
      out.sugestoes.push({ key: kind + it.id, type: kind === 'movie' ? 'movie' : 'series', title: clean(it.name),
        desc: `${it.year ? `${it.year} · ` : ''}★ ${String(it.rating).replace('.', ',')}`, img: it.poster, uri: link({ a: 'detail', k: kind, id: it.id }) });
    });
  }
  try { NATIVE.updateHome(JSON.stringify(out)); } catch { /* app antigo */ }
}

/** Carrega os catálogos em segundo plano e publica os canais (só no app Android TV). */
export function startHomeChannels() {
  if (!NATIVE || !NATIVE.updateHome) return;
  // espera o app assentar: carregar catálogos grandes logo de cara deixava o 1º canal lento na TV box
  const idle = window.requestIdleCallback || ((fn) => setTimeout(fn, 2000));
  setTimeout(() => idle(async () => {
    for (const k of ['live', 'movie', 'series']) {
      if (isPlayerOpen()) await new Promise((r) => window.addEventListener('sintonia:player-closed', r, { once: true }));
      try { await loadCatalog(k); } catch { /* ok */ }
    }
    pushHome();
  }), 45000);
  window.addEventListener('sintonia:player-closed', pushHome);
  document.addEventListener('visibilitychange', () => { if (document.hidden && S.user) { clearTimeout(homeT); buildHome(); } });
}

/** Item clicado nos canais da tela inicial (sintonia://open?…). */
window.sintoniaOpen = async (q, tries = 0) => {
  if (!q || !q.a || q.a === 'home') return;
  if (!S.active || !S.user) { if (tries < 30) setTimeout(() => window.sintoniaOpen(q, tries + 1), 500); return; }
  try {
    if (q.k === 'live') {
      const c = await loadCatalog('live');
      const ch = c.byId.get(String(q.id));
      if (!ch) return;
      const favs = (S.user?.favorites?.live || []).map((id) => c.byId.get(String(id))).filter(Boolean);
      openPlayer({ kind: 'live', item: ch, list: favs.includes(ch) ? favs : [ch] });
    } else if (q.a === 'detail') {
      location.hash = q.k === 'movie' ? `#/movie/${encodeURIComponent(q.id)}` : `#/serie/${encodeURIComponent(q.id)}`;
    } else if (q.k === 'movie') {
      const c = await loadCatalog('movie');
      const it = c.byId.get(String(q.id));
      if (!it) { location.hash = `#/movie/${encodeURIComponent(q.id)}`; return; }
      const p = progressOf('movie', it.id);
      openPlayer({ kind: 'movie', item: it, startAt: canResume(p) ? p.pos : 0 });
    } else if (q.k === 'episode' && q.s) {
      window.__sintoniaAutoplay = String(q.id);      // a página da série abre o episódio sozinha
      location.hash = `#/serie/${encodeURIComponent(q.s)}`;
    }
  } catch { /* item sumiu da lista */ }
};
