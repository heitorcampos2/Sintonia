// Motores de reprodução: HLS (hls.js ou nativo), MPEG-TS (mpegts.js) e nativo.
const LIBS = {
  hls: { global: 'Hls', urls: ['/vendor/hls.min.js', 'https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js'] },
  mpegts: { global: 'mpegts', urls: ['/vendor/mpegts.js', 'https://cdn.jsdelivr.net/npm/mpegts.js@1/dist/mpegts.js'] },
};
const loading = {};

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => { s.remove(); reject(new Error('falha ao carregar ' + src)); };
    document.head.append(s);
  });
}

export function lib(name) {
  const L = LIBS[name];
  if (window[L.global]) return Promise.resolve(window[L.global]);
  if (!loading[name]) {
    loading[name] = (async () => {
      for (const u of L.urls) {
        try {
          await loadScript(u);
          if (window[L.global]) return window[L.global];
        } catch { /* tenta o próximo */ }
      }
      loading[name] = null;
      throw new Error('lib-indisponivel');
    })();
  }
  return loading[name];
}

export function guessType(url) {
  const path = String(url).split('?')[0].toLowerCase();
  if (path.endsWith('.m3u8') || path.endsWith('.m3u')) return 'hls';
  if (path.endsWith('.ts')) return 'ts';
  if (/\.(mp4|m4v|mkv|webm|mov|mp3|aac|ogg)$/.test(path)) return 'native';
  return null;
}

const nativeHls = (v) => !!v.canPlayType('application/vnd.apple.mpegurl');

// Perfis de estabilidade: quanto maior, mais vídeo fica guardado à frente e mais o player insiste antes de desistir.
export const MODES = {
  low: { label: 'Latência baixa', buf: 8, maxBuf: 20, size: 40, live: 2, back: 10, chase: true, latency: 2.5, persist: false },
  normal: { label: 'Normal', buf: 30, maxBuf: 90, size: 80, live: 3, back: 30, chase: true, latency: 6, persist: false },
  high: { label: 'Alto', buf: 90, maxBuf: 300, size: 160, live: 5, back: 60, chase: false, latency: 12, persist: false },
  max: { label: 'Máximo', buf: 300, maxBuf: 900, size: 300, live: 7, back: 90, chase: false, latency: 30, persist: true },
  ultra: { label: 'Ultra extremo', buf: 1800, maxBuf: 7200, size: 900, live: 10, back: 120, chase: false, latency: 60, persist: true },
};
// TV box e aparelhos com pouca memória: guarda menos vídeo na memória (fica mais leve e não engasga)
const lowMem = () => document.body.classList.contains('tv') || !!(navigator.deviceMemory && navigator.deviceMemory <= 2);
function profile(mode) {
  const M = MODES[mode] || MODES.normal;
  if (!lowMem()) return M;
  return { ...M, buf: Math.min(M.buf, 120), maxBuf: Math.min(M.maxBuf, 240), size: Math.min(M.size, 120), back: Math.min(M.back, 30) };
}

/** Baixa os componentes de vídeo antes do primeiro play (o 1º canal abre mais rápido). */
export function preload(first = 'ts') {
  const order = first === 'hls' || first === 'm3u8' ? ['hls', 'mpegts'] : ['mpegts', 'hls'];
  const idle = window.requestIdleCallback || ((fn) => setTimeout(fn, 1500));
  idle(() => { lib(order[0]).catch(() => {}).then(() => idle(() => lib(order[1]).catch(() => {}))); });
}

const forever = (first = 1000, max = 8000) => ({ maxNumRetry: 1e6, retryDelayMs: first, maxRetryDelayMs: max });

function base(video, type) {
  const fatal = new Set();
  const infoCbs = new Set();
  let extra = {};
  return {
    type, video,
    onFatal(cb) { fatal.add(cb); },
    fire(err) { fatal.forEach((cb) => cb(err)); },
    onInfo(cb) { infoCbs.add(cb); },
    setExtra(e) { extra = { ...extra, ...e }; infoCbs.forEach((cb) => cb()); },
    info() {
      return { width: video.videoWidth, height: video.videoHeight, ...extra };
    },
    levels: () => [], level: -1, setLevel() {},
    audioTracks() {
      const t = video.audioTracks;
      if (!t || t.length < 2) return [];
      return Array.from(t).map((x, i) => ({ id: i, name: x.label || x.language || `Faixa ${i + 1}`, lang: x.language, on: x.enabled }));
    },
    setAudio(i) {
      const t = video.audioTracks;
      if (t) Array.from(t).forEach((x, k) => { x.enabled = k === i; });
    },
    destroy() {},
  };
}

function attachNative(video, url, type = 'native') {
  const c = base(video, type);
  const onErr = () => {
    const e = video.error;
    c.fire(new Error(e ? `Erro de mídia (${e.code})` : 'Erro de mídia'));
  };
  video.addEventListener('error', onErr);
  video.src = url;
  c.destroy = () => {
    video.removeEventListener('error', onErr);
    video.removeAttribute('src');
    video.load();
  };
  return c;
}

async function attachHls(video, url, live, mode) {
  const M = profile(mode);
  let Hls = null;
  try { Hls = await lib('hls'); } catch { Hls = null; }
  if (!Hls || !Hls.isSupported()) {
    if (nativeHls(video)) return attachNative(video, url, 'hls-nativo');
    throw new Error('Este navegador não consegue reproduzir HLS (não foi possível carregar o hls.js).');
  }
  const c = base(video, 'hls');
  const cfg = {
    enableWorker: true, lowLatencyMode: false, backBufferLength: M.back,
    maxBufferLength: M.buf, maxMaxBufferLength: M.maxBuf, maxBufferSize: M.size * 1000 * 1000,
    liveSyncDurationCount: M.live, liveMaxLatencyDurationCount: M.persist ? Infinity : M.live + 6,
    maxBufferHole: 0.5, nudgeMaxRetry: 10,
    startFragPrefetch: true,          // já baixa o 1º pedaço enquanto prepara o vídeo
    testBandwidth: false, startLevel: -1,
  };
  if (M.persist) {
    // sem internet: continua tocando o que já está guardado e tenta de novo sem parar
    const pol = (ttfb, load) => ({ default: { maxTimeToFirstByteMs: ttfb, maxLoadTimeMs: load, timeoutRetry: forever(), errorRetry: forever() } });
    cfg.fragLoadPolicy = pol(15000, 120000);
    cfg.playlistLoadPolicy = pol(10000, 30000);
    cfg.manifestLoadPolicy = { default: { maxTimeToFirstByteMs: 15000, maxLoadTimeMs: 30000, timeoutRetry: { maxNumRetry: 4, retryDelayMs: 1000, maxRetryDelayMs: 4000 }, errorRetry: { maxNumRetry: 4, retryDelayMs: 1000, maxRetryDelayMs: 4000 } } };
  }
  const hls = new Hls(cfg);
  let started = false;
  video.addEventListener('playing', () => { started = true; }, { once: true });
  let mediaRecovered = 0;
  let netRetry = 0;
  hls.on(Hls.Events.ERROR, (_e, d) => {
    if (!d.fatal) return;
    if (d.type === Hls.ErrorTypes.NETWORK_ERROR && (netRetry < 2 || (M.persist && started))) {
      netRetry++;
      c.setExtra({ offline: true });
      setTimeout(() => { try { hls.startLoad(); } catch { /* destruído */ } }, Math.min(8000, 1000 * netRetry));
      return;
    }
    if (d.type === Hls.ErrorTypes.MEDIA_ERROR && mediaRecovered < 2) { mediaRecovered++; hls.recoverMediaError(); return; }
    c.fire(new Error(d.details || 'Falha no HLS'));
  });
  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    const lv = hls.levels[0];
    c.setExtra({ vcodec: lv?.videoCodec || '', acodec: lv?.audioCodec || '' });
  });
  hls.on(Hls.Events.FRAG_LOADED, () => { netRetry = 0; if (c.info().offline) c.setExtra({ offline: false }); });
  hls.on(Hls.Events.LEVEL_SWITCHED, (_e, d) => {
    const lv = hls.levels[d.level];
    if (lv) c.setExtra({ vcodec: lv.videoCodec || '', acodec: lv.audioCodec || '', fps: lv.frameRate || 0, bitrate: lv.bitrate });
  });
  hls.loadSource(url);
  hls.attachMedia(video);
  c.levels = () => hls.levels.map((l, i) => ({ id: i, height: l.height, bitrate: l.bitrate }));
  Object.defineProperty(c, 'level', { get: () => (hls.autoLevelEnabled ? -1 : hls.currentLevel) });
  c.setLevel = (i) => { hls.currentLevel = i; };
  c.audioTracks = () => (hls.audioTracks.length > 1
    ? hls.audioTracks.map((t, i) => ({ id: i, name: t.name || t.lang || `Faixa ${i + 1}`, lang: t.lang, on: i === hls.audioTrack }))
    : []);
  c.setAudio = (i) => { hls.audioTrack = i; };
  c.destroy = () => { hls.destroy(); video.removeAttribute('src'); video.load(); };
  return c;
}

async function attachTs(video, url, live, mode) {
  const M = profile(mode);
  const mpegts = await lib('mpegts').catch(() => null);
  if (!mpegts) throw new Error('lib-indisponivel');
  const feats = mpegts.getFeatureList();
  if (!mpegts.isSupported() || (live && !feats.mseLivePlayback)) throw new Error('ts-sem-suporte');
  const c = base(video, 'ts');
  const player = mpegts.createPlayer({ type: 'mpegts', isLive: !!live, url }, {
    enableWorker: true, lazyLoad: !live && !M.persist, lazyLoadMaxDuration: M.buf, lazyLoadRecoverDuration: Math.max(30, M.buf / 2),
    liveBufferLatencyChasing: !!live && M.chase, liveBufferLatencyMaxLatency: M.latency, liveBufferLatencyMinRemain: Math.min(3, M.latency / 2),
    autoCleanupSourceBuffer: true, autoCleanupMaxBackwardDuration: M.back, autoCleanupMinBackwardDuration: Math.max(10, M.back / 2),
    // ao vivo começa com pouco (antes juntava 2 MB, uns 4 s de vídeo, antes de mostrar a imagem)
    enableStashBuffer: true, stashInitialSize: (live ? 48 : 384) * 1024,   // 2.3.2: ao vivo começa a decodificar com menos dados
  });
  player.on(mpegts.Events.ERROR, (type, detail) => c.fire(new Error(`${type}: ${detail}`)));
  player.on(mpegts.Events.MEDIA_INFO, (mi) => {
    c.setExtra({ vcodec: mi.videoCodec || '', acodec: mi.audioCodec || '', fps: mi.fps || 0,
      channels: mi.audioChannelCount || 0, width: mi.width, height: mi.height });
  });
  player.attachMediaElement(video);
  player.load();
  c.destroy = () => {
    try { player.pause(); player.unload(); player.detachMediaElement(); player.destroy(); } catch { /* ignora */ }
  };
  return c;
}

/** Liga a fonte ao <video>. type: hls | ts | native | auto */
export async function attach(video, { url, type, live, mode }) {
  // endereço absoluto: o mpegts.js busca o vídeo dentro de um Worker, que não entende "/relay/..."
  url = new URL(url, location.href).href;
  if (type === 'auto' || !type) type = guessType(url) || 'ts';
  if (type === 'hls') return attachHls(video, url, live, mode);
  if (type === 'ts') return attachTs(video, url, live, mode);
  return attachNative(video, url);
}

/** Conta quadros por segundo de verdade, quando o navegador permite. */
export function measureFps(video, cb) {
  if (!('requestVideoFrameCallback' in HTMLVideoElement.prototype)) return () => {};
  let stop = false;
  let first = null;
  let frames = 0;
  const tick = (_now, meta) => {
    if (stop) return;
    if (first === null) first = meta.mediaTime;
    frames++;
    const span = meta.mediaTime - first;
    if (span >= 2) {
      cb(Math.round(frames / span));
      first = meta.mediaTime;
      frames = 0;
    }
    video.requestVideoFrameCallback(tick);
  };
  video.requestVideoFrameCallback(tick);
  return () => { stop = true; };
}
