"""Sintonia — player IPTV que roda como servidor e abre em qualquer navegador."""

VERSION = "2.0.7"
