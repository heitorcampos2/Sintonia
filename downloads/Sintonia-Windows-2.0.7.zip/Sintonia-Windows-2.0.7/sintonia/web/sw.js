// Service worker: guarda a interface para abrir rápido. Dados e vídeo sempre vêm da rede.
const CACHE = 'sintonia-v17';
const SHELL = ['/', '/index.html', '/app.css', '/manifest.webmanifest', '/icons/icon.svg', '/icons/icon-192.png',
  '/js/main.js', '/js/api.js', '/js/state.js', '/js/ui.js', '/js/icons.js', '/js/player.js', '/js/engines.js',
  '/js/views/common.js', '/js/views/live.js', '/js/views/vod.js', '/js/views/detail.js', '/js/views/offline.js',
  '/js/views/search.js', '/js/views/guide.js', '/js/views/multi.js', '/js/views/menu.js', '/js/views/onboarding.js', '/js/views/share.js', '/js/views/update.js', '/js/lib/qr.js'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  if (/^\/(api|p|files|img)\//.test(url.pathname)) return;
  e.respondWith(fetch(e.request).then((res) => {
    if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
    return res;
  }).catch(() => caches.match(e.request).then((r) => r || caches.match('/index.html'))));
});
