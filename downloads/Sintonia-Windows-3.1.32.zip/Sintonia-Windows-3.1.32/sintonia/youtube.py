"""Canais YouTube (2.3.9) — busca de canais e transmissão ao vivo, do jeito do SmartTube.

Busca pelo cliente Web da API interna do YouTube, a página /live do canal diz se ele está ao vivo
(o endereço canônico vira o do vídeo) e o cliente Android entrega o link HLS do vídeo ao vivo.
"""

import json
import urllib.parse
import re
import threading
import time

from . import net, proxy

WEB = {"clientName": "WEB", "clientVersion": "2.20260907.05.00", "hl": "pt", "gl": "BR"}
AND = {"clientName": "ANDROID", "clientVersion": "21.26.364", "osName": "Android", "osVersion": "11",
       "androidSdkVersion": 30, "hl": "pt", "gl": "BR"}
UA_WEB = net.BROWSER_UA
UA_AND = "com.google.android.youtube/21.26.364 (Linux; U; Android 11) gzip"
CNN = {"id": "UCvdwhh_fDyWccR42-rReZLw", "name": "CNN Brasil", "thumb": ""}
CAZETV = {"id": "UCZiYbVptd3PVPf4f6eR6UaQ", "name": "CazéTV", "thumb": ""}
_CANON = re.compile(rb'<link rel="canonical" href="https://www\.youtube\.com/(?:watch\?v=([\w-]{11})|channel/)')
_cache = {}
_lock = threading.Lock()


class YtError(Exception):
    pass


def _api(ep, client, ua, body, timeout=15):
    body = dict(body, context={"client": client})
    try:
        with net.open_url("https://www.youtube.com/youtubei/v1/%s?prettyPrint=false" % ep,
                          headers={"Content-Type": "application/json", "User-Agent": ua, "Origin": "https://www.youtube.com"},
                          data=json.dumps(body).encode("utf-8"), method="POST", timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:  # noqa: BLE001
        raise YtError("Sem conexão com o YouTube (%s)" % e) from e


def _pic(thumbs):
    u = ((thumbs or [{}])[-1] or {}).get("url", "")
    return "https:" + u if u.startswith("//") else u


def _txt(o):
    if not o:
        return ""
    return o.get("simpleText") or "".join(r.get("text", "") for r in o.get("runs", []))


def search(q):
    r = _api("search", WEB, UA_WEB, {"query": q, "params": "EgIQAg%3D%3D"})
    out = []

    def walk(o):
        if isinstance(o, dict):
            c = o.get("channelRenderer")
            if c:
                if c.get("channelId"):
                    out.append({"id": c["channelId"], "name": _txt(c.get("title")), "thumb": _pic((c.get("thumbnail") or {}).get("thumbnails")),
                                "subs": _txt(c.get("videoCountText")) or _txt(c.get("subscriberCountText"))})
                return
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(r)
    return out


def live_id(channel_id, timeout=15):
    """Vídeo ao vivo agora do canal ('' se não está). Para de ler assim que acha o endereço canônico."""
    url = "https://www.youtube.com/channel/%s/live" % channel_id
    try:
        with net.open_url(url, headers={"User-Agent": UA_WEB, "Accept-Language": "pt-BR,pt;q=0.9", "Cookie": "CONSENT=YES+1; SOCS=CAI"}, timeout=timeout) as r:
            buf = b""
            while True:
                chunk = r.read(65536)
                if not chunk:
                    return ""
                buf = buf[-500:] + chunk
                m = _CANON.search(buf)
                if m:
                    return (m.group(1) or b"").decode()
    except Exception as e:  # noqa: BLE001
        raise YtError("Sem conexão com o YouTube (%s)" % e) from e


def player(vid):
    r = _api("player", AND, UA_AND, {"videoId": vid, "contentCheckOk": True, "racyCheckOk": True})
    vd, ps = r.get("videoDetails") or {}, r.get("playabilityStatus") or {}
    return {"ok": ps.get("status") == "OK", "live": bool(vd.get("isLive")), "title": vd.get("title", ""),
            "hls": (r.get("streamingData") or {}).get("hlsManifestUrl", ""), "reason": ps.get("reason", "")}


def status(channel_id, force=False):
    """{live, vid, title, hls}; guardado por 3 min."""
    with _lock:
        c = _cache.get(channel_id)
    if c and not force and time.time() - c["t"] < 180:
        return c["st"]
    vid = live_id(channel_id)
    st = {"live": False}
    if vid:
        p = player(vid)
        st = {"live": bool(p["ok"] and p["live"] and p["hls"]), "vid": vid, "title": p["title"], "hls": p["hls"], "reason": p["reason"]}
    with _lock:
        _cache[channel_id] = {"t": time.time(), "st": st}
    return st


def public(st):
    """Situação sem o link do vídeo (ele só sai pelo /play, passando pelo Sintonia)."""
    return {k: v for k, v in st.items() if k != "hls"}


def play_url(channel_id, fresh=False):
    """fresh: consulta o canal de novo (a transmissão que estava passando terminou ou deu erro)."""
    st = status(channel_id, force=fresh)
    if not st.get("live") and not fresh:
        st = status(channel_id, force=True)
    if not st.get("live"):
        raise YtError("Este canal não está ao vivo agora")
    # o navegador não pode buscar o vídeo do YouTube direto (CORS): passa pelo Sintonia
    return {"url": proxy.proxied("yt", st["hls"]), "type": "hls", "live": True, "title": st.get("title", ""), "vid": st.get("vid", ""),
            "direct": st["hls"]}


# ====================================================================== 2.5.1: vídeos comuns (só no app Android)
# Mesma ideia da TV Android: clientes da API em ordem (lista do SmartTube, atualizada pelo GitHub do Sintonia),
# sem o token anti-robô — a qualidade é a que o YouTube libera (360p na maioria dos vídeos).
CFG_URL = "https://raw.githubusercontent.com/heitorcampos2/Sintonia/main/docs/yt-clients.json"
_cfg = {"t": 0, "data": None}
_last_good = {"name": ""}
_DEFAULT_CLIENTS = {
    "WEB": ({"clientName": "WEB", "clientVersion": "2.20260907.06.00"}, UA_WEB),
    "ANDROID": ({"clientName": "ANDROID", "clientVersion": "21.26.364", "osName": "Android", "osVersion": "11", "androidSdkVersion": 30}, UA_AND),
    "IOS": ({"clientName": "IOS", "clientVersion": "21.26.4", "deviceMake": "Apple", "deviceModel": "iPhone16,2", "osName": "iPhone", "osVersion": "18.3.2.22D82"},
            "com.google.ios.youtube/21.26.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"),
    "ANDROID_VR": ({"clientName": "ANDROID_VR", "clientVersion": "1.65.10", "osName": "Android", "osVersion": "12", "androidSdkVersion": 32, "deviceMake": "Oculus", "deviceModel": "Quest 3"},
                   "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"),
}
SB_CATS = ["sponsor", "selfpromo", "interaction", "intro", "outro", "music_offtopic"]


def _config():
    if _cfg["data"] is None or time.time() - _cfg["t"] > 86400:
        _cfg["t"] = time.time()
        try:
            with net.open_url(CFG_URL, timeout=10) as r:
                d = json.loads(r.read().decode("utf-8"))
            if isinstance(d.get("clients"), dict) and d["clients"].get("ANDROID"):
                _cfg["data"] = d
        except Exception:  # noqa: BLE001 - fica com a lista embutida
            pass
    return _cfg["data"] or {}


def _client(name):
    c = (_config().get("clients") or {}).get(name)
    if c and c.get("context") and c.get("ua"):
        return dict(c["context"], hl="pt", gl="BR"), c["ua"]
    d = _DEFAULT_CLIENTS.get(name)
    return (dict(d[0], hl="pt", gl="BR"), d[1]) if d else (None, None)


def _call(ep, name, body):
    ctx, ua = _client(name)
    return _api(ep, ctx, ua, body)


def _video_items(r):
    out, nxt = [], [None]

    def lockup(l):
        if l.get("contentType") and l["contentType"] != "LOCKUP_CONTENT_TYPE_VIDEO":
            return None
        vid = l.get("contentId") or ""
        if not re.fullmatch(r"[\w-]{11}", vid):
            return None
        img0 = json.dumps(l.get("contentImage") or {})
        dm = re.search(r'"text": ?"(\d+:\d{2}(?::\d{2})?)"', img0)
        if not dm:
            return None   # ao vivo / agendado
        md = (l.get("metadata") or {}).get("lockupMetadataViewModel") or {}
        srcs = (((l.get("contentImage") or {}).get("thumbnailViewModel") or {}).get("image") or {}).get("sources") or []
        rows = []
        for rw in ((md.get("metadata") or {}).get("contentMetadataViewModel") or {}).get("metadataRows") or []:
            parts = [((p.get("text") or {}).get("content") or "") for p in rw.get("metadataParts") or []]
            if any(parts):
                rows.append(" · ".join(x for x in parts if x))
        return {"id": vid, "title": (md.get("title") or {}).get("content", ""), "dur": dm.group(1), "meta": " · ".join(rows),
                "thumb": (srcs[-1] if srcs else {}).get("url") or f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg"}

    def vrend(v):
        if not v.get("videoId") or not v.get("lengthText"):
            return None
        return {"id": v["videoId"], "title": _txt(v.get("title")), "dur": _txt(v.get("lengthText")),
                "thumb": f"https://i.ytimg.com/vi/{v['videoId']}/mqdefault.jpg",
                "meta": " · ".join(x for x in (_txt(v.get("ownerText")), _txt(v.get("viewCountText")), _txt(v.get("publishedTimeText"))) if x)}

    def walk(o):
        if isinstance(o, dict):
            if "lockupViewModel" in o:
                a = lockup(o["lockupViewModel"])
                if a:
                    out.append(a)
                return
            if "videoRenderer" in o:
                b = vrend(o["videoRenderer"])
                if b:
                    out.append(b)
                return
            if "continuationCommand" in o and not nxt[0]:
                nxt[0] = (o["continuationCommand"] or {}).get("token")
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(r)
    return {"items": out, "next": nxt[0]}


def channel_videos(channel_id, nxt=None):
    body = {"continuation": nxt} if nxt else {"browseId": channel_id, "params": "EgZ2aWRlb3PyBgQKAjoA"}
    return _video_items(_call("browse", "WEB", body))


def search_videos(q, nxt=None):
    body = {"continuation": nxt} if nxt else {"query": q, "params": "EgIQAQ%3D%3D"}
    return _video_items(_call("search", "WEB", body))


def vod(video_id):
    """Link do vídeo para o navegador: HLS ou vídeo com áudio junto (o <video> não junta áudio separado)."""
    order = [n for n in (_config().get("vodOrder") or ["IOS", "ANDROID_VR", "ANDROID"]) if _client(n)[0]]
    if _last_good["name"] in order:
        order.remove(_last_good["name"])
        order.insert(0, _last_good["name"])
    errs = []
    for name in order:
        try:
            r = _call("player", name, {"videoId": video_id, "contentCheckOk": True, "racyCheckOk": True})
        except YtError as e:
            errs.append(str(e))
            continue
        ps, sd, vd = r.get("playabilityStatus") or {}, r.get("streamingData") or {}, r.get("videoDetails") or {}
        if ps.get("status") != "OK":
            errs.append(ps.get("reason") or ps.get("status") or "indisponível")
            continue
        base = {"title": vd.get("title", ""), "author": vd.get("author", ""), "len": int(vd.get("lengthSeconds") or 0), "client": name}
        if sd.get("hlsManifestUrl"):
            _last_good["name"] = name
            return dict(base, url=proxy.proxied("yt", sd["hlsManifestUrl"]), type="hls", q="auto")
        mux = sorted([f for f in sd.get("formats") or [] if f.get("url")], key=lambda f: -(f.get("height") or 0))
        if mux:
            _last_good["name"] = name
            return dict(base, url=mux[0]["url"], type="native", q="%dp" % (mux[0].get("height") or 360))
        errs.append("sem link")
    raise YtError(errs[-1] if errs else "o YouTube não liberou este vídeo")


def sponsor(video_id):
    """SponsorBlock (público): [[início, fim], …] em segundos."""
    url = "https://sponsor.ajay.app/api/skipSegments?videoID=%s&categories=%s" % (video_id, urllib.parse.quote(json.dumps(SB_CATS)))
    try:
        with net.open_url(url, headers={"User-Agent": "Sintonia"}, timeout=8) as r:
            return [x["segment"] for x in json.loads(r.read().decode("utf-8")) if x.get("segment") and x["segment"][1] > x["segment"][0]]
    except Exception:  # noqa: BLE001 - 404 = vídeo sem trechos marcados
        return []
