import { api } from './api.js';
import { attach, lib, measureFps } from './engines.js';
import { S, addRecent, base, removeRecent, canResume, isFav, progressOf, s24, saveProgress, sectionPrefs, toggleFav, src } from './state.js';
import { btn, clear, copyText, downloadText, fmtDur, fmtTime, h, ic, iconBtn, menu, modal, pic, toast } from './ui.js';

let current = null;

/** Testa o canal pelo servidor e pelo navegador e mostra um relatório legível. */
export async function diagnose(ch, attempts = []) {
  const pre = h('pre.diag-out', 'Testando o canal, aguarde…');
  const m = modal(h('div', pre, h('div.modal-actions',
    btn('Copiar relatório', { cls: 'ghost', icon: 'copy', onclick: () => copyText(pre.textContent) }),
    btn('Fechar', { cls: 'primary', onclick: () => m.close() }))), { title: `Diagnóstico: ${ch.name}`, cls: 'wide' });
  const lines = [];
  const add = (t) => { lines.push(t); pre.textContent = lines.join('\n'); };
  add(`Sintonia ${S.version} · ${navigator.userAgent.replace(/^Mozilla\/5\.0 /, '')}`);
  const mp4 = (c) => (window.MediaSource && window.MediaSource.isTypeSupported(`video/mp4; codecs="${c}"`) ? 'sim' : 'não');
  add(`Navegador: MSE ${window.MediaSource ? 'sim' : 'não'} · H.264 ${mp4('avc1.640028,mp4a.40.2')} · H.265 ${mp4('hvc1.1.6.L120.90')} · HLS nativo ${document.createElement('video').canPlayType('application/vnd.apple.mpegurl') ? 'sim' : 'não'}`);
  for (const name of ['mpegts', 'hls']) {
    try { await lib(name); add(`Componente ${name}: carregado`); } catch { add(`Componente ${name}: NÃO carregou (sem internet no servidor e no navegador?)`); }
  }
  add('');
  add('Teste no servidor (pedindo o canal ao provedor):');
  try {
    const r = await api.post(`${base()}/diagnose`, { id: ch.id, cmd: ch.cmd });
    add(`  Componentes guardados no servidor: hls ${r.vendor['hls.min.js'] ? 'sim' : 'não'}, mpegts ${r.vendor['mpegts.js'] ? 'sim' : 'não'}`);
    add(`  User-Agent configurado: ${r.ua} · Estabilidade: ${r.buffer} · Proxy: ${r.proxy ? 'sim' : 'não'}`);
    r.tests.forEach((t) => {
      add(`  ${t.fmt || ''} · UA ${t.ua || '-'} · ${t.status ?? ''} · ${t.ms ?? '?'} ms → ${t.kind}`);
      if (t.ctype) add(`      tipo: ${t.ctype}`);
      if (t.final && t.final !== t.url) add(`      redirecionou para: ${t.final}`);
    });
    if (r.tests[0]?.url) add(`  endereço: ${r.tests[0].url}`);
  } catch (e) { add(`  falhou: ${e.message}`); }
  if (attempts.length) { add(''); add('Tentativas do player:'); attempts.forEach((a) => add('  ' + a)); }
}

export function isPlayerOpen() { return !!current; }
export function closePlayer() { if (current) current.close(); }

// Imagem no canto (PiP) do app Android: o app avisa quando entra/sai e manda os botões da janelinha
const NATIVE_PIP = typeof window !== 'undefined' && window.SintoniaPip && window.SintoniaPip.supported && window.SintoniaPip.supported();
window.sintoniaPip = (on) => {
  document.body.classList.toggle('pip-mode', !!on);
  if (current) { if (on) current.hideUi(); else current.showUi(); }
};
window.sintoniaPipAction = (a) => {
  if (!current) return;
  if (a === 'toggle') current.togglePlay();
  else if (a === 'closed') { current.video.pause(); current.save(); document.body.classList.remove('pip-mode'); }
};

/**
 * opts: { kind: live|movie|episode|catchup|file, item, list, series, episodes, program, file, startAt }
 */
export function openPlayer(opts) {
  if (current) current.close(true);
  if (useNative(opts)) { nativeOpen(opts); return null; }
  current = new Player(opts);
  return current;
}
export function currentPlayer() { return current; }

// ---------------------------------------------------------------- player nativo do Android TV (opcional)
// Configurações › Reprodutor › "Usar o player nativo do Android": o vídeo toca no ExoPlayer do app.
const NATIVE = typeof window !== 'undefined' && window.SintoniaNative && window.SintoniaNative.play && /SintoniaTV/.test(navigator.userAgent);
let nativeOpts = null;
function useNative(opts) {
  return NATIVE && S.settings?.player?.nativeTv && ['live', 'movie', 'episode'].includes(opts.kind);
}
function movieListOf(item) {
  const c = S.catalogs.movie;
  if (!c) return [];
  const cat = item.cat || (item.cats && item.cats[0]);
  return c.items.filter((it) => !cat || it.cat === cat || (it.cats && it.cats.indexOf(cat) >= 0));
}
function nativeNeighbor(opts, dir) {
  const list = opts.kind === 'episode' ? (opts.episodes || []) : movieListOf(opts.item);
  const i = list.findIndex((e) => String(e.id) === String(opts.item.id));
  return i >= 0 ? list[i + dir] || null : null;
}
async function nativeOpen(opts) {
  const it = opts.item;
  const ref = opts.kind === 'episode' ? it : { id: it.id, ext: it.ext, cmd: it.cmd };
  const list = opts.kind === 'live' ? ((opts.list && opts.list.length) ? opts.list : [it]) : [];
  let info;
  try {
    info = await api.post(`${base()}/native`, { kind: opts.kind, ref,
      list: list.map((c) => ({ id: c.id, name: (c.num ? `${c.num}  ` : '') + c.name, fav: isFav('live', c.id) })) });
  } catch (e) { toast(e.message, { type: 'error', ms: 6000 }); return; }
  const p = progressOf(opts.kind, it.id);
  const start = opts.startAt !== undefined ? opts.startAt : (opts.kind !== 'live' && canResume(p) && S.settings.player.resume !== 'never' ? p.pos : 0);
  const data = { live: opts.kind === 'live', start, url: info.url, alt: info.alt || '',
    title: opts.kind === 'episode' ? `${opts.series?.name || ''} · T${it.season}E${it.episode}` : it.name };
  if (opts.kind === 'live') {
    data.channels = info.channels.length ? info.channels : [{ id: String(it.id), name: it.name, url: info.url, alt: info.alt, fav: isFav('live', it.id) }];
    data.index = Math.max(0, data.channels.findIndex((c) => c.id === String(it.id)));
  } else {
    data.hasPrev = !!nativeNeighbor(opts, -1);
    data.hasNext = !!nativeNeighbor(opts, 1);
  }
  nativeOpts = opts;
  if (opts.kind === 'live') addRecent(it.id).catch(() => {});
  window.SintoniaNative.play(JSON.stringify(data));
}
window.sintoniaNativeDone = async (r) => {
  const opts = nativeOpts;
  nativeOpts = null;
  if (!opts || !r) return;
  const it = opts.item;
  if (opts.kind === 'live') {
    for (const [id, on] of Object.entries(r.favs || {})) if (isFav('live', id) !== !!on) await toggleFav('live', id).catch(() => {});
  } else if (r.dur > 0 && r.pos > 3) {
    const entry = { kind: opts.kind, id: it.id, pos: Math.floor(r.ended ? r.dur : r.pos), dur: Math.floor(r.dur), ext: it.ext };
    if (opts.kind === 'movie') Object.assign(entry, { name: it.name, img: it.poster || '' });
    else Object.assign(entry, { name: it.title, img: opts.series?.poster || it.still || '', seriesId: opts.series?.id,
      seriesName: opts.series?.name, season: it.season, episode: it.episode,
      ref: { id: it.id, ext: it.ext, url: it.url, cmd: it.cmd, series_num: it.series_num, season: it.season, episode: it.episode, title: it.title } });
    await saveProgress(entry).catch(() => {});
  }
  window.dispatchEvent(new CustomEvent('sintonia:player-closed', { detail: { kind: opts.kind } }));
  let nx = r.step ? nativeNeighbor(opts, r.step) : null;
  if (!nx && r.ended && opts.kind === 'episode' && sectionPrefs('series').autoNext) nx = nativeNeighbor(opts, 1);
  if (nx) {
    const pn = progressOf(opts.kind, nx.id);
    nativeOpen({ ...opts, item: nx, startAt: opts.kind === 'movie' && canResume(pn) ? pn.pos : 0 });
  }
};

const ASPECTS = [
  { id: 'contain', label: 'Ajustar à tela' },
  { id: 'cover', label: 'Preencher (corta bordas)' },
  { id: 'fill', label: 'Esticar' },
];

class Player {
  constructor(opts) {
    this.opts = opts;
    this.kind = opts.kind;
    this.item = opts.item;
    this.list = opts.list || [];
    this.index = Math.max(0, this.list.findIndex((x) => x.id === opts.item?.id));
    this.ctrl = null;
    this.hideT = null;
    this.locked = false;
    this.aspect = S.settings.player.aspect || 'contain';
    this.brightness = 1;
    this.closed = false;
    this.build();
    this.load();
    this.bindKeys();
    if (matchMedia('(pointer: coarse)').matches) {
      this.fullscreen(true).then(() => {
        if (S.settings.player.landscape && screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => {});
      });
    }
  }

  get live() { return this.kind === 'live'; }
  get skip() { return +(S.settings.player.skipSeconds || 10); }
  get vod() { return this.kind === 'movie' || this.kind === 'episode' || this.kind === 'file' || this.kind === 'catchup'; }

  // ---------------------------------------------------------------- interface
  build() {
    const root = document.getElementById('player-root');
    this.video = h('video.pl-video', { playsinline: true, autoplay: true, preload: 'auto' });
    this.video.style.objectFit = this.aspect;
    this.badges = h('div.pl-badges');
    this.favBtn = iconBtn('star', 'Favorito', () => this.toggleFav());
    this.topRight = h('div.pl-top-r');
    this.recentBox = h('div.pl-recent');
    this.title = h('div.pl-title');
    this.sub = h('div.pl-sub');
    this.timeLbl = h('div.pl-time');
    this.progFill = h('div.pl-prog-fill');
    this.progBuf = h('div.pl-prog-buf');
    this.progBar = h('div.pl-prog', this.progBuf, this.progFill, h('div.pl-prog-knob'));
    this.logo = h('div.pl-logo');
    this.playBtn = h('button.pl-play', { type: 'button', 'aria-label': 'Reproduzir ou pausar', onclick: () => this.togglePlay() }, ic('pause'));
    this.prevBtn = h('button.pl-skip', { type: 'button', onclick: () => this.prev() });
    this.nextBtn = h('button.pl-skip', { type: 'button', onclick: () => this.next() });
    this.status = h('div.pl-status');
    this.volume = h('input.pl-vslider', { type: 'range', min: 0, max: 1, step: 0.02, value: 1, 'aria-label': 'Volume', orient: 'vertical' });
    this.bright = h('input.pl-vslider', { type: 'range', min: 0.4, max: 1.6, step: 0.02, value: 1, 'aria-label': 'Brilho', orient: 'vertical' });
    this.muteBtn = iconBtn('volume', 'Som (M)', () => this.toggleMute());
    this.recBtn = h('button.pl-rec', { type: 'button', onclick: () => this.record() }, ic('record'), h('span', 'Gravar'));
    this.actionsL = h('div.pl-actions-l');
    this.actionsR = h('div.pl-actions-r');
    this.side = h('aside.pl-side');
    this.overlayBox = h('div.pl-overlay-box');
    this.lockLayer = h('div.pl-lock-layer', h('button.icon-btn.big', { type: 'button', 'aria-label': 'Desbloquear tela', onclick: () => this.setLocked(false) }, ic('unlock')));

    this.volume.addEventListener('input', () => { this.video.volume = +this.volume.value; this.video.muted = false; this.syncMute(); });
    this.bright.addEventListener('input', () => { this.brightness = +this.bright.value; this.video.style.filter = `brightness(${this.brightness})`; });
    this.video.volume = +(localStorage.getItem('sintonia.vol') || 1);
    this.volume.value = this.video.volume;

    const top = h('div.pl-top',
      iconBtn('close', 'Fechar (Esc)', () => this.close()),
      this.badges,
      this.topRight);
    const center = h('div.pl-center', this.prevBtn, this.playBtn, this.nextBtn);
    const bottom = h('div.pl-bottom',
      h('div.pl-info', this.logo, h('div.pl-text', this.title, this.sub), this.timeLbl),
      this.progBar,
      h('div.pl-actions', this.actionsL, this.actionsR));

    this.el = h('div.player', { tabindex: '-1' },
      this.video,
      h('div.pl-shade'),
      this.status,
      h('div.pl-ui', top, this.recentBox,
        h('div.pl-vol', ic('volume'), this.volume),
        h('div.pl-bri', ic('sun'), this.bright),
        center, bottom),
      this.side, this.overlayBox, this.lockLayer);

    // controles da barra superior direita
    const tr = this.topRight;
    if (this.live) tr.append(iconBtn('gridPlus', 'Abrir em multitela', () => this.toMulti()));
    tr.append(iconBtn('aspect', 'Proporção da imagem', () => this.aspectMenu()));
    tr.append(iconBtn('lock', 'Travar controles', () => this.setLocked(true)));
    if (screen.orientation && screen.orientation.lock && matchMedia('(pointer: coarse)').matches) {
      tr.append(iconBtn('rotate', 'Girar tela', () => this.rotate()));
    }
    const onTv = document.body.classList.contains('tv');
    if (!onTv && (NATIVE_PIP || document.pictureInPictureEnabled)) tr.append(iconBtn('pip', 'Imagem no canto (PiP)', () => this.pip()));
    if (this.kind !== 'file' && this.kind !== 'catchup') tr.append(this.favBtn);

    // ações inferiores
    const al = this.actionsL;
    al.append(iconBtn('subtitles', 'Legendas', () => this.subtitleMenu()));
    al.append(iconBtn('audio', 'Faixa de áudio e qualidade', () => this.audioMenu()));
    al.append(this.muteBtn);
    if (this.live) al.append(this.recBtn);
    if (this.vod) al.append(iconBtn('speed', 'Velocidade', () => this.speedMenu()));
    // anterior / próximo: canal, episódio ou filme da mesma categoria
    if (this.live || this.kind === 'episode' || this.kind === 'movie') {
      const what = this.live ? ['Canal anterior', 'Próximo canal'] : this.kind === 'episode' ? ['Episódio anterior', 'Próximo episódio'] : ['Filme anterior', 'Próximo filme'];
      this.stepPrevBtn = iconBtn('prev', what[0], () => this.step(-1));
      this.stepNextBtn = iconBtn('next', what[1], () => this.step(1));
      this.stepPrevBtn.classList.add('pl-step');
      this.stepNextBtn.classList.add('pl-step');
      al.append(this.stepPrevBtn, this.stepNextBtn);
    }
    const ar = this.actionsR;
    if (this.live) ar.append(iconBtn('guide', 'Canais e programação', () => this.toggleSide()));
    if (this.kind === 'episode') ar.append(iconBtn('series', 'Episódios', () => this.toggleSide()));
    if (!onTv && 'remote' in HTMLMediaElement.prototype) ar.append(iconBtn('cast', 'Transmitir para TV', () => this.cast()));
    if (!onTv) ar.append(iconBtn('external', 'Abrir em outro player (VLC)', () => this.externalMenu()));
    this.fsBtn = iconBtn('fullscreen', 'Tela cheia (F)', () => this.fullscreen());
    if (!onTv) ar.append(this.fsBtn);

    if (this.live) {
      this.prevBtn.append(ic('prev'));
      this.prevBtn.title = 'Canal anterior';
      this.nextBtn.append(ic('next'));
      this.nextBtn.title = 'Próximo canal';
    } else {
      const sk = this.skip;
      const b = ic('back10');
      const f = ic('fwd10');
      b.querySelector('text').textContent = String(sk);
      f.querySelector('text').textContent = String(sk);
      this.prevBtn.append(b);
      this.prevBtn.title = `Voltar ${sk} s`;
      this.nextBtn.append(f);
      this.nextBtn.title = `Avançar ${sk} s`;
    }

    // eventos de interação
    const wake = () => this.showUi();
    this.el.addEventListener('mousemove', wake);
    this.el.addEventListener('touchstart', wake, { passive: true });
    this.el.addEventListener('click', (e) => {
      if (e.target === this.el.querySelector('.pl-ui') || e.target === this.video) {
        if (this.el.classList.contains('ui-on') && matchMedia('(pointer: coarse)').matches) this.hideUi();
        else this.showUi();
      }
    });
    this.el.querySelector('.pl-ui').addEventListener('dblclick', (e) => { if (e.target.classList.contains('pl-ui')) this.fullscreen(); });
    this.progBar.addEventListener('pointerdown', (e) => this.seekPointer(e));

    const v = this.video;
    v.addEventListener('playing', () => { this.everPlayed = true; this.loadPlayed = true; if (this.netBanner) this.updateNetBanner(); this.recoverTries = 0; clearTimeout(this.stuckT); this.setStatus(''); this.playBtn.innerHTML = ''; this.playBtn.append(ic('pause')); });
    v.addEventListener('pause', () => { this.playBtn.innerHTML = ''; this.playBtn.append(ic('play')); this.showUi(); this.save(); });
    v.addEventListener('playing', () => this.pipState());
    v.addEventListener('pause', () => this.pipState());
    v.addEventListener('loadedmetadata', () => this.pipState());
    v.addEventListener('waiting', () => { this.setStatus('loading'); this.watchStuck(); });
    v.addEventListener('timeupdate', () => { if (!v.paused && v.currentTime > 0.5) this.lastGood = v.currentTime; });
    v.addEventListener('canplay', () => { if (this.status.dataset.s === 'loading') this.setStatus(''); });
    v.addEventListener('timeupdate', () => this.onTime());
    v.addEventListener('progress', () => this.onTime());
    v.addEventListener('loadedmetadata', () => { this.onMeta(); this.updateBadges(); });
    v.addEventListener('ended', () => this.onEnded());
    v.addEventListener('volumechange', () => { this.syncMute(); localStorage.setItem('sintonia.vol', v.volume); });
    this.stopFps = measureFps(v, (fps) => { this.fps = fps; this.updateBadges(); });
    document.addEventListener('fullscreenchange', this.onFs = () => this.syncFs());

    root.append(this.el);
    document.body.classList.add('playing');
    requestAnimationFrame(() => this.el.classList.add('show'));
    this.el.focus();
    this.showUi();
  }

  setStatus(kind, msg) {
    const s = this.status;
    s.dataset.s = kind;
    clear(s);
    if (kind === 'loading') s.append(h('div.pl-loading', h('span.spin.big'), msg ? h('small', msg) : null));
    if (kind === 'error') {
      s.append(h('div.pl-error',
        ic('warning', 'warn-ic'),
        h('h4', 'Não foi possível reproduzir'),
        h('p', msg || 'O canal pode estar fora do ar ou o formato não é suportado pelo navegador.'),
        h('div.pl-error-act',
          btn('Tentar de novo', { cls: 'primary', icon: 'refresh', onclick: () => { this.load(); } }),
          btn('Abrir no VLC', { cls: 'ghost', icon: 'external', onclick: () => this.openExternal() }),
          btn('Copiar link', { cls: 'ghost', icon: 'copy', onclick: () => this.copyLink() }))));
    }
  }

  showUi() {
    if (this.locked) { this.lockLayer.classList.add('peek'); clearTimeout(this.peekT); this.peekT = setTimeout(() => this.lockLayer.classList.remove('peek'), 2500); return; }
    this.el.classList.add('ui-on');
    clearTimeout(this.hideT);
    this.hideT = setTimeout(() => this.hideUi(), (+(S.settings.player.controlsSeconds || 4)) * 1000);
  }

  hideUi() {
    if (this.video.paused || this.side.classList.contains('open') || this.overlayBox.childElementCount) return;
    this.el.classList.remove('ui-on');
  }

  // ---------------------------------------------------------------- carregamento
  async resolveSource(fmt) {
    const k = this.kind;
    if (k === 'file') {
      const f = this.opts.file;
      const ext = (f.file || '').split('.').pop().toLowerCase();
      return { url: `/files/${f.id}`, type: ext === 'ts' ? 'ts' : 'native', live: false, direct: location.origin + `/files/${f.id}` };
    }
    if (k === 'catchup') {
      const p = this.opts.program;
      return api.post(`${base()}/catchup`, { id: this.item.id, start: p.start, stop: p.stop });
    }
    const ref = k === 'episode' ? this.item : { id: this.item.id, ext: this.item.ext, cmd: this.item.cmd };
    return api.post(`${base()}/play`, { kind: k, ref, fmt, noReserve: !!this.noReserve, uaAlt: !!this.uaAlt });
  }

  /** Sequência de tentativas para a TV ao vivo: com reserva, sem reserva e no outro formato. */
  livePlan() {
    const pref = S.settings.player.liveFormat || 'ts';
    const other = pref === 'ts' ? 'm3u8' : 'ts';
    const isM3u = (src()?.engine || src()?.type) === 'm3u';
    const plan = [{ fmt: pref, noReserve: false }, { fmt: pref, noReserve: true }, { fmt: pref, noReserve: true, uaAlt: true }];
    if (!isM3u) plan.push({ fmt: other, noReserve: true }, { fmt: other, noReserve: true, uaAlt: true });
    if ((S.settings.player.buffer || 'max') !== 'max' && S.settings.player.buffer !== 'ultra') plan.shift();
    return plan;
  }

  async load(fmt, retry = false) {
    if (this.closed) return;
    const stepMsg = retry && this.plan ? `Tentando outro caminho (${this.planStep + 1}/${this.plan.length})…` : undefined;
    if (!retry) {
      this.triedTypes = new Set();
      this.wasAuto = false;
      this.attempts = [];
      this.plan = this.live ? this.livePlan() : null;
      this.planStep = 0;
      this.noReserve = false;
      this.uaAlt = false;
      if (this.plan) { fmt = this.plan[0].fmt; this.noReserve = this.plan[0].noReserve; this.uaAlt = !!this.plan[0].uaAlt; }
    }
    this.setStatus('loading', stepMsg);
    this.renderInfo();
    this.updateStepButtons();
    if (this.ctrl) { this.ctrl.destroy(); this.ctrl = null; }
    clearTimeout(this.stallT);
    let info;
    try {
      info = await this.resolveSource(fmt);
    } catch (e) {
      this.setStatus('error', e.message);
      return;
    }
    if (this.closed) return;
    this.source = info;
    this.loadPlayed = false;
    const myLoad = (this.loadSeq = (this.loadSeq || 0) + 1);
    const fail = (err) => {
      if (myLoad !== this.loadSeq) return;
      if (this.vod && this.everPlayed && this.kind !== 'file' && (this.recoverTries || 0) < 8) { this.recoverVod(String(err && err.message || err)); return; }
      this.onFail(err, info);
    };
    try {
      this.ctrl = await attach(this.video, { ...info, mode: S.settings.player.buffer || 'max' });
    } catch (e) {
      fail(e);
      return;
    }
    if (myLoad !== this.loadSeq) { this.ctrl.destroy(); return; }
    this.ctrl.onFatal(fail);
    this.ctrl.onInfo(() => this.updateBadges());
    const startWait = (this.live ? 12000 : 25000) + (info.reserve && info.reserve.cushion ? info.reserve.cushion * 1000 : 0);
    if (info.reserve && info.reserve.cushion) this.setStatus('loading', `Montando a reserva de ${info.reserve.cushion} s…`);
    this.stallT = setTimeout(() => {
      if (myLoad === this.loadSeq && this.video.readyState < 2 && !this.loadPlayed) fail(new Error('timeout'));
    }, startWait);
    this.reserveFail = info.reserve ? fail : null;
    this.watchReserve(info.reserve);
    const p = this.video.play();
    if (p && p.catch) {
      p.catch((e) => {
        if (e && e.name === 'NotAllowedError') {
          this.video.muted = true;
          this.video.play().catch(() => {});
          toast('Som desativado pelo navegador. Toque no alto-falante para ativar.');
        }
      });
    }
    this.afterStart();
  }

  onFail(err, info) {
    const msg = String((err && err.message) || err);
    this.triedTypes.add(info.type);
    const why = this.reserveInfo && this.reserveInfo.error ? ` (${this.reserveInfo.error})` : '';
    this.attempts.push(`${(info.format || info.type).toUpperCase()}${info.reserve ? ' com reserva' : ''} · UA ${info.ua || '?'}: ${msg}${why}`);
    console.warn('Sintonia: falha ao reproduzir', info.url, msg);
    if (info.type === 'auto') this.wasAuto = true;
    // ao vivo: segue o plano (com reserva → sem reserva → outro formato)
    if (this.plan && this.planStep < this.plan.length - 1) {
      this.planStep++;
      const step = this.plan[this.planStep];
      this.noReserve = step.noReserve;
      this.uaAlt = !!step.uaAlt;
      this.setStatus('loading', `Tentando outro caminho (${this.planStep + 1}/${this.plan.length})…`);
      this.load(step.fmt, true);
      return;
    }
    // endereço sem extensão: tenta cada motor de vídeo
    if (this.wasAuto || (src()?.engine || src()?.type) === 'm3u') {
      const order = ['ts', 'hls', 'native'].filter((t) => !this.triedTypes.has(t));
      if (order.length) { this.retryWithType(info, order[0]); return; }
    }
    let human = 'O canal pode estar fora do ar ou o formato não é suportado pelo navegador.';
    const hevc = /\b(h\.?265|hevc)\b/i.test(this.item?.name || '');
    const hevcOk = window.MediaSource && window.MediaSource.isTypeSupported('video/mp4; codecs="hvc1.1.6.L120.90"');
    if (this.live && hevc && !hevcOk) human = 'Este canal usa vídeo H.265 (HEVC), que este navegador não reproduz. Escolha a versão HD ou FHD do mesmo canal.';
    if (msg.includes('lib-indisponivel')) human = 'Não consegui carregar o componente de vídeo (hls.js/mpegts.js). Verifique a internet do aparelho onde o Sintonia está rodando.';
    else if (msg.includes('ts-sem-suporte')) human = 'Este navegador não reproduz MPEG-TS. Em Reprodutor de vídeo, mude o formato ao vivo para HLS.';
    else if (hevc && !hevcOk) { /* mantém a mensagem do H.265 */ }
    else if (msg === 'timeout') human = 'O vídeo demorou demais para começar. O servidor pode estar lento ou fora do ar.';
    else if (/403|401/.test(msg)) human = 'O provedor recusou o acesso (limite de conexões ou login expirado).';
    else if (/não está entregando|503/.test(msg) && this.vod) human = 'O provedor não está entregando este vídeo agora (erro 503). Outros títulos funcionam; tente este mais tarde ou outra versão (DUB/LEG) dele.';
    this.setStatus('error', human);
    const details = h('details.pl-diag', h('summary', 'Detalhes técnicos'), h('pre', this.attempts.join('\n')));
    const box = this.status.querySelector('.pl-error');
    if (box) {
      if (this.live) box.querySelector('.pl-error-act')?.prepend(btn('Diagnosticar canal', { cls: 'ghost', icon: 'info', onclick: () => diagnose(this.item, this.attempts) }));
      box.append(details);
    }
  }

  async retryWithType(info, type) {
    if (this.ctrl) { this.ctrl.destroy(); this.ctrl = null; }
    const myLoad = (this.loadSeq = (this.loadSeq || 0) + 1);
    const next = { ...info, type };
    try {
      this.ctrl = await attach(this.video, { ...next, mode: S.settings.player.buffer || 'max' });
      if (myLoad !== this.loadSeq) return;
      this.ctrl.onFatal((e) => { if (myLoad === this.loadSeq) this.onFail(e, next); });
      this.ctrl.onInfo(() => this.updateBadges());
      this.video.play().catch(() => {});
    } catch (e) {
      this.onFail(e, next);
    }
  }

  afterStart() {
    if (this.live) {
      addRecent(this.item.id).then(() => this.renderRecent()).catch(() => {});
      this.loadEpg();
      this.syncRecBtn();
    } else if (this.kind === 'movie' || this.kind === 'episode' || this.kind === 'file') {
      this.maybeResume();
      clearInterval(this.saveT);
      this.saveT = setInterval(() => { if (!this.video.paused) this.save(); }, 5000);
    }
    this.favBtn.classList.toggle('fav-on', this.kind !== 'episode' ? isFav(this.kind === 'live' ? 'live' : 'movie', this.item.id) : isFav('series', this.opts.series?.id));
    this.favBtn.innerHTML = '';
    this.favBtn.append(ic('star', this.favBtn.classList.contains('fav-on') ? 'filled' : ''));
  }

  maybeResume() {
    if (this.recoverAt !== undefined) {
      const t = this.recoverAt;
      this.recoverAt = undefined;
      if (t > 0) this.seekWhenReady(t);
      return;
    }
    if (this.opts.startAt !== undefined) {
      if (this.opts.startAt > 0) this.seekWhenReady(this.opts.startAt);
      return;
    }
    const p = this.kind === 'file' ? this.fileProgress() : progressOf(this.kind, this.item.id);
    if (!canResume(p)) return;
    const mode = S.settings.player.resume || 'ask';
    if (mode === 'never') return;
    if (mode === 'auto') {
      this.seekWhenReady(p.pos);
      toast(`Retomando de ${fmtDur(p.pos)}`, { action: { label: 'Do início', fn: () => { this.video.currentTime = 0; } } });
      return;
    }
    this.video.pause();
    const box = h('div.pl-card',
      h('h4', 'Continuar de onde parou?'),
      h('p', `Você assistiu até ${fmtDur(p.pos)}.`),
      h('div.pl-card-act',
        btn(`Continuar de ${fmtDur(p.pos)}`, { cls: 'primary', icon: 'play', onclick: () => { clear(this.overlayBox); this.seekWhenReady(p.pos); this.video.play(); } }),
        btn('Começar do início', { cls: 'ghost', onclick: () => { clear(this.overlayBox); this.video.play(); } })));
    clear(this.overlayBox).append(box);
  }

  /** Vídeo parado esperando dados por muito tempo: reabre no mesmo ponto. */
  watchStuck() {
    clearTimeout(this.stuckT);
    if (!this.vod || this.kind === 'file' || !this.everPlayed) return;
    this.stuckT = setTimeout(() => {
      const v = this.video;
      if (this.closed || v.paused || v.readyState >= 3) return;
      // o servidor ainda está reconectando ao provedor: continua esperando (a reserva retoma sozinha)
      if (!navigator.onLine || (this.reserveInfo && this.reserveInfo.state === 'retrying')) { this.watchStuck(); return; }
      this.recoverVod('travado');
    }, 20000);
  }

  /** Erro ou travamento no meio do filme/episódio: reabre do mesmo segundo, sem perguntar. */
  async recoverVod(why) {
    if (this.closed || this.recovering) return;
    this.recovering = true;
    clearTimeout(this.stuckT);
    const v = this.video;
    const at = Math.max(0, (v.currentTime > 0.5 ? v.currentTime : this.lastGood || 0) - 1);
    this.recoverTries = (this.recoverTries || 0) + 1;
    this.attempts.push(`Recuperação ${this.recoverTries} em ${fmtDur(at)}: ${why}`);
    console.warn('Sintonia: retomando o vídeo em', at, why);
    try {
      // sem internet: espera ela voltar
      while (!this.closed && !navigator.onLine) {
        this.setStatus('loading');
        this.netDot(true);
        await new Promise((r) => { const t = setTimeout(r, 3000); window.addEventListener('online', () => { clearTimeout(t); r(); }, { once: true }); });
      }
      const wait = Math.min(15000, 1000 * 2 ** Math.min(this.recoverTries - 1, 4));
      this.setStatus('loading');
      this.netDot(true);
      if (this.recoverTries > 1) await new Promise((r) => setTimeout(r, wait));
      if (this.closed) return;
      this.recoverAt = at;
      const resumeAt = at;
      await this.load(this.source && this.source.format, true);
      // garante a posição mesmo se a carga terminar antes do maybeResume
      if (this.recoverAt === resumeAt) { this.recoverAt = undefined; this.seekWhenReady(resumeAt); }
    } finally {
      this.recovering = false;
    }
  }

  /** Pontinho vermelho no canto enquanto reconecta (some quando o vídeo volta). */
  netDot(on) {
    if (!this.netBanner) { this.netBanner = h('div.pl-net'); this.el.append(this.netBanner); }
    this.netBanner.classList.toggle('show', !!on);
    if (on) {
      clearTimeout(this.netDotT);
      this.netDotT = setTimeout(() => this.updateNetBanner(), 15000);
    }
  }

  seekWhenReady(t) {
    const go = () => { try { this.video.currentTime = t; } catch { /* ignora */ } };
    if (this.video.readyState >= 1) go();
    else this.video.addEventListener('loadedmetadata', go, { once: true });
  }

  // ---------------------------------------------------------------- informações
  renderInfo() {
    const it = this.item;
    clear(this.logo);
    clear(this.title);
    clear(this.sub);
    if (this.live || this.kind === 'catchup') {
      this.logo.append(pic(it.logo, it.name, 'pl-logo-pic'));
      if (it.num) this.title.append(h('span.pl-num', String(it.num)));
      this.title.append(it.name);
      if (this.kind === 'catchup') {
        const p = this.opts.program;
        this.sub.append(h('span.chip-replay', ic('replay'), 'Replay'), ` ${p.title} · ${fmtTime(p.start, s24())}`);
      }
    } else if (this.kind === 'episode') {
      this.title.append(this.opts.series?.name || '');
      this.sub.append(`T${it.season} · E${it.episode} — ${it.title || ''}`);
    } else if (this.kind === 'file') {
      this.title.append(this.opts.file.name);
      this.sub.append(this.opts.file.type === 'rec' ? 'Gravação' : 'Download');
    } else {
      this.title.append(it.name.replace(/\s*[([](19|20)\d\d[)\]]\s*$/, ''));
      this.sub.append([it.year || '', it.rating ? `★ ${String(it.rating).replace('.', ',')}` : ''].filter(Boolean).join('  ·  '));
    }
    this.renderRecent();
    this.renderSide();
  }

  renderRecent() {
    clear(this.recentBox);
    if (!this.live || !S.user) return;
    const live = S.catalogs.live;
    const ids = (S.user.recent || []).filter((id) => id !== this.item.id).slice(0, 5);
    for (const id of ids) {
      const ch = live?.byId.get(id);
      if (!ch) continue;
      const wrap = h('div.pl-recent-wrap',
        h('button.pl-recent-btn', { type: 'button', title: ch.name, onclick: () => this.zapTo(ch) }, pic(ch.logo, ch.name)),
        h('button.recent-x', { type: 'button', title: 'Tirar do histórico', 'aria-label': `Tirar ${ch.name} do histórico`,
          onclick: async (e) => { e.stopPropagation(); await removeRecent(id); this.renderRecent(); } }, ic('close')));
      this.recentBox.append(wrap);
    }
  }

  async loadEpg() {
    const ch = this.item;
    this.epg = null;
    try {
      const r = await api.post(`${base()}/epg/channel`, { channel: { id: ch.id, epg: ch.epg, name: ch.name },
        from: Math.floor(Date.now() / 1000) - 3 * 86400, to: Math.floor(Date.now() / 1000) + 86400 });
      if (this.item !== ch) return;
      this.epg = r.data || [];
      this.updateLiveInfo();
      if (this.sideTab === 'prog') this.renderSide();
    } catch { /* sem guia */ }
  }

  currentProg() {
    const now = Date.now() / 1000;
    return (this.epg || []).find((p) => p.start <= now && now < p.stop) || null;
  }

  updateLiveInfo() {
    if (!this.live) return;
    const p = this.currentProg();
    clear(this.sub);
    clear(this.timeLbl);
    if (p) {
      this.sub.append(p.title);
      this.timeLbl.append(`${fmtTime(p.start, s24())} – ${fmtTime(p.stop, s24())}`);
      const pct = Math.min(100, ((Date.now() / 1000 - p.start) / (p.stop - p.start)) * 100);
      this.progFill.style.width = pct + '%';
      this.progBuf.style.width = '0';
    } else {
      this.sub.append('Ao vivo');
      this.progFill.style.width = '0';
    }
  }

  onMeta() {
    if (this.live) this.updateLiveInfo();
  }

  onTime() {
    const v = this.video;
    if (!this.badgeTick || Date.now() - this.badgeTick > 3000) { this.badgeTick = Date.now(); this.updateBadges(); if (!navigator.onLine) this.updateNetBanner(); }
    if (this.live) {
      if (!this.liveTick || Date.now() - this.liveTick > 30000) { this.liveTick = Date.now(); this.updateLiveInfo(); }
      return;
    }
    const d = v.duration;
    if (!isFinite(d) || !d) return;
    this.progFill.style.width = (v.currentTime / d) * 100 + '%';
    const r = this.reserveInfo;
    if (r && r.kind === 'vod' && r.total && this.reserveEnd() !== null) this.progBuf.style.width = Math.min(100, this.reserveEnd() * 100) + '%';
    else if (v.buffered.length) this.progBuf.style.width = (v.buffered.end(v.buffered.length - 1) / d) * 100 + '%';
    clear(this.timeLbl).append(`${fmtDur(v.currentTime)} / ${fmtDur(d)}`);
    if (this.kind === 'episode') this.checkNextEpisode();
  }

  updateBadges() {
    if (!this.ctrl && !this.video.videoHeight) { clear(this.badges); return; }
    const info = this.ctrl ? this.ctrl.info() : {};
    const b = [];
    const fps = this.fps || Math.round(info.fps || 0);
    if (fps) b.push(`${fps} fps`);
    const hgt = this.video.videoHeight || info.height;
    if (hgt) b.push(hgt >= 2000 ? '4K' : `${hgt}p`);
    const vc = (info.vcodec || '').split('.')[0];
    if (vc) b.push(vc.replace('avc1', 'h264').replace(/^(hev1|hvc1)$/, 'h265'));
    if (info.channels) b.push(info.channels === 6 ? '5.1' : info.channels + '.0');
    const ac = (info.acodec || '').split('.')[0];
    if (ac) b.push(ac.replace('mp4a', 'aac'));
    clear(this.badges);
    b.forEach((x) => this.badges.append(h('span.pl-badge', x)));
    const r = this.reserveInfo;
    if (r && r.kind === 'vod' && r.total) {
      const pct = r.state === 'complete' ? 100 : Math.min(99, Math.floor(((r.saved || r.done) / r.total) * 100));
      const mbps = r.speed ? ` · baixando a ${(r.speed * 8 / 1e6).toFixed(1).replace('.', ',')} Mbps` : '';
      this.badges.append(h('span.pl-badge.res', { title: `Parte do vídeo já guardada no servidor${mbps}` }, pct >= 100 ? 'Reserva completa' : `Reserva ${pct}%`));
    } else if (r && r.kind === 'live') {
      this.badges.append(h('span.pl-badge.res', { title: 'Reserva do canal no servidor' }, `Reserva ${this.reserve.cushion}s`));
    } else if (this.vod) {
      const ahead = this.bufferedAhead();
      if (ahead > 5) this.badges.append(h('span.pl-badge.res', `Carregado +${fmtDur(ahead)}`));
    }
  }

  // ---------------------------------------------------------------- reserva e conexão
  watchReserve(reserve) {
    clearInterval(this.reserveT);
    this.reserve = reserve || null;
    this.reserveInfo = null;
    if (!this.onNet) {
      this.onNet = () => this.updateNetBanner();
      window.addEventListener('online', this.onNet);
      window.addEventListener('offline', this.onNet);
    }
    if (!reserve) { this.updateNetBanner(); return; }
    const poll = async () => {
      try {
        this.reserveInfo = await api.get(`/api/stream/${reserve.kind}/${reserve.id}`);
      } catch { this.reserveInfo = null; }
      if (this.reserveInfo && this.reserveInfo.state === 'failed' && this.video.readyState < 2 && this.reserveFail) {
        const f = this.reserveFail;
        this.reserveFail = null;
        clearInterval(this.reserveT);
        f(new Error(this.reserveInfo.error || 'reserva falhou'));
        return;
      }
      this.updateNetBanner();
      this.updateBadges();
      this.onTime();
    };
    poll();
    this.reserveT = setInterval(poll, 2000);
  }

  bufferedAhead() {
    const v = this.video;
    for (let i = 0; i < v.buffered.length; i++) {
      if (v.buffered.start(i) <= v.currentTime + 0.5 && v.currentTime <= v.buffered.end(i)) return v.buffered.end(i) - v.currentTime;
    }
    return 0;
  }

  /** Até onde (0–1 do vídeo) a reserva do servidor vai sem buracos, a partir do ponto atual. */
  reserveEnd() {
    const r = this.reserveInfo;
    const v = this.video;
    if (!r || r.kind !== 'vod' || !r.total || !isFinite(v.duration) || !v.duration) return null;
    const here = (v.currentTime / v.duration) * r.total;
    let end = here;
    for (const [a, b] of r.ranges || []) if (a <= end + 65536 && b > end) end = b;
    return Math.min(1, end / r.total);
  }

  reserveSeconds() {
    const v = this.video;
    const f = this.reserveEnd();
    if (f !== null) return Math.max(this.bufferedAhead(), f * v.duration - v.currentTime);
    return this.bufferedAhead();
  }

  updateNetBanner() {
    const r = this.reserveInfo;
    let msg = '';
    if (!navigator.onLine) msg = `Sem internet. Tocando o que já foi carregado (${fmtDur(this.reserveSeconds())} guardados).`;
    else if (r && r.state === 'retrying') {
      msg = r.kind === 'live' ? 'O canal caiu. Reconectando sem parar a imagem…'
        : `Conexão com o provedor perdida. Tocando a reserva (${fmtDur(this.reserveSeconds())}) e retomando o download…`;
    } else if (this.ctrl && this.ctrl.info().offline) msg = 'Conexão instável. Tocando o que já foi carregado…';
    if (!this.netBanner) {
      this.netBanner = h('div.pl-net');
      this.el.append(this.netBanner);
    }
    // só um pontinho vermelho no canto: o vídeo continua, sem faixa de texto por cima
    this.netBanner.title = msg;
    this.netBanner.setAttribute('aria-label', msg || '');
    this.netBanner.classList.toggle('show', !!msg);
  }

  // ---------------------------------------------------------------- controles
  togglePlay() {
    if (this.video.paused) this.video.play().catch(() => {}); else this.video.pause();
    this.showUi();
  }

  prev() { if (this.live) this.zap(-1); else this.seekBy(-this.skip); }
  next() { if (this.live) this.zap(1); else this.seekBy(this.skip); }

  seekBy(s) {
    const v = this.video;
    if (isFinite(v.duration)) v.currentTime = Math.max(0, Math.min(v.duration - 1, v.currentTime + s));
    this.showUi();
  }

  seekPointer(e) {
    if (this.live || !isFinite(this.video.duration)) return;
    const rect = this.progBar.getBoundingClientRect();
    const move = (ev) => {
      const x = Math.max(0, Math.min(1, (ev.clientX - rect.left) / rect.width));
      this.progFill.style.width = x * 100 + '%';
      this.pendingSeek = x * this.video.duration;
    };
    move(e);
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      if (this.pendingSeek !== undefined) this.video.currentTime = this.pendingSeek;
      this.pendingSeek = undefined;
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  }

  zap(dir) {
    if (!this.list.length) return;
    this.index = (this.index + dir + this.list.length) % this.list.length;
    this.zapTo(this.list[this.index]);
  }

  zapTo(ch) {
    this.item = ch;
    const i = this.list.findIndex((x) => x.id === ch.id);
    if (i >= 0) this.index = i;
    this.load();
    this.showUi();
  }

  toggleMute() {
    this.video.muted = !this.video.muted;
    if (!this.video.muted && this.video.volume === 0) this.video.volume = 0.6;
  }

  syncMute() {
    const m = this.video.muted || this.video.volume === 0;
    this.muteBtn.innerHTML = '';
    this.muteBtn.append(ic(m ? 'mute' : 'volume'));
    this.volume.value = this.video.muted ? 0 : this.video.volume;
  }

  setLocked(on) {
    this.locked = on;
    this.el.classList.toggle('locked', on);
    if (on) { this.el.classList.remove('ui-on'); toast('Controles travados. Toque na tela e no cadeado para destravar.'); }
    else this.showUi();
  }

  async fullscreen(force) {
    try {
      if (document.fullscreenElement && force !== true) await document.exitFullscreen();
      else if (!document.fullscreenElement) await this.el.requestFullscreen({ navigationUI: 'hide' });
    } catch { /* o navegador recusou */ }
  }

  syncFs() {
    const fs = !!document.fullscreenElement;
    this.fsBtn.innerHTML = '';
    this.fsBtn.append(ic(fs ? 'unfullscreen' : 'fullscreen'));
  }

  async rotate() {
    try {
      if (!document.fullscreenElement) await this.el.requestFullscreen();
      const landscape = (screen.orientation.type || '').startsWith('landscape');
      await screen.orientation.lock(landscape ? 'portrait' : 'landscape');
    } catch { toast('Este aparelho não permite girar a tela pelo navegador.'); }
  }

  pipState() {
    if (!NATIVE_PIP) return;
    try { window.SintoniaPip.state(!this.closed, !this.closed && !this.video.paused, this.video.videoWidth || 16, this.video.videoHeight || 9); } catch { /* app antigo */ }
  }

  async pip() {
    if (NATIVE_PIP) { this.hideUi(); window.SintoniaPip.enter(this.video.videoWidth || 16, this.video.videoHeight || 9); return; }
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else await this.video.requestPictureInPicture();
    } catch { toast('Imagem no canto não está disponível agora.'); }
  }

  cast() {
    this.video.remote.prompt().catch(() => toast('Nenhuma TV encontrada na rede.'));
  }

  async toggleFav() {
    let on;
    if (this.kind === 'episode') on = await toggleFav('series', this.opts.series.id);
    else on = await toggleFav(this.live ? 'live' : 'movie', this.item.id);
    this.favBtn.classList.toggle('fav-on', on);
    this.favBtn.innerHTML = '';
    this.favBtn.append(ic('star', on ? 'filled' : ''));
    toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
  }

  aspectMenu() {
    menu(ASPECTS.map((a) => ({ label: a.label, checked: a.id === this.aspect, fn: () => {
      this.aspect = a.id;
      this.video.style.objectFit = a.id;
    } })), { title: 'Proporção da imagem' });
  }

  speedMenu() {
    const cur = this.video.playbackRate;
    menu([0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((r) => ({ label: r === 1 ? 'Normal' : `${String(r).replace('.', ',')}x`,
      checked: r === cur, fn: () => { this.video.playbackRate = r; } })), { title: 'Velocidade' });
  }

  audioMenu() {
    const items = [];
    const tracks = this.ctrl ? this.ctrl.audioTracks() : [];
    if (tracks.length) {
      tracks.forEach((t) => items.push({ label: t.name, sub: t.lang || '', icon: 'audio', checked: t.on, fn: () => this.ctrl.setAudio(t.id) }));
    }
    const levels = this.ctrl ? this.ctrl.levels() : [];
    if (levels.length > 1) {
      if (items.length) items.push(null);
      items.push({ label: 'Qualidade automática', icon: 'hd', checked: this.ctrl.level === -1, fn: () => this.ctrl.setLevel(-1) });
      levels.slice().sort((a, b) => b.height - a.height).forEach((l) => items.push({
        label: l.height ? `${l.height}p` : `${Math.round(l.bitrate / 1000)} kbps`, sub: l.bitrate ? `${(l.bitrate / 1e6).toFixed(1).replace('.', ',')} Mbps` : '',
        icon: 'hd', checked: this.ctrl.level === l.id, fn: () => this.ctrl.setLevel(l.id) }));
    }
    if (!items.length) { toast('Este conteúdo tem apenas uma faixa de áudio e uma qualidade.'); return; }
    menu(items, { title: 'Áudio e qualidade' });
  }

  subtitleMenu() {
    const tracks = Array.from(this.video.textTracks || []).filter((t) => t.kind === 'subtitles' || t.kind === 'captions');
    const items = [{ label: 'Desativadas', checked: tracks.every((t) => t.mode !== 'showing'), fn: () => tracks.forEach((t) => { t.mode = 'disabled'; }) }];
    tracks.forEach((t) => items.push({ label: t.label || t.language || 'Legenda', sub: t.language || '', checked: t.mode === 'showing',
      fn: () => tracks.forEach((x) => { x.mode = x === t ? 'showing' : 'disabled'; }) }));
    items.push(null);
    items.push({ label: 'Carregar legenda do aparelho…', icon: 'folder', sub: '.srt ou .vtt', fn: () => this.loadSubtitleFile() });
    menu(items, { title: 'Legendas' });
  }

  loadSubtitleFile() {
    const input = h('input', { type: 'file', accept: '.srt,.vtt,text/vtt' });
    input.addEventListener('change', async () => {
      const f = input.files[0];
      if (!f) return;
      let text = await f.text();
      if (!text.trim().startsWith('WEBVTT')) {
        text = 'WEBVTT\n\n' + text.replace(/\r/g, '').replace(/(\d\d:\d\d:\d\d),(\d\d\d)/g, '$1.$2');
      }
      this.video.querySelectorAll('track[data-ext]').forEach((t) => t.remove());
      const tr = h('track', { kind: 'subtitles', label: f.name.replace(/\.\w+$/, ''), srclang: 'pt', 'data-ext': '1',
        src: URL.createObjectURL(new Blob([text], { type: 'text/vtt' })) });
      this.video.append(tr);
      setTimeout(() => {
        Array.from(this.video.textTracks).forEach((t) => { t.mode = t.label === tr.label ? 'showing' : 'disabled'; });
      }, 100);
      toast('Legenda carregada');
    });
    input.click();
  }

  externalMenu() {
    menu([
      { label: 'Abrir no VLC ou outro player', icon: 'external', sub: 'baixa um arquivo .m3u com o link', fn: () => this.openExternal() },
      { label: 'Copiar link do vídeo', icon: 'copy', fn: () => this.copyLink() },
    ], { title: 'Outro player' });
  }

  directUrl() {
    const s = this.source;
    if (!s) return '';
    return s.direct && s.direct.startsWith('http') ? s.direct : location.origin + s.url;
  }

  openExternal() {
    const url = this.directUrl();
    if (!url) return;
    const name = this.item?.name || this.opts.file?.name || 'video';
    downloadText(`${name.replace(/[^\w\- ]/g, '').slice(0, 40) || 'video'}.m3u`, `#EXTM3U\n#EXTINF:-1,${name}\n${url}\n`);
  }

  copyLink() { const u = this.directUrl(); if (u) copyText(u); }

  toMulti() {
    const ch = this.item;
    if (!S.multi.some((x) => x && x.id === ch.id)) {
      const free = S.multi.findIndex((x) => !x);
      if (free >= 0) S.multi[free] = ch; else S.multi.push(ch);
    }
    S.multi = S.multi.slice(0, 4);
    this.close();
    location.hash = '#/multi';
  }

  // ---------------------------------------------------------------- gravação
  activeRec() {
    return (this._recs || []).find((r) => r.status === 'recording' && r.itemId === this.item.id && r.src === S.active);
  }

  async syncRecBtn() {
    try { this._recs = await api.get('/api/downloads'); } catch { this._recs = []; }
    this.drawRec(this.activeRec());
  }

  /** Botão Gravar ↔ Parar e a bolinha vermelha "Gravando" por cima do vídeo. */
  drawRec(r) {
    if (!this.recBtn) return;
    this.recBtn.classList.toggle('on', !!r);
    clear(this.recBtn).append(ic(r ? 'stop' : 'record'), h('span', r ? 'Parar' : 'Gravar'));
    this.recBtn.title = r ? 'Parar a gravação' : 'Gravar este canal';
    clearInterval(this.recT);
    if (!r) { if (this.recBadge) { this.recBadge.remove(); this.recBadge = null; } return; }
    if (!this.recBadge) {
      this.recBadge = h('button.pl-rec-badge', { type: 'button', title: 'Parar a gravação', onclick: () => this.record() }, h('i'), h('span', 'Gravando'), h('em'));
      this.el.append(this.recBadge);
    }
    const t0 = (r.created || Date.now() / 1000) * 1000;
    const tick = () => { if (this.recBadge) this.recBadge.querySelector('em').textContent = fmtDur(Math.max(0, (Date.now() - t0) / 1000)); };
    tick();
    this.recT = setInterval(tick, 1000);
  }

  async record() {
    const r = this.activeRec();
    if (r) {
      this.drawRec(null);
      await api.post(`/api/downloads/${r.id}/stop`).catch(() => {});
      toast('Gravação salva em Offline › Gravações.', { type: 'ok' });
      setTimeout(() => this.syncRecBtn(), 800);
      return;
    }
    if (this.recBtn.classList.contains('on')) return;   // ainda começando
    // um toque grava até você tocar em Parar
    const p = this.currentProg();
    this.drawRec({ created: Date.now() / 1000 });   // já mostra "Parar" e a bolinha vermelha
    try {
      await api.post('/api/recordings', { src: S.active, ref: { id: this.item.id, cmd: this.item.cmd, url: this.item.url },
        meta: { name: this.item.name + (p ? ` - ${p.title}` : ''), img: this.item.logo }, minutes: 0 });
      toast('Gravando. Toque em Parar para encerrar (pode fechar o player que continua gravando).', { ms: 4500 });
      setTimeout(() => this.syncRecBtn(), 800);
    } catch (e) {
      this.drawRec(null);
      toast(e.message, { type: 'error' });
    }
  }

  // ---------------------------------------------------------------- painel lateral
  toggleSide() {
    this.side.classList.toggle('open');
    if (this.side.classList.contains('open')) this.renderSide(true);
    this.showUi();
  }

  renderSide(scroll) {
    if (!this.side.classList.contains('open')) return;
    clear(this.side);
    const head = h('div.pl-side-head');
    const body = h('div.pl-side-body');
    if (this.live) {
      this.sideTab = this.sideTab || 'ch';
      const tabs = h('div.seg.small',
        h('button', { type: 'button', class: this.sideTab === 'ch' ? 'on' : '', onclick: () => { this.sideTab = 'ch'; this.renderSide(true); } }, 'Canais'),
        h('button', { type: 'button', class: this.sideTab === 'prog' ? 'on' : '', onclick: () => { this.sideTab = 'prog'; this.renderSide(true); } }, 'Programação'));
      head.append(tabs, iconBtn('close', 'Fechar painel', () => this.toggleSide()));
      if (this.sideTab === 'ch') {
        this.list.forEach((ch) => {
          body.append(h('button.pl-side-row', { type: 'button', class: ch.id === this.item.id ? 'on' : '', onclick: () => this.zapTo(ch) },
            pic(ch.logo, ch.name, 'mini'), h('span.pl-side-name', ch.num ? h('em', String(ch.num)) : null, ch.name)));
        });
      } else {
        const now = Date.now() / 1000;
        const progs = this.epg || [];
        if (!progs.length) body.append(h('p.muted.pad', 'Sem programação para este canal.'));
        progs.filter((p) => p.stop > now - (this.item.archive ? (this.item.archive_days || 3) * 86400 : 3600)).forEach((p) => {
          const isNow = p.start <= now && now < p.stop;
          const past = p.stop <= now;
          const canReplay = past && this.item.archive;
          body.append(h('div.pl-prog-row', { class: isNow ? 'now' : past ? 'past' : '' },
            h('div.pl-prog-time', fmtTime(p.start, s24())),
            h('div.pl-prog-txt', h('strong', p.title), p.desc ? h('small', p.desc) : null),
            canReplay ? iconBtn('replay', 'Assistir replay', () => openPlayer({ kind: 'catchup', item: this.item, program: p, list: this.list })) : null,
            isNow ? h('span.live-dot', 'agora') : null));
        });
      }
    } else if (this.kind === 'episode') {
      head.append(h('strong', 'Episódios'), iconBtn('close', 'Fechar painel', () => this.toggleSide()));
      (this.opts.episodes || []).forEach((ep) => {
        body.append(h('button.pl-side-row', { type: 'button', class: ep.id === this.item.id ? 'on' : '', onclick: () => this.playEpisode(ep) },
          h('span.pl-side-name', h('em', `T${ep.season}E${ep.episode}`), ep.title)));
      });
    }
    this.side.append(head, body);
    if (scroll) {
      const on = body.querySelector('.on, .now');
      if (on) on.scrollIntoView({ block: 'center' });
    }
  }

  // ---------------------------------------------------------------- anterior / próximo
  /** Filmes da mesma categoria do filme aberto (na ordem do catálogo). */
  movieList() {
    const c = S.catalogs.movie;
    if (!c) return [];
    const cat = this.item.cat || (this.item.cats && this.item.cats[0]);
    return c.items.filter((it) => !cat || it.cat === cat || (it.cats && it.cats.indexOf(cat) >= 0));
  }

  stepTarget(dir) {
    if (this.live) return this.list.length > 1 ? true : null;
    const list = this.kind === 'episode' ? (this.opts.episodes || []) : this.movieList();
    const i = list.findIndex((e) => String(e.id) === String(this.item.id));
    return i >= 0 ? list[i + dir] || null : null;
  }

  updateStepButtons() {
    if (!this.stepPrevBtn) return;
    this.stepPrevBtn.disabled = !this.stepTarget(-1);
    this.stepNextBtn.disabled = !this.stepTarget(1);
  }

  step(dir) {
    if (this.live) { this.zap(dir); return; }
    const t = this.stepTarget(dir);
    if (!t) { toast(dir < 0 ? 'Este é o primeiro.' : 'Este é o último.'); return; }
    if (this.kind === 'episode') { this.playEpisode(t); return; }
    this.save();
    this.item = t;
    this.opts.startAt = undefined;
    this.nextShown = false;
    clear(this.overlayBox);
    this.load();
  }

  // ---------------------------------------------------------------- séries
  nextEpisode() {
    const eps = this.opts.episodes || [];
    const i = eps.findIndex((e) => e.id === this.item.id);
    return i >= 0 ? eps[i + 1] : null;
  }

  checkNextEpisode() {
    const v = this.video;
    if (this.nextShown || !isFinite(v.duration) || v.duration < 120) return;
    if (v.duration - v.currentTime > 20) return;
    const nx = this.nextEpisode();
    if (!nx || !sectionPrefs('series').autoNext) return;
    this.nextShown = true;
    let n = 10;
    const count = h('span', String(n));
    const card = h('div.pl-next',
      h('small', 'Próximo episódio em ', count, ' s'),
      h('strong', `T${nx.season}E${nx.episode} — ${nx.title}`),
      h('div.pl-card-act',
        btn('Assistir agora', { cls: 'primary', icon: 'play', onclick: () => this.playEpisode(nx) }),
        btn('Cancelar', { cls: 'ghost', onclick: () => { clearInterval(this.countT); card.remove(); this.nextCanceled = true; } })));
    this.overlayBox.append(card);
    this.countT = setInterval(() => {
      n--;
      count.textContent = String(n);
      if (n <= 0) { clearInterval(this.countT); this.playEpisode(nx); }
    }, 1000);
  }

  playEpisode(ep) {
    this.save();
    clearInterval(this.countT);
    clear(this.overlayBox);
    this.nextShown = false;
    this.nextCanceled = false;
    this.item = ep;
    this.opts.startAt = undefined;
    this.load();
  }

  onEnded() {
    if (this.kind === 'episode') {
      this.save(true);
      const nx = this.nextEpisode();
      if (nx && sectionPrefs('series').autoNext && !this.nextCanceled) this.playEpisode(nx);
    } else if (this.kind === 'movie') {
      this.save(true);
    }
  }

  fileProgress() {
    try { return JSON.parse(localStorage.getItem('sintonia.file.' + this.opts.file.id) || 'null'); } catch { return null; }
  }

  save(ended) {
    const v = this.video;
    if (this.kind === 'file' && isFinite(v.duration) && v.currentTime > 5) {
      try { localStorage.setItem('sintonia.file.' + this.opts.file.id, JSON.stringify({ pos: ended ? v.duration : Math.floor(v.currentTime), dur: Math.floor(v.duration) })); } catch { /* sem espaço */ }
      return;
    }
    if (!(this.kind === 'movie' || this.kind === 'episode')) return;
    if (!isFinite(v.duration) || !v.duration || v.currentTime < 5) return;
    const it = this.item;
    const entry = { kind: this.kind, id: it.id, pos: ended ? v.duration : Math.floor(v.currentTime), dur: Math.floor(v.duration), ext: it.ext };
    if (this.kind === 'movie') Object.assign(entry, { name: it.name, img: it.poster || '' });
    else Object.assign(entry, { name: it.title, img: this.opts.series?.poster || it.still || '', seriesId: this.opts.series?.id,
      seriesName: this.opts.series?.name, season: it.season, episode: it.episode,
      ref: { id: it.id, ext: it.ext, url: it.url, cmd: it.cmd, series_num: it.series_num, season: it.season, episode: it.episode, title: it.title } });
    saveProgress(entry).catch(() => {});
  }

  // ---------------------------------------------------------------- teclado e saída
  bindKeys() {
    this.onKey = (e) => {
      if (e.target.closest('input, textarea, select') || document.querySelector('.modal-back')) return;
      const k = e.key;
      if (k === 'Escape') { if (this.side.classList.contains('open')) this.toggleSide(); else if (!document.fullscreenElement) this.close(); }
      else if (k === ' ' || k === 'k' || k === 'K') { e.preventDefault(); this.togglePlay(); }
      else if (k === 'f' || k === 'F') this.fullscreen();
      else if (k === 'm' || k === 'M') this.toggleMute();
      else if (k === 'ArrowLeft' && this.vod) this.seekBy(-this.skip);
      else if (k === 'ArrowRight' && this.vod) this.seekBy(this.skip);
      else if (k === 'ArrowUp') { e.preventDefault(); if (this.live) this.zap(-1); else this.video.volume = Math.min(1, this.video.volume + 0.1); }
      else if (k === 'ArrowDown') { e.preventDefault(); if (this.live) this.zap(1); else this.video.volume = Math.max(0, this.video.volume - 0.1); }
      else if (k === 'PageUp' && this.live) this.zap(-1);
      else if (k === 'PageDown' && this.live) this.zap(1);
      else return;
      this.showUi();
    };
    document.addEventListener('keydown', this.onKey);
    this.onHide = () => this.save();
    window.addEventListener('pagehide', this.onHide);
    document.addEventListener('visibilitychange', this.onHide);
  }

  close(silent) {
    if (this.closed) return;
    this.closed = true;
    this.save();
    clearInterval(this.saveT);
    clearInterval(this.countT);
    clearInterval(this.recT);
    clearInterval(this.reserveT);
    window.removeEventListener('online', this.onNet);
    window.removeEventListener('offline', this.onNet);
    clearTimeout(this.stallT);
    clearTimeout(this.hideT);
    this.stopFps();
    if (this.ctrl) this.ctrl.destroy();
    document.removeEventListener('keydown', this.onKey);
    window.removeEventListener('pagehide', this.onHide);
    document.removeEventListener('visibilitychange', this.onHide);
    document.removeEventListener('fullscreenchange', this.onFs);
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
    this.pipState();
    this.el.classList.remove('show');
    setTimeout(() => this.el.remove(), silent ? 0 : 200);
    document.body.classList.remove('playing');
    if (current === this) current = null;
    window.dispatchEvent(new CustomEvent('sintonia:player-closed', { detail: { kind: this.kind } }));
  }
}

