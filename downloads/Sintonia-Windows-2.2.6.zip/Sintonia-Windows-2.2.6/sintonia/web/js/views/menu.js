// Menu, fontes e configurações
import { api } from '../api.js';
import {
  KIND_LABEL, S, base, catalog, emit, isLocked, loadCatalog, loadState, saveSettings, src,
} from '../state.js';
import {
  btn, clear, confirmBox, copyText, fmtDate, h, ic, iconBtn, menu, pinBox, promptBox, spinner, toast, toggle,
} from '../ui.js';
import { sectionHeader } from './common.js';
import { smartTubeModal, spectraModal, updateModal } from './update.js';
import { folderBar } from './folders.js';
import { canScan, deviceFinder, exportModal, importModal, scanPair, syncQrModal } from './share.js';

const TYPE_LABEL = { xtream: 'Xtream Codes', m3u: 'Playlist M3U', stalker: 'Portal Stalker' };

function get(path) {
  return path.split('.').reduce((o, k) => (o ? o[k] : undefined), S.settings);
}
function patchFor(path, value) {
  const keys = path.split('.');
  const out = {};
  let o = out;
  keys.forEach((k, i) => { if (i === keys.length - 1) o[k] = value; else { o[k] = {}; o = o[k]; } });
  return out;
}
const set = (path, value) => saveSettings(patchFor(path, value)).then(() => toast('Salvo', { ms: 1200 }));

function row(label, sub, control, opts = {}) {
  return h('div.set-row', { class: opts.cls || '', onclick: opts.onclick || null, role: opts.onclick ? 'button' : null, tabindex: opts.onclick ? '0' : null },
    h('div.set-txt', h('span', label), sub ? h('small', sub) : null), control || null);
}
function toggleRow(label, path, sub) {
  return row(label, sub, toggle(get(path), (v) => set(path, v), label));
}
function choiceRow(label, path, options, sub) {
  const valEl = h('small');
  const show = () => { valEl.textContent = (options.find((o) => o[0] === get(path)) || options[0])[1]; };
  show();
  const r = row(label, null, ic('chevR', 'muted'), { onclick: async () => {
    const ch = await menu(options.map(([v, l]) => ({ label: l, value: v, checked: v === get(path) })), { title: label });
    if (ch) { await set(path, ch.value); show(); }
  } });
  r.querySelector('.set-txt').append(valEl);
  if (sub) r.querySelector('.set-txt').append(h('small.sub2', sub));
  return r;
}
function actionRow(label, fn, opts = {}) {
  return h('button.set-row.action', { type: 'button', class: opts.danger ? 'danger' : '', onclick: fn }, h('div.set-txt', h('span', label), opts.sub ? h('small', opts.sub) : null), opts.icon ? ic(opts.icon) : null);
}
const group = (title, ...rows) => h('section.set-group', title ? h('h3', title) : null, ...rows);

function subPage(root, title, ...content) {
  root.append(sectionHeader(title, { back: () => { location.hash = '#/menu'; } }), h('div.view-body.narrow', ...content));
}

// ================================================================= página principal
export function render(root, params) {
  const page = params[0] || '';
  const pages = { fontes: sourcesPage, fonte: sourcePage, personalizacao: personalPage, parental: parentalPage,
    player: playerPage, epg: epgPage, tema: themePage, dispositivos: devicesPage, sobre: aboutPage, sincronizar: syncPage };
  if (pages[page]) return pages[page](root, params.slice(1));
  return mainPage(root);
}

function mainPage(root) {
  const s = src();
  const acc = h('div.acc-status', spinner());
  const card = h('section.acc-card',
    h('div.acc-left',
      h('div.acc-ic', ic('signal')),
      h('div',
        h('small.acc-kicker', s ? TYPE_LABEL[s.type] : 'Nenhuma fonte'),
        h('h2', s ? s.name : 'Adicione sua lista'),
        acc,
        h('p.muted', S.settings.sync?.enabled
          ? `Sincronização ligada com ${S.settings.sync.peer || 'outro aparelho'}.`
          : 'Seus favoritos e histórico ficam neste aparelho. Para juntar com outro Sintonia da rede, use "Sincronizar aparelhos na rede".'))),
    h('div.acc-right',
      h('a.acc-link', { href: '#/menu/fontes' }, h('span.acc-link-ic', ic('listCheck')), h('div', h('strong', 'Gerenciar fontes e playlists'), h('small', 'Adicionar, remover ou trocar de lista')), ic('chevR')),
      s ? h('a.acc-link', { href: `#/menu/fonte/${s.id}` }, h('span.acc-link-ic', ic('sliders')), h('div', h('strong', 'Configurações da lista atual'), h('small', s.name)), ic('chevR')) : null));
  const items = [
    ['personalizacao', 'brush', 'Personalização'],
    ['parental', 'lock', 'Controle parental'],
    ['player', 'play', 'Reprodutor de vídeo'],
    ['epg', 'guide', 'Guia de programação (EPG)'],
    ['tema', 'moon', 'Tema e cores'],
    ['dispositivos', 'devices', 'Instalar o app e usar em outros aparelhos'],
    ['sincronizar', 'wifi', 'Sincronizar aparelhos na rede'],
    ['#/offline', 'offline', 'Offline: downloads e gravações'],
    ['#/multi', 'grid', 'Multitela'],
    ['sobre', 'info', 'Sobre, notas da versão e atalhos'],
  ];
  const list = h('nav.menu-links', ...items.map(([id, icn, label]) => h('a.menu-link', { href: id.startsWith('#') ? id : `#/menu/${id}` }, ic(icn), h('span', label), ic('chevR', 'muted'))));
  root.append(sectionHeader('Menu'), h('div.view-body', card, list, h('p.version', `Sintonia ${S.version}`)));
  if (s) {
    api.get(`${base()}/account`).then((a) => {
      clear(acc);
      const active = /active|ativo/i.test(a.status || 'Active');
      acc.append(h('span.pill', { class: active ? 'ok' : 'bad' }, h('i'), active ? 'Assinatura ativa' : `Situação: ${a.status}`));
      if (a.expires) acc.append(h('span.pill', ic('calendar'), `Vence em ${fmtDate(a.expires)}`));
      if (a.maxCons) acc.append(h('span.pill', ic('devices'), `${a.activeCons}/${a.maxCons} conexões`));
      if (a.isTrial) acc.append(h('span.pill.warn', 'Teste'));
    }).catch((e) => { clear(acc).append(h('span.pill.bad', h('i'), e.message)); });
  } else clear(acc);
}

// ================================================================= fontes
function sourcesPage(root) {
  const list = h('div.src-list');
  const draw = () => {
    clear(list);
    list.append(h('a.src-add', { href: '#/menu/fonte/nova' }, h('span.acc-link-ic', ic('plus')), h('strong', 'Adicionar fonte'), ic('chevR')));
    list.append(h('div.src-share',
      btn('Importar lista', { cls: 'ghost sm', icon: 'upload', onclick: () => importModal() }),
      S.sources.length ? btn(S.sources.length > 1 ? 'Exportar todas' : 'Exportar', { cls: 'ghost sm', icon: 'qr', onclick: () => exportModal() }) : null));
    S.sources.forEach((s) => {
      const on = s.id === S.active;
      list.append(h('div.src-item', { class: on ? 'on' : '' },
        h('div.src-txt', h('strong', s.name, on ? h('span.pill.ok.sm', h('i'), 'em uso') : null),
          h('small', `${TYPE_LABEL[s.type]} · ${hostOf(s.url)} · desde ${fmtDate(s.created)}`)),
        !on ? btn('Usar', { cls: 'ghost sm', onclick: () => switchSource(s.id) }) : null,
        iconBtn('moreH', 'Opções', () => menu([
          ...(!on ? [{ label: 'Usar esta fonte', icon: 'check', fn: () => switchSource(s.id) }] : []),
          { label: 'Editar', icon: 'edit', fn: () => { location.hash = `#/menu/fonte/${s.id}`; } },
          { label: 'Exportar (arquivo ou QR)', icon: 'qr', fn: () => exportModal([s.id]) },
          { label: 'Atualizar canais e guia', icon: 'refresh', fn: async () => { await api.post(`/api/sources/${s.id}/refresh`); if (on) { S.catalogs = {}; } toast('Lista atualizada. Abrindo de novo carrega o conteúdo novo.'); } },
          null,
          { label: 'Remover', icon: 'trash', danger: true, fn: async () => {
            if (!(await confirmBox(`Remover "${s.name}"? Favoritos e histórico desta fonte também serão apagados.`, { ok: 'Remover', danger: true }))) return;
            await api.del(`/api/sources/${s.id}`);
            await loadState();
            if (on) window.dispatchEvent(new CustomEvent('sintonia:source-changed'));
            draw();
          } },
        ], { title: s.name }))));
    });
  };
  draw();
  subPage(root, 'Fontes e playlists', list);
}

function hostOf(u) {
  try { return new URL(u.includes('://') ? u : 'http://' + u).host; } catch { return u; }
}

export async function switchSource(id) {
  await api.post(`/api/sources/${id}/activate`);
  await loadState();
  window.dispatchEvent(new CustomEvent('sintonia:source-changed'));
}

function sourcePage(root, params) {
  const id = params[0];
  const existing = id && id !== 'nova' ? S.sources.find((s) => s.id === id) : null;
  subPage(root, existing ? 'Editar fonte' : 'Adicionar fonte', sourceForm({
    source: existing,
    onSaved: async (saved, isNew) => {
      await loadState();
      if (isNew || saved.id === S.active) window.dispatchEvent(new CustomEvent('sintonia:source-changed', { detail: { id: saved.id } }));
      else location.hash = '#/menu/fontes';
    },
  }));
}

/** Formulário de fonte (usado também na primeira configuração). */
export function sourceForm({ source, onSaved }) {
  let type = source?.type || 'xtream';
  const f = {
    name: h('input.input', { value: source?.name || '', placeholder: 'Ex.: Minha TV', autocomplete: 'off' }),
    url: h('input.input', { value: source?.url || '', autocomplete: 'off', spellcheck: 'false', inputmode: 'url' }),
    username: h('input.input', { value: source?.username || '', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'off' }),
    password: h('input.input', { value: source?.password || '', type: 'password', autocomplete: 'off' }),
    mac: h('input.input', { value: source?.mac || '00:1A:79:', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'characters' }),
    epgUrl: h('input.input', { value: source?.epgUrl || '', placeholder: 'Opcional: deixe vazio para usar o guia do provedor', autocomplete: 'off', inputmode: 'url' }),
    ua: h('input.input', { value: source?.ua || '', placeholder: 'Opcional: alguns provedores exigem um específico', autocomplete: 'off' }),
  };
  const seg = h('div.seg.wide');
  const fields = h('div.form-fields');
  const err = h('p.form-err', { role: 'alert' });
  const showPw = h('button.icon-btn.in-input', { type: 'button', 'aria-label': 'Mostrar senha', onclick: () => { f.password.type = f.password.type === 'password' ? 'text' : 'password'; } }, ic('eye'));
  const field = (label, input, extra) => h('label.field', h('span.field-label', label), h('div.input-wrap', input, extra || null));
  const draw = () => {
    clear(seg);
    [['m3u', 'Playlist M3U/M3U8'], ['xtream', 'Xtream Codes'], ['stalker', 'Portal Stalker']].forEach(([t, l]) =>
      seg.append(h('button', { type: 'button', class: type === t ? 'on' : '', onclick: () => { type = t; draw(); } }, l)));
    clear(fields);
    fields.append(field('Nome', f.name));
    if (type === 'm3u') {
      f.url.placeholder = 'http://servidor.com/lista.m3u';
      fields.append(field('Endereço da lista (URL)', f.url));
      fields.append(h('p.hint', 'Link com get.php?username=…&password=… é de painel Xtream: ao colar, o Sintonia muda para Xtream e preenche tudo.'));
      fields.append(h('p.hint', 'Também aceita o caminho de um arquivo .m3u no aparelho onde o Sintonia roda, como /sdcard/Download/lista.m3u.'));
    } else if (type === 'xtream') {
      f.url.placeholder = 'http://servidor.com:8080 ou cole o link da playlist';
      fields.append(field('Servidor', f.url), h('p.hint', 'Pode colar o link completo da playlist (get.php?username=…): usuário e senha são preenchidos sozinhos.'),
        field('Usuário', f.username), field('Senha', f.password, showPw));
    } else {
      f.url.placeholder = 'http://portal.com:8080/c/';
      fields.append(field('Endereço do portal', f.url), field('Endereço MAC', f.mac));
    }
    fields.append(h('details.adv', h('summary', 'Opções avançadas'), field('Endereço do guia (EPG/XMLTV)', f.epgUrl), field('User-Agent', f.ua)));
  };
  draw();
  // Colou o link da playlist (get.php?username=…&password=…)? Vira Xtream com tudo preenchido.
  const autofill = () => {
    const raw = f.url.value.trim();
    let u;
    try { u = new URL(raw.includes('://') ? raw : 'http://' + raw); } catch { return; }
    const user = u.searchParams.get('username');
    const pw = u.searchParams.get('password');
    if (!/\/(get|playlist|player_api)\.php$/i.test(u.pathname) || !user || !pw) return;
    const root = u.pathname.replace(/\/[^/]*$/, '');
    f.url.value = `${u.protocol}//${u.host}${root}`;
    f.username.value = user;
    f.password.value = pw;
    if (!f.name.value.trim()) f.name.value = u.hostname.split('.')[0].toUpperCase();
    if (type !== 'xtream') { type = 'xtream'; draw(); }
    toast('Link da playlist reconhecido: servidor, usuário e senha preenchidos.', { type: 'ok' });
  };
  f.url.addEventListener('paste', () => setTimeout(autofill, 0));
  f.url.addEventListener('change', autofill);
  f.url.addEventListener('blur', autofill);

  const submit = btn(source ? 'Salvar alterações' : 'Adicionar fonte', { cls: 'primary lg block', icon: 'check' });
  submit.addEventListener('click', async () => {
    err.textContent = '';
    submit.disabled = true;
    const label = submit.querySelector('span:last-child');
    const old = label.textContent;
    label.textContent = 'Conectando…';
    try {
      const body = { id: source?.id, type, name: f.name.value, url: f.url.value.trim(), username: f.username.value.trim(),
        password: f.password.value, mac: f.mac.value.trim(), epgUrl: f.epgUrl.value.trim(), ua: f.ua.value.trim() };
      if (!body.name) body.name = type === 'stalker' ? 'Portal' : hostOf(body.url);
      const saved = await api.post('/api/sources', body);
      onSaved(saved, !source);
    } catch (e) {
      err.textContent = e.message;
    } finally {
      submit.disabled = false;
      label.textContent = old;
    }
  });
  const form = h('div.src-form', seg, fields, err, submit);
  form.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.tagName === 'INPUT') submit.click(); });
  return form;
}

// ================================================================= personalização
function personalPage(root) {
  const catOpts = (kind) => [['', 'Nenhuma categoria padrão'], ...((catalog(kind)?.categories || []).map((c) => [c.id, c.name]))];
  const sortOpts = [['remember', 'Lembrar última ordenação'], ['default', 'Ordem da lista'], ['az', 'A → Z'], ['za', 'Z → A'], ['added', 'Adicionados recentemente'], ['rating', 'Melhor avaliação']];
  const clearHist = (what, label) => actionRow(label, async () => {
    if (!(await confirmBox('Limpar o histórico de visualização?', { ok: 'Limpar', danger: true }))) return;
    S.user = await api.post(`${base()}/user/clear`, { what });
    emit('settings');
    toast('Histórico limpo');
  }, { danger: true });
  const content = h('div');
  const draw = () => {
    clear(content).append(
      group('Configurações gerais',
        choiceRow('Iniciar na aba', 'startTab', [['live', 'TV ao Vivo'], ['series', 'Séries'], ['movies', 'Filmes'], ['search', 'Pesquisar']]),
        choiceRow('Formato de hora', 'timeFormat', [['24', '24 horas'], ['12', '12 horas (AM/PM)']])),
      group('TV ao Vivo',
        toggleRow('Sempre mostrar favoritos primeiro', 'live.favFirst'),
        toggleRow('Abrir com a grade de programação', 'live.openGuide'),
        choiceRow('Abrir com categoria selecionada', 'live.defaultCat', catOpts('live')),
        choiceRow('Ordenação padrão', 'live.sort', sortOpts.filter((o) => o[0] !== 'rating')),
        toggleRow('Mostrar canais assistidos recentemente', 'live.showRecent'),
        clearHist('live', 'Limpar canais recentes')),
      group('Séries',
        toggleRow('Sempre mostrar favoritos primeiro', 'series.favFirst'),
        choiceRow('Abrir com categoria selecionada', 'series.defaultCat', catOpts('series')),
        choiceRow('Ordenação padrão', 'series.sort', sortOpts),
        toggleRow('Mostrar "Continuar assistindo"', 'series.showRecent'),
        toggleRow('Mostrar destaques (Popular e Novidades)', 'series.showPopular', 'Desativado por padrão'),
        toggleRow('Reproduzir o próximo episódio automaticamente', 'series.autoNext'),
        clearHist('series', 'Limpar o histórico de séries')),
      group('Filmes',
        toggleRow('Sempre mostrar favoritos primeiro', 'movies.favFirst'),
        choiceRow('Abrir com categoria selecionada', 'movies.defaultCat', catOpts('movie')),
        choiceRow('Ordenação padrão', 'movies.sort', sortOpts),
        toggleRow('Mostrar "Continuar assistindo"', 'movies.showRecent'),
        toggleRow('Mostrar destaques (Popular e Novidades)', 'movies.showPopular', 'Desativado por padrão'),
        clearHist('movie', 'Limpar o histórico de filmes')),
      group('Histórico de visualização', clearHist('all', 'Limpar todo o histórico de visualização')),
      group('Downloads',
        pathRow('Pasta dos downloads', 'downloadDir')),
      group('Gravações',
        pathRow('Pasta das gravações', 'recordDir')),
    );
  };
  Promise.allSettled(['live', 'movie', 'series'].map((k) => loadCatalog(k))).then(draw);
  draw();
  subPage(root, 'Personalização', content);
}

function pathRow(label, key) {
  const kind = key === 'recordDir' ? 'rec' : 'download';
  return h('div.set-row.folder-row', folderBar(kind));
}

// ================================================================= controle parental
function parentalPage(root) {
  const content = h('div');
  const draw = async () => {
    clear(content);
    const p = S.parental;
    content.append(group('PIN',
      row(p.hasPin ? 'PIN definido' : 'Nenhum PIN definido', p.hasPin ? 'Categorias bloqueadas pedem o PIN para abrir.' : 'Crie um PIN de 4 a 8 números para bloquear categorias.',
        btn(p.hasPin ? 'Trocar PIN' : 'Criar PIN', { cls: 'ghost sm', onclick: changePin })),
      p.hasPin ? row('Bloquear conteúdo adulto automaticamente', 'Bloqueia categorias com nomes como "Adultos", "XXX" ou "+18".',
        toggle(p.autoAdult, async (v) => {
          const pin = await pinBox('Confirme o PIN');
          if (pin === null) { draw(); return; }
          try { S.parental = await api.post('/api/parental/settings', { pin, autoAdult: v }); toast('Salvo'); } catch (e) { toast(e.message, { type: 'error' }); }
          draw();
        })) : null,
      p.hasPin ? actionRow('Remover PIN e desbloquear tudo', async () => {
        const pin = await pinBox('PIN atual');
        if (pin === null) return;
        try { S.parental = await api.post('/api/parental/pin', { old: pin, new: '' }); S.unlocked.clear(); toast('PIN removido'); draw(); } catch (e) { toast(e.message, { type: 'error' }); }
      }, { danger: true }) : null));
    if (!p.hasPin || !S.active) return;
    await Promise.allSettled(['live', 'movie', 'series'].map((k) => loadCatalog(k)));
    for (const kind of ['live', 'movie', 'series']) {
      const c = catalog(kind);
      if (!c || !c.categories.length) continue;
      const rows = c.categories.map((cat) => row(cat.name, null, toggle(isLocked(kind, cat.id), async (v) => {
        if (!S.pinOk) {
          const pin = await pinBox('Confirme o PIN');
          if (pin === null) { draw(); return; }
          S.pinCache = pin;
        }
        try {
          S.parental = await api.post('/api/parental/lock', { pin: S.pinCache, src: S.active, kind, cat: cat.id, on: v });
          S.pinOk = true;
          emit('cats');
        } catch (e) { S.pinOk = false; toast(e.message, { type: 'error' }); draw(); }
      }, cat.name)));
      content.append(h('details.set-group.collapse', h('summary', h('h3', `Bloquear categorias de ${KIND_LABEL[kind]}`)), ...rows));
    }
  };
  async function changePin() {
    let old = '';
    if (S.parental.hasPin) { old = await pinBox('PIN atual'); if (old === null) return; }
    const nw = await promptBox('Novo PIN (4 a 8 números)', { title: 'Novo PIN', type: 'password', inputmode: 'numeric', maxlength: 8 });
    if (!nw) return;
    try {
      S.parental = await api.post('/api/parental/pin', { old, new: nw });
      S.pinOk = true;
      S.pinCache = nw;
      toast('PIN salvo');
      draw();
    } catch (e) { toast(e.message, { type: 'error' }); }
  }
  draw();
  subPage(root, 'Controle parental', content);
}

// ================================================================= player
const BUFFER_MODES = [
  ['low', 'Latência baixa', 'Ao vivo mais próximo do tempo real. Guarda pouco vídeo; trava mais se a internet oscilar.'],
  ['normal', 'Normal', 'Equilíbrio entre atraso e estabilidade.'],
  ['high', 'Alto', 'Guarda 1 a 5 minutos à frente. Bom para Wi-Fi instável.'],
  ['max', 'Máximo', 'Guarda até 15 minutos à frente e insiste sem parar se a conexão cair. Ao vivo começa em ~1 s e reconecta sozinho.'],
  ['ultra', 'Ultra extremo', 'Filmes e episódios são baixados inteiros, o mais rápido possível, para o aparelho do Sintonia. Sem internet, o vídeo segue até onde foi carregado e o download continua do mesmo ponto quando a conexão volta. Ao vivo ganha 15 s de reserva.'],
];

function playerPage(root) {
  const modes = h('div.mode-list');
  const drawModes = () => {
    clear(modes);
    BUFFER_MODES.forEach(([id, label, desc]) => {
      const on = (S.settings.player.buffer || 'max') === id;
      modes.append(h('button.mode-opt', { type: 'button', class: on ? 'on' : '', role: 'radio', 'aria-checked': String(on),
        onclick: async () => { await set('player.buffer', id); drawModes(); } },
      h('div.set-txt', h('span', label, id === 'ultra' ? h('span.tag-ultra', 'ULTRA') : null), h('small', desc)), h('span.radio')));
    });
  };
  drawModes();
  const uaInput = h('input.input', { value: S.settings.player.userAgent || '', placeholder: 'Ex.: VLC/3.0.20 LibVLC/3.0.20', autocomplete: 'off', spellcheck: 'false' });
  const uaBox = h('div.ua-box', h('div.input-wrap', uaInput),
    h('p.hint', 'Alguns provedores só liberam o vídeo para um User-Agent específico. Vazio usa o padrão do Sintonia.'),
    h('div.ua-act',
      btn('Limpar', { cls: 'ghost', onclick: async () => { uaInput.value = ''; await set('player.userAgent', ''); } }),
      btn('Salvar', { cls: 'primary', onclick: () => set('player.userAgent', uaInput.value.trim()) })));
  subPage(root, 'Reprodutor de vídeo',
    group('Estabilidade da reprodução', modes),
    group('Controles',
      choiceRow('Duração do salto', 'player.skipSeconds', [[5, '5 segundos'], [10, '10 segundos'], [15, '15 segundos'], [30, '30 segundos'], [60, '1 minuto']]),
      choiceRow('Tempo dos controles na tela', 'player.controlsSeconds', [[2, '2 segundos'], [3, '3 segundos'], [4, '4 segundos'], [6, '6 segundos'], [10, '10 segundos']]),
      toggleRow('Iniciar o player em modo paisagem', 'player.landscape', 'No celular e no tablet, abre em tela cheia deitada'),
      choiceRow('Continuar de onde parou', 'player.resume', [['ask', 'Perguntar'], ['auto', 'Continuar automaticamente'], ['never', 'Sempre do início']]),
      choiceRow('Proporção padrão', 'player.aspect', [['contain', 'Ajustar à tela'], ['cover', 'Preencher (corta bordas)'], ['fill', 'Esticar']])),
    document.body.classList.contains('tv') && window.SintoniaNative && window.SintoniaNative.play ? group('Android TV',
      choiceRow('Player da TV', 'player.tvPlayer', [
        ['live', 'Ao vivo no player nativo, filmes e séries no do celular (recomendado)'],
        ['native', 'Tudo no player nativo do Android'],
        ['web', 'Tudo no player do celular (gravar, legendas, multitela)']],
        'O nativo abre e troca de canal ao vivo bem mais rápido em TV box. Para gravar um canal, use o do celular.')) : null,
    group('Formato e conexão',
      choiceRow('Formato da TV ao vivo', 'player.liveFormat', [['ts', 'MPEG-TS (.ts), mais compatível com provedores'], ['m3u8', 'HLS (.m3u8), melhor no iPhone e Safari']],
        'Se um canal falhar, o Sintonia tenta o outro formato sozinho.'),
      row('Passar o vídeo pelo servidor do Sintonia', 'Recomendado. Evita bloqueios do navegador e é necessário para os modos Máximo e Ultra.',
        toggle(S.settings.player.useProxy, (v) => set('player.useProxy', v)))),
    group('User-Agent personalizado', uaBox));
}

// ================================================================= EPG
function epgPage(root) {
  const st = h('div.epg-status', spinner());
  const loadStatus = async () => {
    if (!S.active) { clear(st); return; }
    try {
      const s = await api.get(`${base()}/epg/status`);
      clear(st).append(
        h('span.pill', { class: s.loaded ? 'ok' : s.loading ? 'warn' : 'bad' }, h('i'), s.loading ? 'Atualizando…' : s.loaded ? `${s.channels} canais com guia` : 'Guia não carregado'),
        s.at ? h('span.pill', ic('history'), `Atualizado em ${new Date(s.at * 1000).toLocaleString('pt-BR')}`) : null,
        s.error ? h('p.form-err', s.error) : null);
      if (s.loading) setTimeout(loadStatus, 3000);
    } catch (e) { clear(st).append(h('p.form-err', e.message)); }
  };
  const offsets = [];
  for (let m = -720; m <= 720; m += 30) offsets.push([m, m === 0 ? 'Sem ajuste' : `${m > 0 ? '+' : '−'}${Math.floor(Math.abs(m) / 60)}h${Math.abs(m) % 60 ? '30' : ''}`]);
  subPage(root, 'Guia de programação',
    group('Situação', st, actionRow('Atualizar o guia agora', async () => { await api.post(`${base()}/epg/refresh`); loadStatus(); }, { icon: 'refresh' })),
    group('Ajustes',
      toggleRow('Mostrar guia de programação', 'epg.enabled'),
      choiceRow('Atualizar o guia a cada', 'epg.refreshHours', [[6, '6 horas'], [12, '12 horas'], [24, '24 horas'], [48, '2 dias']]),
      choiceRow('Ajuste de horário', 'epg.offsetMinutes', offsets, 'Use se a programação aparecer adiantada ou atrasada.'),
      src() ? h('a.set-row.action', { href: `#/menu/fonte/${S.active}` }, h('div.set-txt', h('span', 'Endereço do guia desta fonte'), h('small', src().epgUrl || 'Automático (do provedor)')), ic('chevR')) : null));
  loadStatus();
}

// ================================================================= tema
function themePage(root) {
  const ACC = [['azul', 'Azul', '#2F7BFF'], ['ciano', 'Ciano', '#06B6D4'], ['violeta', 'Violeta', '#7C5CFF'], ['verde', 'Verde', '#16B97A'], ['ambar', 'Âmbar', '#F59E0B'], ['rosa', 'Rosa', '#E5246E'], ['vermelho', 'Vermelho', '#E5383B']];
  const sw = h('div.swatches');
  const drawSw = () => {
    clear(sw);
    ACC.forEach(([id, label, color]) => sw.append(h('button.swatch', { type: 'button', class: S.settings.accent === id ? 'on' : '', style: { '--c': color }, title: label,
      onclick: async () => { await saveSettings({ accent: id }); drawSw(); } }, h('i'), h('span', label))));
  };
  drawSw();
  subPage(root, 'Tema e cores',
    group('Aparência', choiceRow('Tema', 'theme', [['dark', 'Escuro'], ['light', 'Claro'], ['auto', 'Seguir o sistema']])),
    group('Cor de destaque', sw),
    brandingGroup());
}

/** Título e logo próprios no espaço livre da barra lateral (opcional). */
function brandingGroup() {
  const b = () => S.settings.branding || {};
  const box = h('div');
  const prev = h('div.brand-prev');
  const title = h('input.input', { value: b().title || '', maxlength: 40, placeholder: 'Ex.: TV da Família', autocomplete: 'off' });
  const file = h('input', { type: 'file', accept: 'image/png,image/webp,image/svg+xml,image/jpeg', hidden: true });
  let logo = b().logo || '';
  const drawPrev = () => {
    clear(prev);
    if (logo) prev.append(h('img.side-brand-logo', { src: logo, alt: '' }));
    if (title.value.trim()) prev.append(h('div.side-brand-title', title.value.trim()));
    if (!logo && !title.value.trim()) prev.append(h('small.muted', 'Pré-visualização'));
  };
  title.addEventListener('input', drawPrev);
  file.addEventListener('change', async () => {
    const f = file.files && file.files[0];
    file.value = '';
    if (!f) return;
    try { logo = await shrinkImage(f, 360); drawPrev(); } catch { toast('Não consegui abrir essa imagem. Use um PNG.', { type: 'error' }); }
  });
  const draw = () => {
    const on = !!b().enabled;
    clear(box).append(
      row('Mostrar título personalizado', 'Aparece no espaço livre da barra lateral, acima do nome da fonte.',
        toggle(on, async (v) => { await saveSettings({ branding: { enabled: v } }); draw(); }, 'Título personalizado')),
      on ? h('div.brand-edit', prev,
        h('div.brand-fields',
          h('label.field', h('span.field-label', 'Título'), title),
          h('div.ua-act',
            btn(logo ? 'Trocar imagem' : 'Escolher imagem (PNG)', { cls: 'ghost sm', icon: 'upload', onclick: () => file.click() }),
            btn('Tirar imagem', { cls: 'ghost sm', onclick: () => { logo = ''; drawPrev(); } }),
            btn('Salvar', { cls: 'primary sm', onclick: async () => {
              await saveSettings({ branding: { title: title.value.trim(), logo } });
              toast('Título salvo', { type: 'ok' });
            } })),
          h('p.hint', 'Dica: PNG com fundo transparente, como uma logomarca, fica melhor.'), file)) : null);
    drawPrev();
  };
  draw();
  return group('Título personalizado', box);
}

/** Reduz a imagem (mantendo a transparência) para guardar nas configurações. */
function shrinkImage(fileObj, max) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onerror = reject;
    r.onload = () => {
      if (fileObj.type === 'image/svg+xml') { resolve(r.result); return; }
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const k = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(img.width * k));
        c.height = Math.max(1, Math.round(img.height * k));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/png'));
      };
      img.src = r.result;
    };
    r.readAsDataURL(fileObj);
  });
}

// ================================================================= instalar e outros aparelhos
function installRow() {
  const standalone = matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: window-controls-overlay)').matches;
  if (standalone) return row('O Sintonia já está instalado como aplicativo', 'Você está usando a janela do app.', ic('check'));
  const b = btn('Instalar app', { cls: 'primary sm', icon: 'download', onclick: async () => {
    const ev = window.__sintoniaInstall;
    if (!ev) {
      toast('Use o ícone de instalar na barra de endereço do Chrome ou do Edge (ou menu ⋮ › Instalar Sintonia).');
      return;
    }
    ev.prompt();
    const r = await ev.userChoice.catch(() => null);
    if (r && r.outcome === 'accepted') toast('Sintonia instalado. Ele aparece no Menu Iniciar e na Área de Trabalho.', { type: 'ok' });
    window.__sintoniaInstall = null;
  } });
  return row('Instalar como aplicativo', window.isSecureContext
    ? 'Cria o ícone do Sintonia e abre em janela própria, sem a barra do navegador.'
    : 'Neste endereço o navegador não libera a instalação. Abra pelo próprio aparelho (localhost) ou crie um atalho como janela.', b);
}

function devicesPage(root) {
  const urls = S.urls.length ? S.urls : [location.origin];
  subPage(root, 'Instalar e outros aparelhos',
    group('Aplicativo', installRow(),
      h('p.hint', 'No Chrome ou no Edge: ícone de instalar na barra de endereço, ou menu ⋮ › Transmitir, salvar e compartilhar › Instalar página como app.')),
    lanGroup(urls),
    group('Dicas',
      h('ul.steps',
        h('li', 'Cada aparelho com o Sintonia instalado guarda os próprios favoritos e histórico.'),
        h('li', 'Para juntar os dados de dois aparelhos, use Menu › Sincronizar com outro aparelho.'),
        h('li', 'Para proteger o acesso pela rede, inicie com: sintonia --senha SUA_SENHA'))));
}

/** Acesso de outros aparelhos: desligado por padrão, liga só marcando a caixa e confirmando. */
function lanGroup(urls) {
  const on = !!(S.settings.network && S.settings.network.allowLan);
  const box = h('input', { type: 'checkbox', checked: on || null, id: 'allow-lan' });
  const list = h('div', { hidden: !on || null },
    h('p.muted', 'Outros aparelhos no mesmo Wi-Fi podem abrir este Sintonia por um destes endereços:'),
    ...urls.map((u) => row(u, null, btn('Copiar', { cls: 'ghost sm', icon: 'copy', onclick: () => copyText(u) }))));
  box.addEventListener('change', async () => {
    if (box.checked) {
      const ok = await confirmBox('Outros aparelhos da rede vão poder abrir este Sintonia e assistir pela mesma lista. Cada canal diferente assistido ao mesmo tempo usa uma conexão do seu provedor; se a sua conta permite só 1, as outras telas podem travar. Liberar mesmo assim?',
        { title: 'Permitir outros aparelhos?', ok: 'Liberar' });
      if (!ok) { box.checked = false; return; }
    }
    await set('network.allowLan', box.checked);
    list.hidden = !box.checked;
    toast(box.checked ? 'Acesso pela rede liberado' : 'Acesso pela rede desligado: só este aparelho usa o Sintonia');
  });
  return group('Usar em outros aparelhos da rede',
    h('label.lan-check', box, h('span', 'Permitir que outros aparelhos da rede (TV, celular, outro PC) usem este Sintonia')),
    h('p.hint', 'Desligado por padrão, para evitar várias telas disputando a mesma conexão do provedor.'),
    list);
}

// ================================================================= sincronização
function syncPage(root) {
  const content = h('div');
  const cfg = () => S.settings.sync || {};
  const status = h('div.sync-status');
  const drawStatus = () => {
    const l = cfg().last || {};
    clear(status);
    if (!l.at) { status.append(h('p.muted', 'Ainda não sincronizado.')); return; }
    const when = new Date(l.at * 1000).toLocaleString('pt-BR');
    if (!l.ok) { status.append(h('span.pill.bad', h('i'), `Falhou em ${when}`), h('p.form-err', l.error || '')); return; }
    const st = l.stats || {};
    status.append(h('span.pill.ok', h('i'), `Sincronizado em ${when}${l.device ? ` com ${l.device}` : ''}`),
      h('p.muted', `Recebido: ${st.sources || 0} fonte(s), ${st.favorites || 0} favorito(s), ${st.history || 0} item(ns) de histórico.${l.pushed ? ' O outro aparelho também foi atualizado.' : ''}`),
      l.note ? h('p.hint', l.note) : null);
  };
  const peer = h('input.input', { value: cfg().peer || '', placeholder: 'Ex.: 192.168.0.15:8787', autocomplete: 'off', spellcheck: 'false', inputmode: 'url' });
  const pass = h('input.input', { value: cfg().password || '', type: 'password', placeholder: 'Só se o outro Sintonia usa senha', autocomplete: 'off' });
  const draw = () => {
    const on = !!cfg().enabled;
    clear(content).append(
      group('Sincronizar com outro aparelho',
        row('Ligar sincronização', 'Junta listas, favoritos e "continuar assistindo" com outros Sintonia da mesma rede Wi-Fi. Ligue nos dois aparelhos.',
          toggle(on, async (v) => { await saveSettings({ sync: { enabled: v }, syncAsked: true }); draw(); })),
        on ? deviceFinder({ onSynced: () => { drawStatus(); window.dispatchEvent(new CustomEvent('sintonia:source-changed')); } }) : null,
        on ? h('div.src-share.pair-qr',
          btn('Mostrar QR deste aparelho', { cls: 'ghost sm', icon: 'qr', onclick: () => syncQrModal().catch((e) => toast(e.message, { type: 'error' })) }),
          canScan() ? btn('Ler QR do outro aparelho', { cls: 'ghost sm', icon: 'camera', onclick: () => scanPair().then(drawStatus).catch((e) => { if (!/cancelada/.test(e.message)) toast(e.message, { type: 'error', ms: 6000 }); }) }) : null) : null,
        on ? h('details.adv-box', h('summary', 'Digitar o endereço manualmente'), h('div.ua-box',
          h('label.field', h('span.field-label', 'Endereço do outro Sintonia'), peer),
          h('p.hint', 'Veja o endereço no outro aparelho em Menu › Instalar e outros aparelhos. Os dois precisam estar na mesma rede Wi-Fi.'),
          h('label.field', h('span.field-label', 'Senha do outro Sintonia (opcional)'), pass),
          h('div.ua-act',
            btn('Testar conexão', { cls: 'ghost', onclick: async () => {
              try {
                const r = await api.post('/api/sync/test', { peer: peer.value.trim(), password: pass.value });
                toast(`Encontrado: ${r.device} (${r.sources} fonte${r.sources === 1 ? '' : 's'})${r.accepts ? '' : '. Lá a sincronização está desligada; ligue também para enviar dados para ele.'}`, { ms: 6000 });
              } catch (e) { toast(e.message, { type: 'error', ms: 6000 }); }
            } }),
            btn('Salvar', { cls: 'primary', onclick: async () => { await saveSettings({ sync: { peer: peer.value.trim(), password: pass.value } }); toast('Salvo'); } })))) : null),
      on ? group('O que sincronizar',
        toggleRow('Fontes e playlists', 'sync.items.sources', 'Adiciona aqui as listas que existem só no outro aparelho'),
        toggleRow('Favoritos, categorias fixadas e ocultas', 'sync.items.favorites'),
        toggleRow('Histórico e "continuar de onde parou"', 'sync.items.history'),
        toggleRow('Configurações (tema, cores, preferências)', 'sync.items.settings', 'Copia as do outro aparelho para este')) : null,
      on ? group('Quando sincronizar',
        toggleRow('Sincronizar automaticamente', 'sync.auto'),
        choiceRow('Intervalo', 'sync.everyMinutes', [[5, 'A cada 5 minutos'], [15, 'A cada 15 minutos'], [60, 'A cada hora']]),
        status,
        h('div.ua-box', btn('Sincronizar agora', { cls: 'primary block', icon: 'refresh', onclick: async (e) => {
          const b = e.currentTarget;
          b.disabled = true;
          try {
            await saveSettings({ sync: { peer: peer.value.trim(), password: pass.value } });
            const r = await api.post('/api/sync/now');
            S.settings.sync.last = r;
            await loadState();
            toast('Sincronização concluída', { type: 'ok' });
            window.dispatchEvent(new CustomEvent('sintonia:source-changed'));
          } catch (err) {
            toast(err.message, { type: 'error', ms: 6000 });
          } finally { b.disabled = false; drawStatus(); }
        } }))) : null);
    drawStatus();
  };
  draw();
  subPage(root, 'Sincronizar aparelhos', content);
}

// ================================================================= sobre
const RELEASES = [
  ['2.2.6', 'Hoje', [
    'Android TV: o player não vira mais imagem no canto (miniatura). Saiu do vídeo, ele fecha e guarda onde parou, e nunca ficam dois canais abertos ao mesmo tempo',
    'Android TV e TV LG: visual igual ao do celular/tablet (menu com ícones, coluna de categorias, busca no canto, canais em lista de duas colunas, filmes e séries em grade)',
    'Navegação pelo controle melhorada: passar pela categoria já mostra os itens, → entra na lista, ← volta para a categoria escolhida e depois para o menu (que lembra onde você estava); CH+/CH− pulam uma página',
  ]],
  ['2.2.5', '', [
    'Listas que funcionam em outros apps de IPTV e ficavam em "Carregando canais…" ou davam "Sem conexão com o servidor da lista" agora carregam: quando o DNS da internet/roteador não acha o endereço do servidor, o Sintonia usa o DNS seguro da Cloudflare e do Google (como os apps de IPTV). Vale para celular, tablet, Android TV, Windows e Linux, inclusive no player',
    'Quando o servidor da lista demora e a Cloudflare responde erro 520-524, o Sintonia tenta de novo sozinho',
  ]],
  ['2.2.4', '', [
    'Android TV: listas que funcionam em outros apps de IPTV e davam "Sem conexão com o servidor da lista" agora carregam. A TV busca a lista pelo Android, como os apps de IPTV (identificação do VLC e aceita servidor com certificado https com problema)',
    'Android TV: mensagens de erro mais claras (endereço não encontrado, porta recusada, demora do servidor)',
  ]],
  ['2.2.3', '', [
    'Android TV: voltou a interface própria de TV (a de antes da 2.2.0), mais leve, com o player nativo; corrige filmes que fechavam sozinhos depois de um tempo',
    'Sobre › Atualização (e Configurações na TV): sugestão do SmartTube (estável), com botão para baixar a última versão do GitHub oficial',
  ]],
  ['2.2.2', '', [
    'Android TV: a TV ao vivo agora toca no player nativo do Android (ExoPlayer), direto do provedor: abre e troca de canal bem mais rápido. Filmes e séries continuam no player do celular',
    'Troca de canal com ▲▼ não abre cada canal do caminho: só carrega onde você parar, e solta a conexão do canal anterior na hora',
    'Ao vivo começa a mostrar a imagem sem esperar o próximo quadro-chave',
    'Navegação pelo controle mais leve e rápida em listas grandes (canais, capas, episódios); segurar a seta rola sem engasgar',
    'Na TV, os catálogos para a tela inicial do Android só carregam depois que o app assenta (o 1º canal não espera por eles)',
    'Escolha em Menu › Reprodutor › Player da TV: ao vivo no nativo (padrão), tudo no nativo ou tudo no do celular (para gravar)',
  ]],
  ['2.2.1', '', [
    'Canais e vídeos começam bem mais rápido: o ao vivo abre em cerca de 1 s (antes esperava montar 5 s de reserva e mais 2 MB de vídeo antes de mostrar a imagem)',
    'Os componentes de vídeo já ficam carregados ao abrir o app, e o 1º canal não espera por eles',
    'Mais leve: na TV e em aparelhos com pouca memória o player guarda menos vídeo na memória e os efeitos de desfoque são desligados',
    'Interface abre mais rápido: os arquivos do app ficam guardados e não são reenviados nem comprimidos a cada abertura',
    'Player nativo da TV (opcional) começa com 1 s de vídeo',
  ]],
  ['2.2.0', '', [
    'Android TV agora tem a mesma interface e as mesmas funções do celular e do tablet: downloads, gravações, multitela, guia, sincronizar, importar/exportar, personalização…',
    'Na TV tudo funciona pelo controle remoto: direcional, OK, Voltar e a tecla Menu; no player, OK mostra os controles e as setas avançam ou trocam de canal',
    'Opcional na TV: Configurações › Reprodutor › player nativo do Android (ExoPlayer), mais leve em TV box fraca',
    'Downloads e gravações: escolha a pasta navegando pelas pastas do aparelho (memória, cartão, pendrive ou disco), em Offline ou em Menu › Personalização',
    'No Android, salvar fora da pasta do app pede a permissão "Acesso a todos os arquivos"; na TV, as pastas "(pasta do app)" do pendrive funcionam sem permissão',
  ]],
  ['2.1.2', '', [
    'Android: corrigido o erro "pacote inválido" ao instalar ou atualizar a versão 2.1.1',
  ]],
  ['2.1.1', '', [
    'Sobre › Atualização: sugestão do Spectra Launcher (tela inicial para Android TV) com botão para baixar',
    'Sobre: desenvolvedor Heitor Campos (GitHub heitorcampos2)',
  ]],
  ['2.1.0', '', [
    'Gravar: um toque começa a gravar e o botão vira "Parar"; enquanto grava aparece a bolinha vermelha "Gravando" com o tempo',
    'Em tela cheia, janelas de opções e avisos aparecem por cima do vídeo (antes ficavam escondidas atrás)',
  ]],
  ['2.0.9', '', [
    'Downloads: o filme ou episódio é baixado inteiro (antes podia parar no meio e aparecer como concluído)',
    'Sem internet ou com o provedor cortando a conexão, o download espera e continua de onde parou, sem perder a %',
    'Se o Sintonia for fechado no meio de um download, ele continua sozinho ao abrir de novo',
    'Um download por vez, para não disputar a conexão do provedor com o vídeo',
  ]],
  ['2.0.8', '', [
    'Celular em pé: as temporadas da série aparecem numa lista suspensa (antes os nomes ficavam espremidos)',
  ]],
  ['2.0.7', '', [
    'Sincronização fácil: o Sintonia encontra sozinho os outros aparelhos no mesmo Wi-Fi (opcional, perguntado na primeira abertura)',
    'Parear por QR: mostre o QR deste aparelho e leia no celular, sem digitar IP',
    'Importar e exportar listas: arquivo, texto, link ou QR (o celular lê com a câmera)',
    'Player: botões anterior e próximo para canal, episódio e filme da mesma categoria',
    'Título personalizado com logomarca (PNG) na barra lateral, em Menu › Tema e cores',
    'TV (Android TV e LG): busca o Sintonia do PC na rede, mostra a lista em QR e tem anterior/próximo no player',
  ]],
  ['2.0.6', '', [
    'Android: Imagem no canto (PiP). Toque no botão do player ou aperte Início com o vídeo tocando',
    'Na janelinha dá para pausar e continuar; fechando ela, o vídeo para e guarda onde parou',
    'Android TV: barra de pesquisa só ativa o teclado quando você aperta OK nela, com × para limpar',
  ]],
  ['2.0.5', '', [
    'Nova cor de destaque: Vermelho (e as bolinhas de cor voltaram a aparecer)',
    'Padrão: estabilidade Máximo e vídeo sem passar pelo servidor; aplicado uma vez também em quem já usava',
    'Outros aparelhos da rede só usam este Sintonia se você marcar a caixa em Menu › Instalar e outros aparelhos',
    'Android TV: canais na tela inicial (Projectivy, Xiaomi, Google TV): Continuar assistindo, Canais favoritos e Sugestões',
  ]],
  ['2.0.4', '', [
    'TV (Android TV e LG): barra de pesquisa no topo de TV ao Vivo, Filmes e Séries, filtrando enquanto digita',
  ]],
  ['2.0.3', '', [
    'Reconexão discreta: no lugar dos avisos de texto, só um pontinho vermelho no canto enquanto o vídeo se reconecta',
    'TV (LG e Android TV): barra de controles completa como no celular: voltar/avançar 10 s, play/pause, áudio, legenda e favoritar canal',
  ]],
  ['2.0.2', '', [
    'Android TV/TV box: vídeo no player nativo (ExoPlayer), como o SmartTube: ao vivo sem a travadinha do vídeo',
    'Novas opções na TV: Modo túnel e Ajustar taxa de quadros (AFR)',
    'Categorias numa coluna própria ao lado do menu (como na versão da TV); no celular abrem como painel',
  ]],
  ['2.0.1', '', [
    'Botão × nos canais assistidos recentemente (na TV ao vivo e dentro do player) para tirar do histórico',
    'App Android instala também em TV e TV box (Android 7 em diante), com tela própria para controle remoto',
  ]],
  ['2.0.0', '', [
    'Versão 2.0: reúne todas as melhorias da 1.0.6',
    'Botão × nos quadrinhos de Continuar assistindo para tirar um vídeo da lista',
  ]],
  ['1.0.6', '', [
    'Filmes e séries sem travar: o servidor baixa à frente do ponto assistido na velocidade máxima, usando uma só conexão (contas com limite de 1 conexão)',
    'Continuar de onde parou e pular no vídeo agora também ficam com reserva',
    'Se a internet cair, o vídeo segue com a reserva e o download continua do mesmo ponto quando ela volta; se travar, o player reabre sozinho no mesmo segundo',
    'Capas carregam mais rápido (miniaturas) e sites de capa fora do ar não deixam a tela esperando',
    'Página de detalhes com etiquetas de nota, ano e gênero, sinopse com "Ler mais" e resumo de cada temporada',
  ]],
  ['1.0.5', '', [
    'TV ao vivo corrigida: os canais em MPEG-TS voltaram a tocar no navegador',
    'Link da playlist (get.php) colado no Xtream preenche servidor, usuário e senha sozinho',
    'Painel Xtream que só responde em http ou https é encontrado automaticamente',
    'Os 4 últimos vídeos vistos aparecem no topo de Filmes e Séries',
    'Nova seção Sobre, com as notas de cada versão',
  ]],
  ['1.0.4', '', [
    'Playlist de painel Xtream passa a ser lida como Xtream (guia de programação, replay e TS/HLS)',
    'Aviso claro para canais H.265 que o navegador não reproduz',
  ]],
  ['1.0.3', '', [
    'Versão para Windows com instalador e atalho que abre em janela própria',
    'Pode ser instalado como app pelo Chrome ou Edge',
    'Sincronização opcional entre aparelhos (desligada por padrão)',
    'Botão "Diagnosticar canal" para descobrir por que um canal não abre',
  ]],
  ['1.0.2', '', [
    'Ao vivo tenta vários caminhos sozinho (reserva, User-Agent VLC e navegador, TS e HLS)',
    'Botão "Continuar" com painel flutuante e cartões compactos',
  ]],
  ['1.0.1', '', [
    'Séries divididas por temporada viram uma série só, com abas de temporada',
    'Ponto exato salvo em todos os vídeos, com opção de continuar ou começar do início',
  ]],
  ['1.0.0', '', [
    'Primeira versão: TV ao vivo com guia e replay, filmes, séries, multitela, downloads, gravações e controle parental',
    'Modos de estabilidade até o Ultra extremo, que guarda o filme inteiro e segue tocando sem internet',
  ]],
];

function aboutPage(root) {
  const keys = [['Espaço ou K', 'Pausar e continuar'], ['F', 'Tela cheia'], ['M', 'Sem som'], ['↑ ↓', 'Trocar de canal (ao vivo) ou volume'],
    ['← →', 'Voltar e avançar'], ['Esc', 'Fechar o player'], ['/', 'Ir para a pesquisa']];
  const notes = RELEASES.map(([ver, when, items], i) => h('details.release', { open: i === 0 || null },
    h('summary', h('strong', `Versão ${ver}`), ver === S.version ? h('span.pill.ok.sm', h('i'), 'instalada') : null, when ? h('small', when) : null),
    h('ul', ...items.map((t) => h('li', t)))));
  subPage(root, 'Sobre',
    h('section.about-card',
      h('div.brand.big', h('span.brand-mark', ic('signal')), h('span', 'Sintonia')),
      h('p.about-ver', `Versão ${S.version}`),
      h('p.about-author', 'Desenvolvido por ', h('strong', 'Heitor Campos'), ' · ', h('a', { href: 'https://github.com/heitorcampos2', target: '_blank', rel: 'noopener' }, 'github.com/heitorcampos2')),
      h('p.muted', 'Player de IPTV que roda no seu aparelho e abre em qualquer navegador. O Sintonia não fornece canais nem conteúdo: ele só reproduz as listas que você adiciona.')),
    group('Atualização', actionRow('Procurar atualização no GitHub', () => updateModal(), { icon: 'refresh', sub: 'Quando sair versão nova, aparece 🔁 no canto superior direito' }),
      actionRow('Sugestão: Spectra Launcher', () => spectraModal(), { icon: 'tv', sub: 'Tela inicial para Android TV, do mesmo criador do Sintonia' }),
      actionRow('Sugestão: SmartTube (estável)', () => smartTubeModal(), { icon: 'play', sub: 'YouTube para Android TV sem anúncios · última versão do GitHub oficial' })),
    group('Notas da versão', h('div.release-list', ...notes)),
    group('Atalhos do teclado', ...keys.map(([k, d]) => row(d, null, h('kbd', k)))),
    group('Informações técnicas',
      row('Aparelho', S.device || '', null),
      row('Pasta de dados', S.dataDir || '', null),
      row('Downloads', S.settings.downloadDir || S.mediaDir || '', null),
      row('Gravações', S.settings.recordDir || (S.mediaDir ? S.mediaDir + '/Gravações' : ''), null)));
}

