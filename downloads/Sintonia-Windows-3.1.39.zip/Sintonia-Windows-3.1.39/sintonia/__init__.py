"""Sintonia — player IPTV que roda como servidor e abre em qualquer navegador."""

VERSION = "3.1.39"
