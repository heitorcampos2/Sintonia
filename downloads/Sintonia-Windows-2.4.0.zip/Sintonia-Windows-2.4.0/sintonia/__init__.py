"""Sintonia — player IPTV que roda como servidor e abre em qualquer navegador."""

VERSION = "2.4.0"
