"""Reserva de vídeo no servidor (modos Máximo e Ultra extremo).

- VodCache: baixa filmes/episódios inteiros o mais rápido possível para um arquivo local.
  O player lê desse arquivo; se a internet cair, toca o que já foi baixado e o download
  continua do mesmo byte quando a conexão volta.
- LiveRelay: mantém uma conexão com o canal ao vivo, guarda uma reserva em memória e
  reconecta sozinho ao provedor sem derrubar o player.
"""

import hashlib
import os
import select
import shutil
import socket
import threading
import time
import urllib.error
from collections import deque
from pathlib import Path

from . import net

CHUNK = 256 * 1024


def _key(url):
    return hashlib.sha1(url.encode("utf-8")).hexdigest()[:16]


# ======================================================================================
# Filmes e episódios
# ======================================================================================

BLOCK = 8 * 1024 * 1024          # o arquivo é guardado em blocos de 8 MB (busca rápida, sem preencher zeros)
JUMP_SLACK = 6 * 1024 * 1024     # leitor até 6 MB à frente do download: espera em vez de reconectar
MIN_RUN = 3 * 1024 * 1024        # depois de pular, baixa ao menos isto antes de pular de novo


class _Ranges:
    """Intervalos [a, b) já baixados, sempre ordenados e unidos."""

    def __init__(self):
        self.iv = []

    def add(self, a, b):
        if b <= a:
            return
        out, placed = [], False
        for x, y in self.iv:
            if y < a:
                out.append([x, y])
            elif b < x:
                if not placed:
                    out.append([a, b])
                    placed = True
                out.append([x, y])
            else:
                a, b = min(a, x), max(b, y)
        if not placed:
            out.append([a, b])
        out.sort()
        self.iv = out

    def end_at(self, pos):
        """Até onde vai o trecho contínuo que contém `pos` (ou `pos` se não estiver baixado)."""
        for x, y in self.iv:
            if x <= pos < y:
                return y
            if x > pos:
                break
        return pos

    def gap(self, pos, total):
        """Primeiro byte >= pos ainda não baixado (None se até o fim já está tudo)."""
        p = self.end_at(pos)
        if total and p >= total:
            return None
        return p

    def size(self):
        return sum(y - x for x, y in self.iv)


class VodJob:
    """Reserva de um filme/episódio: baixa à frente do ponto que está sendo assistido.

    Uma única conexão com o provedor (muitos só permitem uma por conta). Se o player pular
    para outro ponto, o download vai junto. Se a internet cair, reconecta sem parar e continua
    do mesmo byte; o player espera com a conexão aberta e volta a tocar sozinho.
    """

    def __init__(self, url, ua, folder, ahead):
        self.id = _key(url)
        self.url = url
        self.ua = ua
        self.dir = Path(folder) / self.id
        self.ahead = ahead            # None = baixa o arquivo inteiro
        self.total = 0
        self.ranges = _Ranges()
        self.head = 0                 # posição atual do download
        self.focus = 0                # posição do leitor mais recente
        self.seekable = True
        self.ctype = "video/mp4"
        self.state = "starting"       # starting | downloading | idle | retrying | complete | failed | stopped
        self.error = ""
        self.retries = 0
        self.speed = 0.0
        self.last_access = time.time()
        self.cond = threading.Condition()
        self.stop_ev = threading.Event()
        self.ready = threading.Event()
        self._readers = {}            # id -> {"pos", "blocked", "t"}
        self._rid = 0
        self._want = None             # posição que um leitor parado está esperando
        self._fh = {}
        threading.Thread(target=self._run, daemon=True).start()

    # ---------------------------------------------------------------- blocos no disco
    def _block(self, n, write=False):
        f = self._fh.get((n, write))
        if f is None:
            path = self.dir / f"{n}.blk"
            if write:
                f = open(path, "r+b" if path.exists() else "w+b")
            else:
                f = open(path, "rb")
            self._fh[(n, write)] = f
        return f

    def _write(self, pos, data):
        while data:
            n, off = divmod(pos, BLOCK)
            k = min(len(data), BLOCK - off)
            f = self._block(n, True)
            f.seek(off)
            f.write(data[:k])
            f.flush()
            pos += k
            data = data[k:]

    def read(self, pos, size):
        """Lê bytes já baixados (abre arquivos próprios: chamado pelas threads dos leitores)."""
        out = b""
        while size > 0:
            n, off = divmod(pos, BLOCK)
            k = min(size, BLOCK - off)
            try:
                with open(self.dir / f"{n}.blk", "rb") as f:
                    f.seek(off)
                    part = f.read(k)
            except OSError:
                break
            if not part:
                break
            out += part
            pos += len(part)
            size -= len(part)
            if len(part) < k:
                break
        return out

    def _close_files(self):
        for f in self._fh.values():
            try:
                f.close()
            except OSError:
                pass
        self._fh.clear()

    # ---------------------------------------------------------------- leitores
    def reader_open(self, pos):
        with self.cond:
            self._rid += 1
            self._readers[self._rid] = {"pos": pos, "blocked": False, "t": time.time()}
            self.focus = pos
            self.last_access = time.time()
            self.cond.notify_all()
            return self._rid

    def reader_move(self, rid, pos, blocked):
        with self.cond:
            r = self._readers.get(rid)
            if not r:
                return
            if blocked and not r["blocked"]:
                r["since"] = time.time()
            r["pos"], r["blocked"] = pos, blocked
            self.last_access = time.time()
            # o leitor mais recente manda no ponto de interesse
            if rid == max(self._readers):
                self.focus = pos
            self._want = self._newest_blocked()
            if blocked:
                self.cond.notify_all()

    def _newest_blocked(self):
        """O pedido parado mais recente é o que o player está esperando agora
        (o Chrome deixa conexões antigas abertas e paradas)."""
        for k in sorted(self._readers, reverse=True):
            if self._readers[k]["blocked"]:
                return self._readers[k]["pos"]
        return None

    def is_stale(self, rid):
        """Pedido parado há muito tempo e já superado por outro mais novo."""
        with self.cond:
            r = self._readers.get(rid)
            return bool(r and r["blocked"] and rid != max(self._readers)
                        and time.time() - r.get("since", time.time()) > 20)

    def reader_close(self, rid):
        with self.cond:
            self._readers.pop(rid, None)
            if self._readers:
                self.focus = self._readers[max(self._readers)]["pos"]
            self._want = self._newest_blocked()
            self.cond.notify_all()

    def available(self, pos):
        with self.cond:
            return self.ranges.end_at(pos) - pos

    def wait_for(self, rid, pos, timeout):
        """Espera o byte `pos` ser baixado. Devolve quantos bytes há a partir dele (0 se nada)."""
        deadline = time.time() + timeout
        with self.cond:
            while True:
                n = self.ranges.end_at(pos) - pos
                if n > 0 or self.state in ("failed", "stopped") or (self.total and pos >= self.total):
                    return n
                if self.state == "complete" and not self.ranges.gap(pos, self.total):
                    return n
                left = deadline - time.time()
                if left <= 0:
                    return 0
                self.cond.wait(min(left, 1.0))

    # ---------------------------------------------------------------- download
    def _pick(self):
        """De onde baixar agora (None = nada a fazer por enquanto)."""
        with self.cond:
            if self._want is not None:
                g = self.ranges.gap(self._want, self.total)
                if g is not None:
                    return g
                self._want = None
            if not self.seekable:
                g = self.ranges.gap(0, self.total)
                return g
            g = self.ranges.gap(self.focus, self.total)
            if g is not None and (self.ahead is None or g - self.focus < self.ahead):
                return g
            if self.ahead is None:
                return self.ranges.gap(0, self.total)
            return None

    def _headers(self, start=0):
        h = {"User-Agent": self.ua} if self.ua else {}
        if start or not self.total:
            h["Range"] = f"bytes={start}-"
        return h

    def _run(self):
        backoff = 1
        self.dir.mkdir(parents=True, exist_ok=True)
        try:
            while not self.stop_ev.is_set():
                start = self._pick()
                if start is None:
                    if self.total and not self.ranges.gap(0, self.total):
                        self.state = "complete"
                        with self.cond:
                            self.cond.notify_all()
                        return
                    self.state = "idle" if self.state != "retrying" else self.state
                    if self.state == "idle":
                        with self.cond:
                            self.cond.wait(1.0)
                    continue
                try:
                    resp = net.open_url(self.url, headers=self._headers(start), timeout=20)
                except urllib.error.HTTPError as exc:
                    if exc.code in (401, 403, 404, 410) and not self.ranges.size():
                        self._fail(f"O provedor respondeu {exc.code}")
                        return
                    if exc.code == 416 and self.total:
                        # pediu além do fim: marca como baixado para não insistir
                        with self.cond:
                            self.ranges.add(start, self.total)
                            self.cond.notify_all()
                        continue
                    self._retry(str(exc))
                    if exc.code in (429, 458, 503, 509):
                        # limite de conexões: a anterior ainda está sendo liberada pelo provedor
                        self.stop_ev.wait(0.8)
                        if self.retries >= 7 and not self.ranges.size():
                            self._fail(f"O provedor não está entregando este vídeo agora (erro {exc.code})")
                            return
                        continue
                    backoff = self._sleep(backoff)
                    continue
                except Exception as exc:  # noqa: BLE001  sem internet, DNS, timeout…
                    if not self.ranges.size() and self.retries >= 4:
                        self._fail(f"Sem resposta do provedor: {exc}")
                        return
                    self._retry(str(exc))
                    backoff = self._sleep(backoff)
                    continue
                with resp:
                    status = getattr(resp, "status", 200)
                    cl = int(resp.headers.get("Content-Length") or 0)
                    cr = resp.headers.get("Content-Range") or ""
                    if not self.total:
                        tail = cr.rsplit("/", 1)[-1] if "/" in cr else ""
                        self.total = int(tail) if tail.isdigit() else (cl if status == 200 else 0)
                        ct = resp.headers.get("Content-Type", "")
                        if ct.startswith("video/") or ct.startswith("audio/"):
                            self.ctype = ct
                        elif self.url.lower().split("?")[0].endswith(".mkv"):
                            self.ctype = "video/webm"
                        if self.total and not _fits(self.dir, self.total) and self.ahead is None:
                            self.ahead = 256 * 1024 * 1024   # pouco espaço: guarda só um trecho à frente
                    if start and status != 206:
                        # o provedor não aceita pular: baixa em sequência desde o começo
                        self.seekable = False
                        start = 0
                    pos = start
                    self.head = pos
                    self.state = "downloading"
                    self.ready.set()
                    backoff = 1
                    t0, b0, run0 = time.time(), pos, pos
                    while not self.stop_ev.is_set():
                        try:
                            chunk = resp.read(CHUNK)
                        except (socket.timeout, OSError) as exc:
                            self._retry(f"Conexão interrompida: {exc}")
                            break
                        if not chunk:
                            if not self.total:
                                self.total = pos
                            break
                        if self.total:
                            chunk = chunk[: max(0, self.total - pos)]
                        self._write(pos, chunk)
                        with self.cond:
                            self.ranges.add(pos, pos + len(chunk))
                            pos += len(chunk)
                            self.head = pos
                            self.cond.notify_all()
                            want, focus = self._want, self.focus
                            nxt = self.ranges.end_at(pos)
                            # alguém está esperando justamente este trecho?
                            needed = want is not None and run0 <= want <= pos + JUMP_SLACK
                        dt = time.time() - t0
                        if dt > 2:
                            self.speed = (pos - b0) / dt
                            t0, b0 = time.time(), pos
                        if self.total and pos >= self.total:
                            break
                        if not self.seekable:
                            continue
                        # depois de pular, insiste um pouco no trecho (evita ficar indo e voltando),
                        # a não ser que ninguém esteja esperando por ele
                        moved = pos - run0 >= MIN_RUN or not needed
                        # um leitor está parado esperando outro ponto do arquivo: vai até ele
                        if want is not None and not (pos <= want <= pos + JUMP_SLACK) and moved:
                            break
                        # chegou num trecho que já estava baixado: pula para o próximo buraco
                        if nxt > pos:
                            break
                        # já tem reserva suficiente à frente de quem está assistindo
                        if self.ahead is not None and pos - focus >= self.ahead and want is None:
                            break
                        # quem assiste pulou para trás do download ou muito à frente
                        if moved and (focus < run0 - BLOCK or focus > pos + 2 * JUMP_SLACK) \
                                and self.ranges.end_at(focus) - focus < 2 * BLOCK:
                            break
                    if self.state == "retrying":
                        backoff = self._sleep(backoff)
        finally:
            self._close_files()
            with self.cond:
                self.cond.notify_all()

    def _retry(self, msg):
        if self.state != "retrying":
            self._retry_since = time.time()
        self.state = "retrying"
        self.error = msg
        self.retries += 1
        if self.ranges.size():
            self.ready.set()

    def _fail(self, msg):
        self.state = "failed"
        self.error = msg
        self.ready.set()
        with self.cond:
            self.cond.notify_all()

    def _sleep(self, backoff):
        self.stop_ev.wait(backoff)
        return min(backoff * 2, 5)

    def stop(self, delete=True):
        self.stop_ev.set()
        self.state = "stopped" if self.state != "complete" else self.state
        with self.cond:
            self.cond.notify_all()
        if delete:
            threading.Timer(3, self._remove).start()

    def _remove(self, tries=5):
        try:
            shutil.rmtree(self.dir)
        except OSError:  # no Windows o arquivo pode estar aberto por um leitor
            if tries:
                threading.Timer(5, self._remove, args=(tries - 1,)).start()

    def status(self):
        with self.cond:
            done = self.ranges.end_at(self.focus) if self.ranges.end_at(self.focus) > self.focus else self.focus
            saved = self.ranges.size()
        state = "downloading" if self.state == "idle" else self.state
        if state == "retrying" and time.time() - getattr(self, "_retry_since", 0) < 3:
            state = "downloading"  # reconexão rápida (troca de ponto, limite de conexão): não alarma
        return {"id": self.id, "kind": "vod", "state": state,
                "done": done, "saved": saved, "focus": self.focus, "total": self.total,
                "speed": round(self.speed), "error": self.error if self.state in ("retrying", "failed") else "",
                "ranges": [[a, b] for a, b in self.ranges.iv[:64]], "head": self.head,
                "readers": [[r["pos"], r["blocked"]] for r in list(self._readers.values())[:8]],
                "retries": self.retries}


def _fits(folder, size):
    try:
        return shutil.disk_usage(folder).free - size > 400 * 1024 * 1024
    except OSError:
        return True


def _client_gone(handler):
    """O navegador fechou a conexão? (abortou o pedido ao pular no vídeo)"""
    try:
        sock = handler.connection
        r, _, _ = select.select([sock], [], [], 0)
        if r:
            return sock.recv(1, socket.MSG_PEEK) == b""
    except (OSError, ValueError):
        return True
    return False


class VodCache:
    def __init__(self, folder):
        self.dir = Path(folder)
        self.dir.mkdir(parents=True, exist_ok=True)
        for f in list(self.dir.iterdir()):
            try:
                shutil.rmtree(f) if f.is_dir() else f.unlink(missing_ok=True)
            except OSError:
                pass
        self.jobs = {}
        self.lock = threading.Lock()
        threading.Thread(target=self._janitor, daemon=True).start()

    def start(self, url, ua, ahead=None):
        jid = _key(url)
        with self.lock:
            job = self.jobs.get(jid)
            if job and job.state not in ("failed", "stopped"):
                job.last_access = time.time()
                if ahead is None or (job.ahead is not None and ahead > job.ahead):
                    job.ahead = ahead
                return job
            # um vídeo por vez: libera o disco e a conexão do provedor para o próximo
            for other in list(self.jobs.values()):
                other.stop()
            self.jobs.clear()
            job = VodJob(url, ua, self.dir, ahead)
            self.jobs[jid] = job
            return job

    def get(self, jid):
        return self.jobs.get(jid)

    def stop_all(self):
        with self.lock:
            for job in self.jobs.values():
                job.stop()
            self.jobs.clear()

    def _janitor(self):
        while True:
            time.sleep(60)
            with self.lock:
                for jid, job in list(self.jobs.items()):
                    if time.time() - job.last_access > 30 * 60:
                        job.stop()
                        self.jobs.pop(jid, None)

    def serve(self, handler, jid):
        job = self.get(jid)
        if not job:
            handler.send_error(404, "Reserva não encontrada")
            return
        job.last_access = time.time()
        rng = handler.headers.get("Range")
        a = b = ""
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-")
            a, b = a.strip(), b.strip()
        start = int(a) if a.isdigit() else 0
        rid = job.reader_open(start)
        try:
            job.ready.wait(45)
            if job.state == "failed" and not job.ranges.size():
                body = job.error.encode("utf-8")
                handler.send_response(502)
                handler.send_header("Content-Type", "text/plain; charset=utf-8")
                handler.send_header("Content-Length", str(len(body)))
                handler.end_headers()
                handler.wfile.write(body)
                return
            total = job.total
            end = total - 1 if total else None
            if not a and b.isdigit() and total:
                start = max(0, total - int(b))
            elif b.isdigit():
                end = min(int(b), total - 1) if total else int(b)
            job.reader_move(rid, start, False)
            if total and start >= total:
                handler.send_response(416)
                handler.send_header("Content-Range", f"bytes */{total}")
                handler.send_header("Content-Length", "0")
                handler.end_headers()
                return
            if total:
                handler.send_response(206 if rng else 200)
                if rng:
                    handler.send_header("Content-Range", f"bytes {start}-{end}/{total}")
                handler.send_header("Content-Length", str(end - start + 1))
            else:
                handler.send_response(200)
                handler.send_header("Connection", "close")
                handler.close_connection = True
            handler.send_header("Content-Type", job.ctype)
            handler.send_header("Accept-Ranges", "bytes")
            handler.send_header("Cache-Control", "no-store")
            handler.end_headers()
            pos = start
            last = end if end is not None else float("inf")
            while pos <= last:
                n = job.available(pos)
                if n <= 0:
                    if job.state in ("failed", "stopped") or (job.total and pos >= job.total):
                        break
                    if job.state == "complete" and job.total and pos >= job.total:
                        break
                    # ainda não chegou (internet caiu ou o download está indo para cá):
                    # espera com a conexão aberta; o vídeo continua assim que os dados chegarem
                    job.reader_move(rid, pos, True)
                    n = job.wait_for(rid, pos, 2.0)
                    if n <= 0:
                        if _client_gone(handler) or job.is_stale(rid):
                            break
                        continue
                    job.reader_move(rid, pos, False)
                k = int(min(CHUNK, n, last - pos + 1))
                data = job.read(pos, k)
                if not data:
                    time.sleep(0.2)
                    continue
                handler.wfile.write(data)
                pos += len(data)
                job.reader_move(rid, pos, False)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            handler.close_connection = True
        finally:
            job.reader_close(rid)


# ======================================================================================
# TV ao vivo
# ======================================================================================

def _open_racing(url, headers, timeout, reserve_after=2.5):
    """Abre a URL; se não houver resposta em reserve_after s, dispara um 2º pedido igual e usa o primeiro
    que responder (o outro é fechado). Erros HTTP do 1º pedido valem na hora."""
    import queue
    q = queue.Queue()
    lock = threading.Lock()
    state = {"winner": None}

    def job():
        try:
            r = net.open_url(url, headers=headers, timeout=timeout)
        except Exception as exc:  # noqa: BLE001
            q.put(("err", exc))
            return
        with lock:
            if state["winner"] is None:
                state["winner"] = r
                q.put(("ok", r))
                return
        try:
            r.close()   # chegou depois: libera a conexão (a conta pode ter limite)
        except Exception:  # noqa: BLE001
            pass

    threading.Thread(target=job, daemon=True).start()
    sent, errors, first_err = 1, 0, None
    deadline = time.time() + timeout + reserve_after + 1
    while time.time() < deadline:
        wait = reserve_after if sent == 1 else max(0.05, deadline - time.time())
        try:
            kind, val = q.get(timeout=wait)
        except queue.Empty:
            if sent == 1:
                threading.Thread(target=job, daemon=True).start()
                sent = 2
            continue
        if kind == "ok":
            return val
        errors += 1
        first_err = first_err or val
        if isinstance(val, urllib.error.HTTPError) and val.code not in (502, 503, 504, 520, 521, 522, 523, 524):
            with lock:
                state["winner"] = state["winner"] or False
            raise val
        if errors >= sent:
            if sent == 1:   # falhou rápido: tenta o reserva já
                threading.Thread(target=job, daemon=True).start()
                sent = 2
                continue
            with lock:
                state["winner"] = state["winner"] or False
            raise first_err
    with lock:
        state["winner"] = state["winner"] or False
    raise socket.timeout("sem resposta do canal")


FAST_START = 0.4            # 2.3.2: segundos no máximo antes do primeiro byte para o player (antes 1 s)
FAST_BYTES = 192 * 1024     # ou assim que chegar este tanto (a rajada inicial do provedor)


class Relay:
    def __init__(self, url, ua, cushion, mem_mb):
        self.id = _key(url + "|" + (ua or ""))
        self.url = url
        self.ua = ua
        self.cushion = cushion
        self.cap = mem_mb * 1024 * 1024
        self.chunks = deque()          # (offset, bytes)
        self.base = 0                  # primeiro offset ainda em memória
        self.end = 0                   # próximo offset
        self.started = time.time()
        self.clients = 0
        self.idle_since = time.time()
        self.state = "connecting"
        self.error = ""
        self.reconnects = 0
        self.last_data = 0
        self.seg_starts = [0]          # offset onde começa cada conexão com o provedor
        self.cond = threading.Condition()
        self.stop_ev = threading.Event()
        threading.Thread(target=self._run, daemon=True).start()

    def _trim_partial(self):
        """Remove o pacote TS incompleto do fim antes de emendar uma nova conexão."""
        with self.cond:
            extra = (self.end - self.seg_starts[-1]) % 188
            while extra and self.chunks:
                off, data = self.chunks[-1]
                if len(data) <= extra:
                    self.chunks.pop()
                    extra -= len(data)
                    self.end -= len(data)
                else:
                    self.chunks[-1] = (off, data[:-extra])
                    self.end -= extra
                    extra = 0
            if self.seg_starts[-1] != self.end:
                self.seg_starts.append(self.end)
                self.seg_starts = self.seg_starts[-50:]

    def align(self, pos):
        start = 0
        for s in self.seg_starts:
            if s <= pos:
                start = s
        return start + ((pos - start) // 188) * 188

    def _run(self):
        backoff = 0.5
        while not self.stop_ev.is_set():
            # antes do primeiro dado, falha rápido para o player tentar outro caminho
            first = self.end == 0
            try:
                hdr = {"User-Agent": self.ua} if self.ua else None
                # 2.4.0: o servidor da lista às vezes trava ~20 s; no primeiro pedido, um pedido reserva sai
                # depois de 2,5 s sem resposta e fica o que responder primeiro (como na TV Android)
                resp = _open_racing(self.url, hdr, 10) if first else net.open_url(self.url, headers=hdr, timeout=20)
            except urllib.error.HTTPError as exc:
                if exc.code in (406, 409) and time.time() - self.started < 8:
                    # 2.4.0: 409 = a vaga da conexão anterior ainda não foi liberada pelo servidor (leva alguns
                    # segundos); 406 = o endereço de acesso venceu. Pede de novo logo, sem contar como falha.
                    self.error = f"O provedor respondeu {exc.code} (aguardando liberar a conexão)"
                    self.state = "retrying"
                    self.stop_ev.wait(0.4)
                    continue
                self._attempt_failed(f"O provedor respondeu {exc.code} ({exc.reason})", fatal=first and exc.code in (401, 403, 404, 405, 458))
                if self.state == "failed":
                    return
                self.stop_ev.wait(backoff)
                backoff = min(backoff * 2, 5)
                continue
            except Exception as exc:  # noqa: BLE001
                self._attempt_failed(f"Sem resposta do canal: {exc}")
                if self.state == "failed":
                    return
                self.stop_ev.wait(backoff)
                backoff = min(backoff * 2, 5)
                continue
            ctype = (resp.headers.get("Content-Type") or "").lower()
            if first and any(t in ctype for t in ("text/html", "json", "text/plain")):
                snippet = resp.read(300).decode("utf-8", "replace").strip().replace("\n", " ")
                resp.close()
                self._attempt_failed(f"O provedor devolveu uma página em vez de vídeo: {snippet[:160]}", fatal=True)
                return
            if first and ("mpegurl" in ctype or resp.geturl().split("?")[0].endswith(".m3u8")):
                resp.close()
                self._attempt_failed("Este canal é HLS; o player vai abrir sem a reserva", fatal=True)
                return
            self.state = "live"
            got = 0
            with resp:
                while not self.stop_ev.is_set():
                    try:
                        data = resp.read1(64 * 1024)   # 2.4.0: entrega o que já chegou (antes esperava juntar 64 KB)
                    except (socket.timeout, OSError) as exc:
                        self.error = str(exc)
                        break
                    if not data:
                        break
                    got += len(data)
                    with self.cond:
                        self.chunks.append((self.end, data))
                        self.end += len(data)
                        self.last_data = time.time()
                        while self.end - self.base > self.cap and len(self.chunks) > 1:
                            off, old = self.chunks.popleft()
                            self.base = off + len(old)
                        self.cond.notify_all()
            if got:
                backoff = 0.5
            elif not self.stop_ev.is_set():
                self._attempt_failed(self.error or "O canal fechou a conexão sem enviar vídeo")
                if self.state == "failed":
                    return
            if not self.stop_ev.is_set():
                self.state = "retrying"
                self.reconnects += 1
                self._trim_partial()
                self.stop_ev.wait(backoff)

    def _attempt_failed(self, msg, fatal=False):
        self.error = msg
        self.reconnects += 1
        self.state = "retrying"
        if self.end == 0 and (fatal or self.reconnects >= 3):
            self.state = "failed"
            with self.cond:
                self.cond.notify_all()

    def stop(self):
        self.stop_ev.set()
        self.state = "stopped"
        with self.cond:
            self.cond.notify_all()

    def status(self):
        return {"id": self.id, "kind": "live", "state": self.state, "buffered": self.end - self.base,
                "reconnects": self.reconnects, "error": self.error, "clients": self.clients,
                "silent": round(time.time() - self.last_data, 1) if self.last_data else None}

    def read_from(self, pos, timeout=1.0):
        with self.cond:
            if pos < self.base:
                pos = self.base
            if pos >= self.end:
                self.cond.wait(timeout)
                if pos >= self.end:
                    return pos, b""
            out = []
            size = 0
            for off, data in self.chunks:
                if off + len(data) <= pos:
                    continue
                piece = data[pos - off:] if off < pos else data
                out.append(piece)
                size += len(piece)
                if size >= CHUNK:
                    break
            buf = b"".join(out)
            return pos + len(buf), buf


class LiveRelays:
    def __init__(self):
        self.relays = {}
        self.lock = threading.Lock()
        threading.Thread(target=self._janitor, daemon=True).start()

    def start(self, url, ua, cushion, mem_mb):
        rid = _key(url + "|" + (ua or ""))
        with self.lock:
            r = self.relays.get(rid)
            if r and r.state not in ("failed", "stopped"):
                return r
            # libera conexões paradas (muitos provedores limitam a 1 conexão)
            for other_id, other in list(self.relays.items()):
                if other.clients == 0:
                    other.stop()
                    self.relays.pop(other_id, None)
            r = Relay(url, ua, cushion, mem_mb)
            self.relays[rid] = r
            return r

    def get(self, rid):
        return self.relays.get(rid)

    def stop_all(self):
        with self.lock:
            for r in self.relays.values():
                r.stop()
            self.relays.clear()

    def stop_idle(self):
        """Fecha relés sem ninguém assistindo (libera a conexão do provedor para o próximo canal)."""
        with self.lock:
            for rid, r in list(self.relays.items()):
                if r.clients == 0:
                    r.stop()
                    self.relays.pop(rid, None)

    def _janitor(self):
        while True:
            time.sleep(2)
            with self.lock:
                for rid, r in list(self.relays.items()):
                    if r.clients == 0 and time.time() - r.idle_since > 4:
                        r.stop()
                        self.relays.pop(rid, None)

    def serve(self, handler, rid):
        r = self.get(rid)
        if not r:
            handler.send_error(404, "Canal não encontrado")
            return
        r.clients += 1
        try:
            # espera só o primeiro pedaço do vídeo: começa a tocar em ~1 s (antes esperava a reserva inteira);
            # a reserva continua sendo usada para reconectar sem cortar
            t_first = time.time() + 10
            while r.end == 0 and r.state not in ("failed", "stopped") and time.time() < t_first:
                time.sleep(0.05)
            t_end = r.started + min(r.cushion, FAST_START)
            while time.time() < t_end and r.end < FAST_BYTES and r.state not in ("failed", "stopped"):
                time.sleep(0.05)
            if r.state == "failed" or r.end == 0:
                body = (r.error or "Canal indisponível").encode("utf-8")
                handler.send_response(502)
                handler.send_header("Content-Type", "text/plain; charset=utf-8")
                handler.send_header("Content-Length", str(len(body)))
                handler.end_headers()
                handler.wfile.write(body)
                return
            handler.send_response(200)
            handler.send_header("Content-Type", "video/mp2t")
            handler.send_header("Cache-Control", "no-store")
            handler.send_header("Connection", "close")
            handler.close_connection = True
            handler.end_headers()
            pos = r.base
            age = time.time() - r.started
            if age > r.cushion + 3 and r.end:
                rate = r.end / max(1.0, age)
                pos = r.align(max(r.base, r.end - int(rate * (r.cushion + 1))))
            while r.state != "stopped":
                pos, data = r.read_from(pos)
                if data:
                    handler.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        finally:
            r.clients -= 1
            if r.clients <= 0:
                r.clients = 0
                r.idle_since = time.time()
