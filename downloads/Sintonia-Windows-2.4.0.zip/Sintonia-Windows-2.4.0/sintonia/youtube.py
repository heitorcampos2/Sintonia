"""Canais YouTube (2.3.9) — busca de canais e transmissão ao vivo, do jeito do SmartTube.

Busca pelo cliente Web da API interna do YouTube, a página /live do canal diz se ele está ao vivo
(o endereço canônico vira o do vídeo) e o cliente Android entrega o link HLS do vídeo ao vivo.
"""

import json
import re
import threading
import time

from . import net, proxy

WEB = {"clientName": "WEB", "clientVersion": "2.20260907.05.00", "hl": "pt", "gl": "BR"}
AND = {"clientName": "ANDROID", "clientVersion": "21.26.364", "osName": "Android", "osVersion": "11",
       "androidSdkVersion": 30, "hl": "pt", "gl": "BR"}
UA_WEB = net.BROWSER_UA
UA_AND = "com.google.android.youtube/21.26.364 (Linux; U; Android 11) gzip"
CNN = {"id": "UCvdwhh_fDyWccR42-rReZLw", "name": "CNN Brasil", "thumb": ""}
_CANON = re.compile(rb'<link rel="canonical" href="https://www\.youtube\.com/(?:watch\?v=([\w-]{11})|channel/)')
_cache = {}
_lock = threading.Lock()


class YtError(Exception):
    pass


def _api(ep, client, ua, body, timeout=15):
    body = dict(body, context={"client": client})
    try:
        with net.open_url("https://www.youtube.com/youtubei/v1/%s?prettyPrint=false" % ep,
                          headers={"Content-Type": "application/json", "User-Agent": ua, "Origin": "https://www.youtube.com"},
                          data=json.dumps(body).encode("utf-8"), method="POST", timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:  # noqa: BLE001
        raise YtError("Sem conexão com o YouTube (%s)" % e) from e


def _pic(thumbs):
    u = ((thumbs or [{}])[-1] or {}).get("url", "")
    return "https:" + u if u.startswith("//") else u


def _txt(o):
    if not o:
        return ""
    return o.get("simpleText") or "".join(r.get("text", "") for r in o.get("runs", []))


def search(q):
    r = _api("search", WEB, UA_WEB, {"query": q, "params": "EgIQAg%3D%3D"})
    out = []

    def walk(o):
        if isinstance(o, dict):
            c = o.get("channelRenderer")
            if c:
                if c.get("channelId"):
                    out.append({"id": c["channelId"], "name": _txt(c.get("title")), "thumb": _pic((c.get("thumbnail") or {}).get("thumbnails")),
                                "subs": _txt(c.get("videoCountText")) or _txt(c.get("subscriberCountText"))})
                return
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(r)
    return out


def live_id(channel_id, timeout=15):
    """Vídeo ao vivo agora do canal ('' se não está). Para de ler assim que acha o endereço canônico."""
    url = "https://www.youtube.com/channel/%s/live" % channel_id
    try:
        with net.open_url(url, headers={"User-Agent": UA_WEB, "Accept-Language": "pt-BR,pt;q=0.9", "Cookie": "CONSENT=YES+1; SOCS=CAI"}, timeout=timeout) as r:
            buf = b""
            while True:
                chunk = r.read(65536)
                if not chunk:
                    return ""
                buf = buf[-500:] + chunk
                m = _CANON.search(buf)
                if m:
                    return (m.group(1) or b"").decode()
    except Exception as e:  # noqa: BLE001
        raise YtError("Sem conexão com o YouTube (%s)" % e) from e


def player(vid):
    r = _api("player", AND, UA_AND, {"videoId": vid, "contentCheckOk": True, "racyCheckOk": True})
    vd, ps = r.get("videoDetails") or {}, r.get("playabilityStatus") or {}
    return {"ok": ps.get("status") == "OK", "live": bool(vd.get("isLive")), "title": vd.get("title", ""),
            "hls": (r.get("streamingData") or {}).get("hlsManifestUrl", ""), "reason": ps.get("reason", "")}


def status(channel_id, force=False):
    """{live, vid, title, hls}; guardado por 3 min."""
    with _lock:
        c = _cache.get(channel_id)
    if c and not force and time.time() - c["t"] < 180:
        return c["st"]
    vid = live_id(channel_id)
    st = {"live": False}
    if vid:
        p = player(vid)
        st = {"live": bool(p["ok"] and p["live"] and p["hls"]), "vid": vid, "title": p["title"], "hls": p["hls"], "reason": p["reason"]}
    with _lock:
        _cache[channel_id] = {"t": time.time(), "st": st}
    return st


def public(st):
    """Situação sem o link do vídeo (ele só sai pelo /play, passando pelo Sintonia)."""
    return {k: v for k, v in st.items() if k != "hls"}


def play_url(channel_id):
    st = status(channel_id)
    if not st.get("live"):
        st = status(channel_id, force=True)
    if not st.get("live"):
        raise YtError("Este canal não está ao vivo agora")
    # o navegador não pode buscar o vídeo do YouTube direto (CORS): passa pelo Sintonia
    return {"url": proxy.proxied("yt", st["hls"]), "type": "hls", "live": True, "title": st.get("title", ""), "direct": st["hls"]}
