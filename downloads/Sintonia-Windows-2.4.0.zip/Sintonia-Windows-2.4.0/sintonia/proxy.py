"""Proxy de streams: evita bloqueios de CORS e conteúdo misto no navegador."""

import base64
import re
import socket
import urllib.error
import urllib.parse

from . import net

CHUNK = 64 * 1024


def _read_some(resp, n):
    """Devolve o que já chegou (até n bytes) em vez de esperar n bytes: com servidor longe, juntar 64 KB
    no começo custa várias idas e voltas."""
    try:
        return resp.read1(n)
    except (AttributeError, NotImplementedError):
        return resp.read(n)
_URI_ATTR = re.compile(r'URI="([^"]+)"')


def encode(url):
    return base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").rstrip("=")


def decode(token):
    pad = "=" * (-len(token) % 4)
    return base64.urlsafe_b64decode(token + pad).decode("utf-8")


def basename(url, default="stream"):
    path = urllib.parse.urlsplit(url).path
    name = path.rsplit("/", 1)[-1] or default
    name = re.sub(r"[^\w.\-]", "_", name)[:80]
    return name or default


def proxied(src_id, url):
    return f"/p/{src_id}/{encode(url)}/{basename(url)}"


def is_playlist(url, ctype, head):
    ctype = (ctype or "").lower()
    if "mpegurl" in ctype:
        return True
    if urllib.parse.urlsplit(url).path.lower().endswith((".m3u8", ".m3u")):
        return True
    return head.lstrip().startswith(b"#EXTM3U")


def rewrite_m3u8(text, base_url, src_id):
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            out.append(line)
            continue
        if s.startswith("#"):
            if "URI=" in s:
                s = _URI_ATTR.sub(lambda m: 'URI="%s"' % proxied(src_id, urllib.parse.urljoin(base_url, m.group(1))), s)
            out.append(s)
            continue
        out.append(proxied(src_id, urllib.parse.urljoin(base_url, s)))
    return "\n".join(out) + "\n"


def handle(handler, src_id, token, ua=None):
    """Repassa a requisição para o provedor e devolve a resposta ao navegador."""
    try:
        url = decode(token)
    except (ValueError, UnicodeDecodeError):
        handler.send_error(400, "Endereço inválido")
        return
    if not url.lower().startswith(("http://", "https://")):
        handler.send_error(400, "Endereço inválido")
        return
    headers = {}
    if ua:
        headers["User-Agent"] = ua
    rng = handler.headers.get("Range")
    if rng:
        headers["Range"] = rng
    try:
        resp = net.open_url(url, headers=headers, timeout=30)
    except urllib.error.HTTPError as exc:
        handler.send_response(exc.code)
        handler.send_header("Content-Type", "text/plain; charset=utf-8")
        handler.send_header("Access-Control-Allow-Origin", "*")
        body = f"O provedor respondeu {exc.code}".encode("utf-8")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)
        return
    except Exception as exc:  # noqa: BLE001
        handler.send_response(502)
        body = f"Falha ao conectar ao provedor: {exc}".encode("utf-8")
        handler.send_header("Content-Type", "text/plain; charset=utf-8")
        handler.send_header("Access-Control-Allow-Origin", "*")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)
        return

    with resp:
        final_url = resp.geturl()
        ctype = resp.headers.get("Content-Type", "")
        first = _read_some(resp, CHUNK)   # 2.4.0: não espera juntar 64 KB para começar
        if is_playlist(final_url, ctype, first[:64]):
            rest = resp.read(8 * 1024 * 1024)
            text = (first + rest).decode("utf-8", "replace")
            body = rewrite_m3u8(text, final_url, src_id).encode("utf-8")
            handler.send_response(200)
            handler.send_header("Content-Type", "application/vnd.apple.mpegurl")
            handler.send_header("Cache-Control", "no-cache")
            handler.send_header("Access-Control-Allow-Origin", "*")
            handler.send_header("Content-Length", str(len(body)))
            handler.end_headers()
            handler.wfile.write(body)
            return

        status = getattr(resp, "status", 200) or 200
        handler.send_response(status)
        if not ctype or ctype.startswith(("application/octet-stream", "text/plain")):
            low = urllib.parse.urlsplit(final_url).path.lower()
            if low.endswith(".ts"):
                ctype = "video/mp2t"
            elif low.endswith(".mkv"):
                ctype = "video/webm"
            elif low.endswith(".mp4") or low.endswith(".m4v"):
                ctype = "video/mp4"
        if ctype:
            handler.send_header("Content-Type", ctype)
        for h in ("Content-Length", "Content-Range", "Accept-Ranges", "Last-Modified"):
            v = resp.headers.get(h)
            if v:
                handler.send_header(h, v)
        if not resp.headers.get("Content-Length"):
            handler.send_header("Connection", "close")
            handler.close_connection = True
        handler.send_header("Access-Control-Allow-Origin", "*")
        handler.send_header("Cache-Control", "no-store")
        handler.end_headers()
        try:
            if first:
                handler.wfile.write(first)
            while True:
                chunk = _read_some(resp, CHUNK)
                if not chunk:
                    break
                handler.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, socket.timeout, OSError):
            handler.close_connection = True
