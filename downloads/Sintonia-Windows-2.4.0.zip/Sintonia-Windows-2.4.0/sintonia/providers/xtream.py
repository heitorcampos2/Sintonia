"""Provedor Xtream Codes (player_api.php)."""

import base64
import urllib.parse
from datetime import datetime

from .. import net
from .base import Provider, to_float, to_int, year_from


def _b64(text):
    if not text:
        return ""
    try:
        return base64.b64decode(text).decode("utf-8", "replace")
    except (ValueError, TypeError):
        return text


def normalize_base(url):
    url = (url or "").strip()
    if not url:
        return ""
    if "://" not in url:
        url = "http://" + url
    parsed = urllib.parse.urlsplit(url)
    path = parsed.path
    for tail in ("/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php", "/c/", "/c"):
        if path.endswith(tail):
            path = path[: -len(tail)]
    path = path.rstrip("/")
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, path, "", ""))


class XtreamProvider(Provider):
    kind = "xtream"

    def __init__(self, source):
        super().__init__(source)
        self.base = normalize_base(source.get("url"))
        self.user = source.get("username", "")
        self.password = source.get("password", "")
        self._tz = None
        self._stream_base = None   # endereço de vídeo informado pelo próprio servidor (server_info)
        self._info_tried = False

    def _alternates(self):
        """Mesmo servidor em http e https: alguns painéis só respondem a API num deles."""
        parts = urllib.parse.urlsplit(self.base)
        host = parts.hostname or ""
        out = [self.base]
        if parts.scheme == "https":
            out += [f"http://{host}", f"http://{host}:80", f"http://{host}:8080"]
        else:
            out += [f"https://{host}"]
        seen, uniq = set(), []
        for b in out:
            if b not in seen:
                seen.add(b)
                uniq.append(b)
        return uniq

    def _q(self, s):
        return urllib.parse.quote(str(s), safe="")

    def api(self, action=None, **params):
        q = {"username": self.user, "password": self.password}
        if action:
            q["action"] = action
        q.update({k: v for k, v in params.items() if v is not None})
        query = urllib.parse.urlencode(q)
        last = None
        for base in self._alternates():
            try:
                data = net.fetch_json(f"{base}/player_api.php?{query}", timeout=60)
                self.base = base   # guarda o endereço que funcionou
                return data
            except net.FetchError as exc:
                last = exc
                msg = str(exc)
                # erro de login ou recurso: não adianta tentar outro endereço
                if any(code in msg for code in ("401", "403", "404")):
                    raise
        raise last

    def account(self):
        d = self.api() or {}
        ui = d.get("user_info") or {}
        si = d.get("server_info") or {}
        if not ui and isinstance(d, dict) and d.get("user_info") is None and not d:
            raise net.FetchError("O servidor não retornou dados da conta")
        if str(ui.get("auth", "1")) == "0":
            raise net.FetchError("Usuário ou senha incorretos")
        self._tz = si.get("timezone")
        host = si.get("url")
        if host and not (si.get("port") or si.get("https_port")):
            host = None  # sem porta informada: usa o mesmo endereço do link (que já funciona)
        if host:
            proto = (si.get("server_protocol") or "http").lower()
            port = si.get("https_port") if proto == "https" else si.get("port")
            port = str(port or "").strip()
            default = "443" if proto == "https" else "80"
            self._stream_base = f"{proto}://{host}" + (f":{port}" if port and port != default else "")
        exp = to_int(ui.get("exp_date"), 0)
        return {
            "status": ui.get("status") or "Active",
            "username": ui.get("username") or self.user,
            "expires": exp or None,
            "isTrial": str(ui.get("is_trial", "0")) == "1",
            "activeCons": to_int(ui.get("active_cons"), 0),
            "maxCons": to_int(ui.get("max_connections"), 0),
            "created": to_int(ui.get("created_at"), 0) or None,
            "formats": ui.get("allowed_output_formats") or [],
            "timezone": si.get("timezone") or "",
            "server": si.get("url") or "",
        }

    def load(self, kind, cat=None):
        cat_action = {"live": "get_live_categories", "movie": "get_vod_categories",
                      "series": "get_series_categories"}[kind]
        list_action = {"live": "get_live_streams", "movie": "get_vod_streams",
                       "series": "get_series"}[kind]
        cats = self.api(cat_action) or []
        items = self.api(list_action) or []
        if isinstance(items, dict):
            items = list(items.values())
        categories = [{"id": str(c.get("category_id")), "name": (c.get("category_name") or "").strip()}
                      for c in cats if isinstance(c, dict)]
        norm = {"live": self._live, "movie": self._movie, "series": self._series}[kind]
        out = []
        for it in items:
            if isinstance(it, dict):
                try:
                    out.append(norm(it))
                except (KeyError, TypeError, ValueError):
                    continue
        return {"categories": categories, "items": out}

    @staticmethod
    def _cat(it):
        c = it.get("category_id")
        if c is None and it.get("category_ids"):
            c = it["category_ids"][0]
        return str(c) if c is not None else ""

    def _live(self, it):
        return {
            "id": str(it["stream_id"]),
            "name": (it.get("name") or "").strip(),
            "logo": it.get("stream_icon") or "",
            "cat": self._cat(it),
            "num": to_int(it.get("num"), 0),
            "epg": it.get("epg_channel_id") or "",
            "archive": to_int(it.get("tv_archive"), 0) == 1,
            "archive_days": to_int(it.get("tv_archive_duration"), 0),
            "added": to_int(it.get("added"), 0),
        }

    def _movie(self, it):
        name = (it.get("name") or "").strip()
        return {
            "id": str(it["stream_id"]),
            "name": name,
            "poster": it.get("stream_icon") or "",
            "cat": self._cat(it),
            "rating": round(to_float(it.get("rating"), 0.0), 1),
            "added": to_int(it.get("added"), 0),
            "year": year_from(it.get("year"), it.get("releasedate"), name),
            "ext": it.get("container_extension") or "mp4",
            "num": to_int(it.get("num"), 0),
        }

    def _series(self, it):
        name = (it.get("name") or "").strip()
        return {
            "id": str(it["series_id"]),
            "name": name,
            "poster": it.get("cover") or "",
            "cat": self._cat(it),
            "rating": round(to_float(it.get("rating"), 0.0), 1),
            "added": to_int(it.get("last_modified"), 0),
            "year": year_from(it.get("year"), it.get("releaseDate") or it.get("release_date"), name),
            "plot": it.get("plot") or "",
            "num": to_int(it.get("num"), 0),
        }

    @staticmethod
    def _list(v):
        if isinstance(v, list):
            return [x for x in v if x]
        if isinstance(v, str) and v:
            return [v]
        return []

    def movie_info(self, item_id):
        d = self.api("get_vod_info", vod_id=item_id) or {}
        info = d.get("info") or {}
        data = d.get("movie_data") or {}
        if isinstance(info, list):
            info = {}
        return {
            "id": str(item_id),
            "name": data.get("name") or info.get("name") or "",
            "plot": info.get("plot") or info.get("description") or "",
            "cast": info.get("cast") or info.get("actors") or "",
            "director": info.get("director") or "",
            "genre": info.get("genre") or "",
            "release": info.get("releasedate") or info.get("release_date") or "",
            "duration": info.get("duration") or "",
            "durationSecs": to_int(info.get("duration_secs"), 0),
            "rating": round(to_float(info.get("rating"), 0.0), 1),
            "trailer": info.get("youtube_trailer") or "",
            "poster": info.get("movie_image") or info.get("cover_big") or "",
            "backdrop": (self._list(info.get("backdrop_path")) or [""])[0],
            "ext": data.get("container_extension") or "mp4",
            "country": info.get("country") or "",
        }

    def series_info(self, item_id):
        d = self.api("get_series_info", series_id=item_id) or {}
        info = d.get("info") or {}
        if isinstance(info, list):
            info = {}
        eps = d.get("episodes") or {}
        if isinstance(eps, list):  # alguns painéis devolvem lista de listas
            tmp = {}
            for group in eps:
                for e in group or []:
                    tmp.setdefault(str(e.get("season", 1)), []).append(e)
            eps = tmp
        seasons = {}
        for season, lst in eps.items():
            out = []
            for e in lst or []:
                ei = e.get("info") or {}
                if isinstance(ei, list):
                    ei = {}
                out.append({
                    "id": str(e.get("id")),
                    "season": to_int(e.get("season") or season, 1),
                    "episode": to_int(e.get("episode_num"), 0),
                    "title": e.get("title") or "",
                    "ext": e.get("container_extension") or "mp4",
                    "plot": ei.get("plot") or "",
                    "still": ei.get("movie_image") or "",
                    "durationSecs": to_int(ei.get("duration_secs"), 0),
                    "duration": ei.get("duration") or "",
                    "rating": round(to_float(ei.get("rating"), 0.0), 1),
                    "air": ei.get("releasedate") or ei.get("air_date") or "",
                })
            out.sort(key=lambda x: x["episode"])
            seasons[str(to_int(season, 1))] = out
        season_meta = {}
        for s in d.get("seasons") or []:
            if isinstance(s, dict):
                season_meta[str(to_int(s.get("season_number"), 0))] = {
                    "name": s.get("name") or "", "cover": s.get("cover_big") or s.get("cover") or "",
                    "overview": s.get("overview") or ""}
        return {
            "info": {
                "id": str(item_id),
                "name": info.get("name") or "",
                "plot": info.get("plot") or "",
                "cast": info.get("cast") or "",
                "director": info.get("director") or "",
                "genre": info.get("genre") or "",
                "release": info.get("releaseDate") or info.get("release_date") or "",
                "rating": round(to_float(info.get("rating"), 0.0), 1),
                "trailer": info.get("youtube_trailer") or "",
                "poster": info.get("cover") or "",
                "backdrop": (self._list(info.get("backdrop_path")) or [""])[0],
            },
            "seasons": seasons,
            "seasonMeta": season_meta,
        }

    def short_epg(self, item, limit=10):
        d = self.api("get_short_epg", stream_id=item["id"], limit=limit) or {}
        out = []
        for p in d.get("epg_listings") or []:
            start = to_int(p.get("start_timestamp"), 0)
            stop = to_int(p.get("stop_timestamp"), 0)
            if not start:
                continue
            out.append({"start": start, "stop": stop or start + 1800,
                        "title": _b64(p.get("title")), "desc": _b64(p.get("description"))})
        return out

    def video_base(self, wait=False):
        """Endereço de vídeo informado pelo servidor. 2.4.0: não espera mais por ele no 1º canal (se o servidor
        da lista travasse, o 1º canal ficava ~20 s parado): descobre em segundo plano e usa o da lista até lá."""
        if self._stream_base is None and not self._info_tried:
            self._info_tried = True

            def job():
                try:
                    self.account()
                except Exception:  # noqa: BLE001
                    pass
            if wait:
                job()
            else:
                import threading
                threading.Thread(target=job, daemon=True).start()
        return self._stream_base or self.base

    def stream_url(self, kind, item, fmt=None):
        u, p = self._q(self.user), self._q(self.password)
        b = self.video_base()
        if kind == "live":
            ext = fmt if fmt in ("ts", "m3u8") else "ts"
            return f"{b}/live/{u}/{p}/{item['id']}.{ext}"
        if kind == "movie":
            return f"{b}/movie/{u}/{p}/{item['id']}.{item.get('ext') or 'mp4'}"
        if kind == "episode":
            return f"{b}/series/{u}/{p}/{item['id']}.{item.get('ext') or 'mp4'}"
        raise ValueError(kind)

    def catchup_url(self, item, start_ts, minutes):
        """Monta a URL de replay (timeshift) no fuso do servidor."""
        dt = None
        tzname = self._tz
        if tzname:
            try:
                from zoneinfo import ZoneInfo
                dt = datetime.fromtimestamp(start_ts, ZoneInfo(tzname))
            except Exception:  # noqa: BLE001
                dt = None
        if dt is None:
            dt = datetime.fromtimestamp(start_ts)
        stamp = dt.strftime("%Y-%m-%d:%H-%M")
        u, p = self._q(self.user), self._q(self.password)
        return f"{self.video_base()}/timeshift/{u}/{p}/{int(minutes)}/{stamp}/{item['id']}.ts"

    def epg_url(self):
        q = urllib.parse.urlencode({"username": self.user, "password": self.password})
        return f"{self.base}/xmltv.php?{q}"

