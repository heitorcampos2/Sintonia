// Canais YouTube (2.3.9): opcional em Menu › Opcionais. CNN Brasil ao vivo + canais que você adicionar.
import { api } from '../api.js';
import { openPlayer } from '../player.js';
import { S, saveSettings } from '../state.js';
import { btn, clear, h, ic, menu, pic, spinner, toast } from '../ui.js';
import { sectionHeader } from './common.js';

const status = new Map();   // canal -> situação (ao vivo, título)

function channels() { return (S.settings.youtube && S.settings.youtube.channels) || []; }
async function saveChannels(list) { await saveSettings({ youtube: { channels: list } }); }
const has = (id) => channels().some((c) => c.id === id);

/** Segurar o dedo / clique direito / tecla de menu abre as opções; toque normal faz a ação principal. */
function pressable(el, onTap, onHold) {
  let t = null, held = false;
  el.addEventListener('pointerdown', () => { held = false; clearTimeout(t); t = setTimeout(() => { held = true; onHold(); }, 550); });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => el.addEventListener(ev, () => clearTimeout(t)));
  el.addEventListener('click', (e) => { if (held) { e.preventDefault(); held = false; return; } onTap(); });
  el.addEventListener('contextmenu', (e) => { e.preventDefault(); clearTimeout(t); onHold(); });
  el.addEventListener('keydown', (e) => { if (e.key === 'ContextMenu') { e.preventDefault(); onHold(); } });
  return el;
}

async function play(ch) {
  const lives = channels().filter((c) => status.get(c.id)?.live);
  const list = (lives.some((c) => c.id === ch.id) ? lives : [ch]).map((c) => ({ id: `yt-${c.id}`, name: c.name, logo: c.thumb, yt: c.id, ytTitle: status.get(c.id)?.title || '' }));
  const it = list.find((x) => x.yt === ch.id);
  openPlayer({ kind: 'live', item: it, list });
}

export function render(root, params) {
  if (params[0] === 'buscar') return searchPage(root);
  const grid = h('div.yt-grid');
  root.append(sectionHeader('Canais YouTube', { actions: [
    btn('Atualizar', { cls: 'ghost', icon: 'refresh', onclick: () => refresh(true) }),
    btn('Adicionar canal', { cls: 'primary', icon: 'plus', onclick: () => { location.hash = '#/youtube/buscar'; } })] }),
  h('div.view-body', h('p.hint', 'Toque num canal ao vivo para assistir. Segure (ou clique com o botão direito) para opções.'), grid));
  let alive = true;
  function draw() {
    clear(grid);
    const l = channels();
    if (!l.length) { grid.append(h('div.empty', 'Nenhum canal. Use "Adicionar canal" para buscar no YouTube.')); return; }
    const lv = l.filter((c) => status.get(c.id)?.live);
    [...lv, ...l.filter((c) => !lv.includes(c))].forEach((c) => {
      const st = status.get(c.id);
      const card = h('button.yt-card', { type: 'button' },
        h('div.yt-art', { class: st?.vid ? '' : 'noimg' }, st?.vid ? h('img', { src: `https://i.ytimg.com/vi/${st.vid}/mqdefault.jpg`, alt: '', loading: 'lazy', onerror: (e) => e.target.remove() }) : null,
          h('div.yt-ava', pic(c.thumb, c.name)), st?.live ? h('span.yt-live', 'AO VIVO') : null),
        h('div.yt-meta', h('strong', c.name), h('small', !st ? 'Verificando…' : st.live ? st.title : 'Sem transmissão ao vivo agora')));
      pressable(card, () => { if (st?.live) play(c); else toast(st ? `${c.name} não está ao vivo agora` : 'Verificando…'); }, () => options(c));
      grid.append(card);
    });
  }
  async function options(c) {
    const l = channels(), i = l.findIndex((x) => x.id === c.id), st = status.get(c.id);
    await menu([
      st?.live ? { label: 'Assistir ao vivo', icon: 'play', fn: () => play(c) } : null,
      { label: 'Ver de novo se está ao vivo', icon: 'refresh', fn: () => check(c, true) },
      i > 0 ? { label: 'Mover para cima', icon: 'chevL', fn: async () => { const n = [...l]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; await saveChannels(n); draw(); } } : null,
      i < l.length - 1 ? { label: 'Mover para baixo', icon: 'chevR', fn: async () => { const n = [...l]; [n[i + 1], n[i]] = [n[i], n[i + 1]]; await saveChannels(n); draw(); } } : null,
      { label: 'Remover dos Canais YouTube', icon: 'trash', fn: async () => { await saveChannels(l.filter((x) => x.id !== c.id)); draw(); } },
    ].filter(Boolean), { title: c.name });
  }
  async function check(c, force) {
    try { status.set(c.id, await api.get(`/api/yt/status?id=${encodeURIComponent(c.id)}${force ? '&force=1' : ''}`)); } catch { status.set(c.id, { live: false }); }
    if (alive) draw();
  }
  async function refresh(force) {
    draw();
    const l = channels();
    // canal sem foto (a CNN que já vem na lista): pega pela busca uma vez
    l.filter((c) => !c.thumb).forEach(async (c) => {
      try {
        const r = await api.get(`/api/yt/search?q=${encodeURIComponent(c.name)}`);
        const m = r.channels.find((x) => x.id === c.id);
        if (m && m.thumb) { await saveChannels(channels().map((x) => (x.id === c.id ? { ...x, thumb: m.thumb } : x))); if (alive) draw(); }
      } catch { /* fica com as iniciais */ }
    });
    l.forEach((c) => check(c, force));
  }
  refresh(false);
  return () => { alive = false; };
}

function searchPage(root) {
  const input = h('input.input', { type: 'search', placeholder: 'Nome do canal no YouTube', autocomplete: 'off' });
  const res = h('div.yt-results');
  const go = async () => {
    const q = input.value.trim();
    if (q.length < 2) { toast('Digite pelo menos 2 letras'); return; }
    clear(res).append(spinner());
    let r;
    try { r = await api.get(`/api/yt/search?q=${encodeURIComponent(q)}`); } catch (e) { clear(res).append(h('div.empty', `Não deu para buscar: ${e.message}`)); return; }
    show(r.channels);
  };
  function show(list) {
    clear(res);
    if (!list.length) { res.append(h('div.empty', 'Nenhum canal encontrado.')); return; }
    list.forEach((c) => {
      const el = h('button.yt-res', { type: 'button' }, h('span.yt-res-ava', pic(c.thumb, c.name)),
        h('span.yt-res-txt', h('strong', c.name), h('small', [has(c.id) ? '✓ Adicionado' : '', c.subs || ''].filter(Boolean).join(' · '))),
        has(c.id) ? ic('check') : ic('plus'));
      const opts = async () => {
        await menu([
          has(c.id) ? { label: 'Remover dos Canais YouTube', icon: 'trash', fn: async () => { await saveChannels(channels().filter((x) => x.id !== c.id)); show(list); } }
            : { label: 'Adicionar aos Canais YouTube', icon: 'plus', fn: async () => { await saveChannels([...channels(), { id: c.id, name: c.name, thumb: c.thumb }]); toast(`"${c.name}" adicionado`); show(list); } },
          { label: 'Ver se está ao vivo', icon: 'play', fn: async () => {
            try {
              const st = await api.get(`/api/yt/status?id=${encodeURIComponent(c.id)}&force=1`);
              status.set(c.id, st);
              if (st.live) play(c); else toast(`${c.name} não está ao vivo agora`);
            } catch (e) { toast(e.message); }
          } },
        ], { title: c.name });
      };
      pressable(el, opts, opts);
      res.append(el);
    });
  }
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
  root.append(sectionHeader('Adicionar canal', { back: () => { location.hash = '#/youtube'; } }),
    h('div.view-body.narrow', h('p.hint', 'Busque no YouTube e toque (ou segure) num canal para adicionar.'),
      h('div.yt-search', input, btn('Buscar', { cls: 'primary', icon: 'search', onclick: go })), res));
  setTimeout(() => input.focus(), 50);
}
