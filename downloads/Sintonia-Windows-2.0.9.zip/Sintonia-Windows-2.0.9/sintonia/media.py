"""Cache de imagens (logos e capas) e bibliotecas de vídeo de terceiros."""

import hashlib
import os
import threading
import time
import urllib.error
import urllib.parse
from pathlib import Path

from . import net
from .proxy import decode

MAX_IMAGE = 6 * 1024 * 1024
CACHE_LIMIT = 400 * 1024 * 1024

VENDOR = {
    "hls.min.js": [
        "https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js",
        "https://unpkg.com/hls.js@1/dist/hls.min.js",
        "https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.20/hls.min.js",
    ],
    "mpegts.js": [
        "https://cdn.jsdelivr.net/npm/mpegts.js@1/dist/mpegts.js",
        "https://unpkg.com/mpegts.js@1/dist/mpegts.js",
    ],
}


class ImageCache:
    def __init__(self, folder):
        self.dir = Path(folder)
        self.dir.mkdir(parents=True, exist_ok=True)
        self._failed = {}
        self._deadhost = {}  # site que não responde: pula direto por 15 min
        threading.Thread(target=self._trim, daemon=True).start()

    def _trim(self):
        try:
            files = [(f.stat().st_mtime, f.stat().st_size, f) for f in self.dir.iterdir() if f.is_file()]
            total = sum(s for _, s, _ in files)
            if total <= CACHE_LIMIT:
                return
            for _, size, f in sorted(files):
                f.unlink(missing_ok=True)
                total -= size
                if total < CACHE_LIMIT * 0.6:
                    break
        except OSError:
            pass

    def get(self, token):
        """Devolve (bytes, content_type) ou None."""
        try:
            url = decode(token)
        except (ValueError, UnicodeDecodeError):
            return None
        if url.startswith("data:"):
            return None
        key = hashlib.sha1(url.encode("utf-8")).hexdigest()
        path = self.dir / key
        meta = self.dir / (key + ".type")
        if path.exists():
            ctype = meta.read_text() if meta.exists() else "image/jpeg"
            return path.read_bytes(), ctype
        if time.time() - self._failed.get(key, 0) < 3600:
            return None
        host = urllib.parse.urlsplit(url).netloc.lower()
        if time.time() - self._deadhost.get(host, 0) < 900:
            return None
        try:
            with net.open_url(url, timeout=6) as resp:
                ctype = resp.headers.get("Content-Type", "image/jpeg").split(";")[0]
                data = resp.read(MAX_IMAGE + 1)
            if len(data) > MAX_IMAGE or not data:
                raise ValueError("imagem grande demais")
            if not ctype.startswith("image/"):
                head = data[:12]
                if head.startswith(b"\x89PNG"):
                    ctype = "image/png"
                elif head[:3] == b"\xff\xd8\xff":
                    ctype = "image/jpeg"
                elif head[:4] == b"RIFF":
                    ctype = "image/webp"
                elif b"<svg" in data[:500]:
                    ctype = "image/svg+xml"
                else:
                    raise ValueError("não é imagem")
            tmp = path.with_suffix(".part")
            tmp.write_bytes(data)
            os.replace(tmp, path)
            meta.write_text(ctype)
            return data, ctype
        except Exception as exc:  # noqa: BLE001
            self._failed[key] = time.time()
            if not isinstance(exc, (urllib.error.HTTPError, ValueError)):
                self._deadhost[host] = time.time()  # tempo esgotado / site fora do ar
            return None


class Vendor:
    """Baixa hls.js/mpegts.js na primeira vez e guarda para uso offline."""

    def __init__(self, folder, bundled=None):
        self.dir = Path(folder)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.bundled = Path(bundled) if bundled else None
        self._lock = threading.Lock()

    def get(self, name):
        if name not in VENDOR:
            return None
        for base in (self.dir, self.bundled):
            if base and (base / name).exists():
                return (base / name).read_bytes()
        with self._lock:
            if (self.dir / name).exists():
                return (self.dir / name).read_bytes()
            for url in VENDOR[name]:
                try:
                    data = net.fetch_bytes(url, timeout=25)
                    if len(data) > 10000:
                        (self.dir / name).write_bytes(data)
                        return data
                except net.FetchError:
                    continue
        return None

    def prefetch(self):
        for name in VENDOR:
            self.get(name)
