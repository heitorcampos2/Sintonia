"""Linha de comando: sintonia [--porta 8787] [--senha X] [--abrir] [--fundo | --parar]."""

import argparse
import os
import signal
import sys
import threading
import webbrowser

from . import VERSION
from .config import data_dir


def _pidfile(dados):
    return data_dir(dados) / "sintonia.pid"


def _ask_quit(porta, senha=""):
    """Pede ao servidor que se encerre (funciona mesmo se ele foi aberto como administrador)."""
    import json
    import urllib.request
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{porta}/api/quit", data=b"{}", method="POST",
                                     headers={"Content-Type": "application/json", "X-Sintonia-Senha": senha or ""})
        with urllib.request.urlopen(req, timeout=4) as r:
            json.loads(r.read() or b"{}")
    except Exception:  # noqa: BLE001
        return False
    # espera a porta liberar
    import socket
    import time
    for _ in range(30):
        with socket.socket() as s:
            s.settimeout(0.3)
            if s.connect_ex(("127.0.0.1", porta)) != 0:
                return True
        time.sleep(0.2)
    return True


def stop_background(dados, porta=8787, senha=""):
    pf = _pidfile(dados)
    if _ask_quit(porta, senha):
        pf.unlink(missing_ok=True)
        print("Sintonia parado.")
        return 0
    try:
        pid = int(pf.read_text().strip())
    except (OSError, ValueError):
        print("O Sintonia não está rodando.")
        return 1
    try:
        os.kill(pid, signal.SIGTERM)
        print(f"Sintonia parado (processo {pid}).")
    except ProcessLookupError:
        print("O processo já tinha sido encerrado.")
    except PermissionError:
        if os.name == "nt":
            import subprocess
            subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True)
        print("Não consegui parar: o processo pode ter sido aberto como administrador.")
    pf.unlink(missing_ok=True)
    return 0


def daemonize(dados):
    if os.fork() > 0:
        return False
    os.setsid()
    if os.fork() > 0:
        os._exit(0)
    log = data_dir(dados) / "sintonia.log"
    fd = os.open(str(log), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    os.dup2(fd, 1)
    os.dup2(fd, 2)
    devnull = os.open(os.devnull, os.O_RDONLY)
    os.dup2(devnull, 0)
    _pidfile(dados).write_text(str(os.getpid()))
    return True


def _browser_paths():
    """Chrome e Edge no Windows (para abrir o Sintonia em janela própria, como aplicativo)."""
    env = os.environ
    bases = [env.get("PROGRAMFILES", r"C:\Program Files"), env.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
             env.get("LOCALAPPDATA", "")]
    rel = [r"Google\Chrome\Application\chrome.exe", r"Microsoft\Edge\Application\msedge.exe"]
    out = []
    for r in rel:
        for b in bases:
            if b and os.path.isfile(os.path.join(b, r)):
                out.append(os.path.join(b, r))
                break
    return out


def open_ui(url, window):
    """Abre a interface; em modo janela usa Chrome/Edge com --app (sem barra do navegador)."""
    if window:
        import shutil
        import subprocess
        cands = _browser_paths() if os.name == "nt" else [shutil.which(x) for x in
                                                           ("google-chrome", "chromium", "chromium-browser", "microsoft-edge")]
        for exe in [c for c in cands if c]:
            try:
                flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                subprocess.Popen([exe, f"--app={url}", "--start-maximized"], close_fds=True,
                                 creationflags=flags if os.name == "nt" else 0,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return
            except OSError:
                continue
    webbrowser.open(url)


def _already_running(port):
    import json
    import urllib.request
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/state", timeout=3) as r:
            return "version" in json.loads(r.read().decode())
    except Exception as exc:  # noqa: BLE001
        return getattr(exc, "code", None) == 401  # protegido por senha, mas é um Sintonia


def main(argv=None):
    p = argparse.ArgumentParser(prog="sintonia", description="Player IPTV que abre em qualquer navegador.")
    p.add_argument("--porta", type=int, default=int(os.environ.get("SINTONIA_PORTA", 8787)))
    p.add_argument("--host", default="0.0.0.0", help="use 127.0.0.1 para aceitar só este aparelho")
    p.add_argument("--senha", default=os.environ.get("SINTONIA_SENHA", ""),
                   help="pede esta senha a quem abrir o Sintonia pela rede")
    p.add_argument("--dados", default=None, help="pasta onde ficam configurações e cache")
    p.add_argument("--abrir", action="store_true", help="abre o navegador ao iniciar")
    p.add_argument("--janela", action="store_true", help="abre em janela própria (Chrome/Edge em modo aplicativo)")
    p.add_argument("--fundo", action="store_true", help="roda em segundo plano")
    p.add_argument("--parar", action="store_true", help="para a execução em segundo plano")
    p.add_argument("--versao", action="version", version=f"Sintonia {VERSION}")
    a = p.parse_args(argv)

    # pythonw (atalho do Windows) não tem console: a saída vai para um arquivo de registro
    if sys.stdout is None or sys.stderr is None:
        log = open(data_dir(a.dados) / "sintonia.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log

    if a.parar:
        sys.exit(stop_background(a.dados, a.porta, a.senha))

    from .server import App, lan_addresses, make_server

    import time
    tries = 40 if os.environ.get("SINTONIA_REINICIO") else 1   # reinício: espera a versão anterior liberar a porta
    err = None
    app = App(a.dados, a.senha, a.porta)
    for attempt in range(tries):
        try:
            httpd = make_server(app, a.host, a.porta)
            err = None
            break
        except OSError as exc:
            err = exc
            if attempt < tries - 1:
                time.sleep(0.5)
    if err is not None:
        exc = err
        if getattr(exc, "errno", None) in (98, 48, 10048) or getattr(exc, "winerror", None) == 10048:
            if (a.abrir or a.janela) and _already_running(a.porta):
                # já está aberto: só mostra a janela de novo
                open_ui(f"http://localhost:{a.porta}", a.janela)
                sys.exit(0)
            print(f"A porta {a.porta} já está em uso. O Sintonia talvez já esteja aberto: "
                  f"acesse http://localhost:{a.porta}\nOu escolha outra porta: sintonia --porta 8790")
        else:
            print(f"Não foi possível iniciar: {exc}")
        sys.exit(1)

    local = f"http://localhost:{a.porta}"
    lines = [f"Sintonia {VERSION} rodando.", "", f"  Neste aparelho:  {local}"]
    if a.host in ("0.0.0.0", "::"):
        for ip in lan_addresses():
            lines.append(f"  Na rede (Windows, TV, outro celular):  http://{ip}:{a.porta}")
    lines += ["", "Deixe esta janela aberta enquanto usa. Para encerrar: Ctrl+C"]
    if a.senha:
        lines.insert(1, "  Acesso protegido por senha.")

    if a.fundo and os.name != "nt":
        print("\n".join(lines[:-1]))
        print("\nRodando em segundo plano. Para parar: sintonia --parar")
        if not daemonize(a.dados):
            return
    else:
        print("\n".join(lines), flush=True)
        try:
            _pidfile(a.dados).write_text(str(os.getpid()))
        except OSError:
            pass

    if a.abrir or a.janela:
        threading.Timer(0.8, lambda: open_ui(local, a.janela)).start()

    def _term(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, _term)
    try:
        httpd.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nSintonia encerrado.")
    finally:
        httpd.server_close()
        try:
            if _pidfile(a.dados).read_text().strip() == str(os.getpid()):
                _pidfile(a.dados).unlink()
        except OSError:
            pass
