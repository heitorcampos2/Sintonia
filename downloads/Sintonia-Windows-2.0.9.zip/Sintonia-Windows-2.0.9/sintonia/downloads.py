"""Downloads de filmes/episódios e gravação de canais ao vivo."""

import os
import re
import threading
import time
import urllib.error
import urllib.parse
import uuid
from pathlib import Path

from . import net
from .store import JsonStore

CHUNK = 256 * 1024
MAX_PARALLEL = 1          # um por vez: muitos provedores só liberam 1 conexão
OFFLINE_NOTE = "Sem conexão: continua sozinho de onde parou quando a internet voltar"


def safe_name(name, default="video"):
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', " ", name or "").strip(" .")
    name = re.sub(r"\s+", " ", name)
    return (name or default)[:120]


def _attrs(line):
    return dict(re.findall(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', line))


class Job:
    def __init__(self):
        self.stop = threading.Event()


class DownloadManager:
    def __init__(self, data_dir, resolver, settings_getter):
        self.store = JsonStore(Path(data_dir) / "downloads.json", {"items": []})
        self.resolver = resolver
        self.settings = settings_getter
        self.jobs = {}
        self.lock = threading.RLock()
        self.sem = threading.Semaphore(MAX_PARALLEL)
        changed = False
        resume = []
        for it in self.store.data["items"]:
            if it["status"] == "recording":
                it["status"] = "error"
                it["error"] = "Interrompido quando o Sintonia foi fechado"
                changed = True
            elif it["status"] in ("downloading", "queued"):
                # o Sintonia foi fechado no meio: continua de onde parou
                it["status"] = "queued"
                it["note"] = ""
                resume.append(it)
                changed = True
        if changed:
            self.store.save()
        for it in resume:
            self._start(it)

    # --- pastas ---------------------------------------------------------------
    def _folder(self, rec):
        from .config import default_media_dir
        s = self.settings()
        if rec:
            d = s.get("recordDir") or os.path.join(default_media_dir(), "Gravações")
        else:
            d = s.get("downloadDir") or default_media_dir()
        Path(d).mkdir(parents=True, exist_ok=True)
        return Path(d)

    # --- consulta ---------------------------------------------------------------
    def list(self):
        with self.lock:
            out = []
            for it in self.store.data["items"]:
                d = dict(it)
                d.pop("ref", None)
                d["exists"] = bool(it.get("file")) and os.path.exists(it["file"])
                out.append(d)
            return out

    def get(self, job_id):
        for it in self.store.data["items"]:
            if it["id"] == job_id:
                return it
        return None

    def _set(self, job_id, **fields):
        with self.lock:
            it = self.get(job_id)
            if it:
                it.update(fields)
                if fields.get("status") in ("done", "error", "canceled", "recording", "downloading"):
                    self.store.save()

    # --- ações -----------------------------------------------------------------
    def add(self, src_id, kind, ref, meta, record_minutes=None):
        rec = kind == "live"
        job_id = uuid.uuid4().hex[:10]
        item = {
            "id": job_id, "type": "rec" if rec else "download", "src": src_id, "kind": kind,
            "itemId": ref.get("id"), "name": meta.get("name") or "Sem título", "img": meta.get("img") or "",
            "meta": meta, "ref": ref, "status": "queued", "done": 0, "total": 0, "file": "",
            "created": int(time.time()), "error": "",
            "endsAt": int(time.time() + record_minutes * 60) if rec and record_minutes else None,
        }
        with self.lock:
            self.store.data["items"].insert(0, item)
            self.store.save()
        self._start(item)
        return {k: v for k, v in item.items() if k != "ref"}

    def retry(self, job_id):
        it = self.get(job_id)
        if not it or it["status"] in ("downloading", "recording", "queued"):
            return False
        it.update(status="queued", error="", note="")
        if it["type"] == "rec":
            it["endsAt"] = None
            it["done"] = 0
        elif not (it.get("file") and os.path.exists(it["file"])):
            # o arquivo sumiu (ou foi cancelado): começa do zero
            it.update(done=0, file="", seg=0, segBytes=0, mode="")
        self.store.save()
        self._start(it)
        return True

    def stop(self, job_id):
        job = self.jobs.get(job_id)
        if job:
            job.stop.set()
            return True
        return False

    def delete(self, job_id, remove_file=True):
        self.stop(job_id)
        with self.lock:
            it = self.get(job_id)
            if not it:
                return False
            if remove_file and it.get("file"):
                try:
                    os.unlink(it["file"])
                except OSError:
                    pass
            self.store.data["items"] = [x for x in self.store.data["items"] if x["id"] != job_id]
            self.store.save()
        return True

    def _start(self, item):
        job = Job()
        self.jobs[item["id"]] = job
        threading.Thread(target=self._run, args=(item, job), daemon=True).start()

    # --- execução ----------------------------------------------------------------
    def _run(self, item, job):
        rec = item["type"] == "rec"
        if not rec:
            self.sem.acquire()
        try:
            if job.stop.is_set():
                self._set(item["id"], status="canceled")
                return
            if not rec:
                self._set(item["id"], status="downloading", error="")
                self._download(item, job)
                if job.stop.is_set():
                    self._set(item["id"], status="canceled", note="")
                    try:
                        os.unlink(self.get(item["id"])["file"])
                    except (OSError, TypeError, KeyError):
                        pass
                    self._set(item["id"], done=0, seg=0, segBytes=0, mode="", file="")
                else:
                    self._set(item["id"], status="done", note="", finished=int(time.time()))
                return
            url, ua = self.resolver(item["src"], item["kind"], item["ref"])
            headers = {"User-Agent": ua} if ua else None
            meta = item.get("meta") or {}
            base = safe_name(meta.get("fileName") or item["name"])
            if rec:
                base += time.strftime(" - %Y-%m-%d %Hh%M")
            self._set(item["id"], status="recording" if rec else "downloading")
            resp = net.open_url(url, headers=headers, timeout=40)
            first = resp.read(CHUNK)
            ctype = resp.headers.get("Content-Type", "").lower()
            final = resp.geturl()
            if "mpegurl" in ctype or first.lstrip().startswith(b"#EXTM3U"):
                text = (first + resp.read()).decode("utf-8", "replace")
                resp.close()
                path = self._unique(self._folder(rec) / f"{base}.ts")
                self._set(item["id"], file=str(path))
                self._hls(item, job, text, final, path, headers, rec)
            else:
                ext = Path(urllib.parse.urlsplit(final).path).suffix.lower().lstrip(".") or meta.get("ext") or "mp4"
                if rec or ext in ("php", ""):
                    ext = "ts" if rec else (meta.get("ext") or "mp4")
                path = self._unique(self._folder(rec) / f"{base}.{ext}")
                total = int(resp.headers.get("Content-Length") or 0)
                self._set(item["id"], file=str(path), total=0 if rec else total)
                self._copy(item, job, resp, first, path, rec)
            if job.stop.is_set() and not rec:
                self._set(item["id"], status="canceled")
                try:
                    os.unlink(self.get(item["id"])["file"])
                except (OSError, TypeError, KeyError):
                    pass
            else:
                self._set(item["id"], status="done", finished=int(time.time()))
        except Exception as exc:  # noqa: BLE001
            self._set(item["id"], status="error", error=str(exc)[:300])
        finally:
            self.jobs.pop(item["id"], None)
            if not rec:
                self.sem.release()

    # --- download completo, com retomada ------------------------------------------
    def _wait(self, item, job, attempt, note=OFFLINE_NOTE):
        """Espera antes de tentar de novo (2 s, 4 s… até 30 s). Mantém o que já foi baixado."""
        self._set(item["id"], note=note)
        delay = min(30, 2 ** min(attempt, 5))
        end = time.time() + delay
        while time.time() < end:
            if job.stop.is_set():
                return False
            time.sleep(0.5)
        return True

    def _open(self, item, extra=None):
        url, ua = self.resolver(item["src"], item["kind"], item["ref"])
        headers = {"User-Agent": ua} if ua else {}
        if extra:
            headers.update(extra)
        return net.open_url(url, headers=headers or None, timeout=40), ({"User-Agent": ua} if ua else None)

    def _download(self, item, job):
        """Baixa o vídeo inteiro. Se a internet cair ou o provedor cortar, continua do mesmo ponto."""
        meta = item.get("meta") or {}
        attempt = 0
        # 1) descobre o tipo (arquivo direto ou HLS) e cria o arquivo, só na primeira vez
        while not item.get("mode"):
            if job.stop.is_set():
                return
            try:
                resp, headers = self._open(item)
                first = resp.read(CHUNK)
                ctype = resp.headers.get("Content-Type", "").lower()
                final = resp.geturl()
                base = safe_name(meta.get("fileName") or item["name"])
                if "mpegurl" in ctype or first.lstrip().startswith(b"#EXTM3U"):
                    resp.close()
                    path = self._unique(self._folder(False) / f"{base}.ts")
                    path.touch()
                    self._set(item["id"], file=str(path), mode="hls", seg=0, segBytes=0, done=0)
                else:
                    ext = Path(urllib.parse.urlsplit(final).path).suffix.lower().lstrip(".") or meta.get("ext") or "mp4"
                    if ext in ("php", "") or len(ext) > 5:
                        ext = meta.get("ext") or "mp4"
                    total = int(resp.headers.get("Content-Length") or 0)
                    path = self._unique(self._folder(False) / f"{base}.{ext}")
                    with open(path, "wb") as out:
                        out.write(first)
                    self._set(item["id"], file=str(path), mode="file", total=total, done=len(first))
                    # aproveita a conexão já aberta
                    self._pump(item, job, resp, path, len(first))
            except Exception:  # noqa: BLE001
                attempt += 1
                if not self._wait(item, job, attempt):
                    return
        if item["mode"] == "hls":
            self._hls_resumable(item, job)
        else:
            self._file_resumable(item, job)

    def _pump(self, item, job, resp, path, done):
        """Copia a resposta para o fim do arquivo; devolve quantos bytes o arquivo tem."""
        last = 0
        with resp, open(path, "ab") as out:
            while not job.stop.is_set():
                chunk = resp.read(CHUNK)
                if not chunk:
                    break
                out.write(chunk)
                done += len(chunk)
                if time.time() - last > 1:
                    last = time.time()
                    self._set(item["id"], done=done, note="")
        self._set(item["id"], done=done)
        return done

    def _file_resumable(self, item, job):
        path = Path(item["file"])
        attempt = 0
        probes = 0
        while not job.stop.is_set():
            done = path.stat().st_size if path.exists() else 0
            total = int(item.get("total") or 0)
            self._set(item["id"], done=done)
            if total and done >= total:
                return
            try:
                resp, _ = self._open(item, {"Range": f"bytes={done}-"} if done else None)
            except urllib.error.HTTPError as exc:
                if exc.code == 416 and done:
                    # o servidor diz que não há mais nada depois disso: está completo
                    self._set(item["id"], total=done, done=done)
                    return
                attempt += 1
                if not self._wait(item, job, attempt, f"O provedor recusou ({exc.code}). Tentando de novo…"):
                    return
                continue
            except Exception:  # noqa: BLE001
                attempt += 1
                if not self._wait(item, job, attempt):
                    return
                continue
            code = resp.getcode()
            if code == 206:
                m = re.search(r"/(\d+)", resp.headers.get("Content-Range", ""))
                if m:
                    self._set(item["id"], total=int(m.group(1)))
            elif code == 200:
                length = int(resp.headers.get("Content-Length") or 0)
                if length:
                    self._set(item["id"], total=length)
                if done:
                    if length and done >= length:
                        resp.close()
                        self._set(item["id"], total=length)
                        return
                    # servidor sem retomada: pula o que já temos, sem perder o progresso
                    try:
                        skip = done
                        while skip > 0 and not job.stop.is_set():
                            got = resp.read(min(CHUNK, skip))
                            if not got:
                                break
                            skip -= len(got)
                        if skip > 0:
                            resp.close()
                            raise OSError("conexão caiu")
                    except Exception:  # noqa: BLE001
                        attempt += 1
                        if not self._wait(item, job, attempt):
                            return
                        continue
            before = done
            try:
                done = self._pump(item, job, resp, path, done)
            except Exception:  # noqa: BLE001
                done = path.stat().st_size if path.exists() else before
            if job.stop.is_set():
                return
            total = int(self.get(item["id"]).get("total") or 0)
            if total and done >= total:
                return
            if done > before:
                attempt = 0                       # andou: zera a espera
            if not total:
                # sem tamanho informado: confirma pedindo o que vier depois (416 = acabou)
                probes += 1
                if probes > 3 and done == before:
                    self._set(item["id"], total=done)
                    return
                continue
            attempt += 1
            if not self._wait(item, job, attempt, "A conexão caiu no meio. Continuando de onde parou…" if done > before else OFFLINE_NOTE):
                return

    def _hls_resumable(self, item, job):
        """HLS (m3u8): baixa trecho por trecho e guarda quantos já foram, para continuar depois."""
        path = Path(item["file"])
        attempt = 0
        while not job.stop.is_set():
            try:
                resp, headers = self._open(item)
                final = resp.geturl()
                text = resp.read().decode("utf-8", "replace")
                resp.close()
                if "#EXT-X-STREAM-INF" in text:
                    best, best_bw = None, -1
                    lines = text.splitlines()
                    for i, line in enumerate(lines):
                        if line.startswith("#EXT-X-STREAM-INF"):
                            bw = int(_attrs(line).get("BANDWIDTH", "0").strip('"') or 0)
                            for nxt in lines[i + 1:]:
                                if nxt.strip() and not nxt.startswith("#"):
                                    if bw > best_bw:
                                        best, best_bw = urllib.parse.urljoin(final, nxt.strip()), bw
                                    break
                    if not best:
                        raise net.FetchError("Playlist sem variantes reproduzíveis")
                    final = best
                    text = net.fetch_text(best, headers=headers)
                break
            except net.FetchError as exc:
                if "variantes" in str(exc):
                    raise
                attempt += 1
            except Exception:  # noqa: BLE001
                attempt += 1
            if not self._wait(item, job, attempt):
                return
        if job.stop.is_set():
            return
        if "#EXT-X-KEY" in text and "METHOD=NONE" not in text:
            raise net.FetchError("Este conteúdo é criptografado e não pode ser baixado")
        segs = [urllib.parse.urljoin(final, s.strip()) for s in text.splitlines() if s.strip() and not s.startswith("#")]
        if not segs:
            raise net.FetchError("A playlist não tem trechos de vídeo")
        it = self.get(item["id"])
        seg, seg_bytes = int(it.get("seg") or 0), int(it.get("segBytes") or 0)
        # descarta um trecho que tenha ficado pela metade
        with open(path, "r+b") as f:
            f.truncate(seg_bytes)
        done = seg_bytes
        attempt = 0
        last = 0
        with open(path, "ab") as out:
            while seg < len(segs) and not job.stop.is_set():
                try:
                    data = net.fetch_bytes(segs[seg], headers=headers, timeout=40)
                except Exception:  # noqa: BLE001
                    attempt += 1
                    if not self._wait(item, job, attempt):
                        return
                    continue
                attempt = 0
                out.write(data)
                out.flush()
                done += len(data)
                seg += 1
                est = int(done / seg * len(segs))
                self._set(item["id"], seg=seg, segBytes=done, done=done, total=est if seg < len(segs) else done)
                if time.time() - last > 5:
                    last = time.time()
                    with self.lock:
                        self.store.save()
                        self._set(item["id"], note="")

    @staticmethod
    def _unique(path):
        if not path.exists():
            return path
        stem, suf = path.stem, path.suffix
        for i in range(2, 999):
            p = path.with_name(f"{stem} ({i}){suf}")
            if not p.exists():
                return p
        return path

    def _time_up(self, item):
        ends = self.get(item["id"]).get("endsAt")
        return bool(ends) and time.time() >= ends

    def _copy(self, item, job, resp, first, path, rec):
        done = 0
        last = 0
        with resp, open(path, "wb") as out:
            chunk = first
            while chunk:
                out.write(chunk)
                done += len(chunk)
                if time.time() - last > 1:
                    last = time.time()
                    self._set(item["id"], done=done)
                if job.stop.is_set() or (rec and self._time_up(item)):
                    break
                chunk = resp.read(CHUNK)
        self._set(item["id"], done=done, total=done if not rec else 0)

    def _hls(self, item, job, text, base_url, path, headers, rec):
        # escolhe a melhor variante de uma playlist mestre
        if "#EXT-X-STREAM-INF" in text:
            best, best_bw = None, -1
            lines = text.splitlines()
            for i, line in enumerate(lines):
                if line.startswith("#EXT-X-STREAM-INF"):
                    bw = int(_attrs(line).get("BANDWIDTH", "0").strip('"') or 0)
                    for nxt in lines[i + 1:]:
                        if nxt.strip() and not nxt.startswith("#"):
                            if bw > best_bw:
                                best, best_bw = urllib.parse.urljoin(base_url, nxt.strip()), bw
                            break
            if not best:
                raise net.FetchError("Playlist sem variantes reproduzíveis")
            base_url = best
            text = net.fetch_text(best, headers=headers)
        seen = set()
        done = 0
        last = 0
        with open(path, "wb") as out:
            while True:
                if "#EXT-X-KEY" in text and "METHOD=NONE" not in text:
                    raise net.FetchError("Este conteúdo é criptografado e não pode ser baixado")
                segs = []
                target = 6
                for line in text.splitlines():
                    s = line.strip()
                    if s.startswith("#EXT-X-TARGETDURATION:"):
                        target = max(1, int(float(s.split(":", 1)[1] or 6)))
                    elif s and not s.startswith("#"):
                        segs.append(urllib.parse.urljoin(base_url, s))
                new = [u for u in segs if u not in seen]
                total_segs = len(segs)
                for idx, seg in enumerate(new):
                    if job.stop.is_set() or (rec and self._time_up(item)):
                        return
                    data = net.fetch_bytes(seg, headers=headers, timeout=40)
                    out.write(data)
                    done += len(data)
                    seen.add(seg)
                    if time.time() - last > 1:
                        last = time.time()
                        if rec:
                            self._set(item["id"], done=done)
                        else:
                            self._set(item["id"], done=done, total=int(done / max(1, len(seen)) * total_segs))
                if not rec or "#EXT-X-ENDLIST" in text:
                    self._set(item["id"], done=done, total=done)
                    return
                for _ in range(target * 2):
                    if job.stop.is_set() or self._time_up(item):
                        return
                    time.sleep(0.5)
                text = net.fetch_text(base_url, headers=headers)
