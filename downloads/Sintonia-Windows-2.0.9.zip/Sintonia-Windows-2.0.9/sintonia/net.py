"""Acesso HTTP aos provedores (somente biblioteca padrão)."""

import gzip
import json
import ssl
import urllib.error
import urllib.request
import zlib

# Muitos provedores IPTV só liberam a TV ao vivo para players conhecidos (VLC, apps de IPTV)
# e recusam User-Agent de navegador. Por isso o padrão imita o VLC.
DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/138.0 Safari/537.36")

_state = {"ua": DEFAULT_UA}

_insecure = ssl.create_default_context()
_insecure.check_hostname = False
_insecure.verify_mode = ssl.CERT_NONE


def set_user_agent(ua):
    _state["ua"] = ua.strip() if ua and ua.strip() else DEFAULT_UA


def user_agent():
    return _state["ua"]


class FetchError(Exception):
    pass


def _is_ssl_error(exc):
    reason = getattr(exc, "reason", exc)
    return isinstance(reason, ssl.SSLError) or isinstance(exc, ssl.SSLError)


def open_url(url, headers=None, timeout=25, data=None, method=None):
    """Abre a URL. Muitos servidores IPTV têm certificado vencido: tenta de novo sem validar."""
    h = {"User-Agent": user_agent(), "Accept": "*/*", "Accept-Encoding": "identity"}
    if headers:
        h.update({k: v for k, v in headers.items() if v is not None})
    req = urllib.request.Request(url, headers=h, data=data, method=method)
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError:
        raise
    except Exception as exc:  # noqa: BLE001
        if url.lower().startswith("https") and _is_ssl_error(exc):
            return urllib.request.urlopen(req, timeout=timeout, context=_insecure)
        raise


def _decode_body(raw, encoding):
    encoding = (encoding or "").lower()
    if encoding == "gzip" or raw[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(raw)
        except OSError:
            return raw
    if encoding == "deflate":
        try:
            return zlib.decompress(raw)
        except zlib.error:
            return zlib.decompress(raw, -zlib.MAX_WBITS)
    return raw


def fetch_bytes(url, headers=None, timeout=30, max_bytes=None):
    try:
        with open_url(url, headers=headers, timeout=timeout) as resp:
            raw = resp.read(max_bytes) if max_bytes else resp.read()
            return _decode_body(raw, resp.headers.get("Content-Encoding"))
    except urllib.error.HTTPError as exc:
        raise FetchError(f"O servidor respondeu {exc.code} ({exc.reason})") from exc
    except urllib.error.URLError as exc:
        raise FetchError(f"Não foi possível conectar: {exc.reason}") from exc
    except (TimeoutError, OSError) as exc:
        raise FetchError(f"Falha de rede: {exc}") from exc


def fetch_text(url, headers=None, timeout=30):
    raw = fetch_bytes(url, headers=headers, timeout=timeout)
    for enc in ("utf-8-sig", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def fetch_json(url, headers=None, timeout=30):
    text = fetch_text(url, headers=headers, timeout=timeout).strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except ValueError as exc:
        raise FetchError("Resposta inválida do servidor (não é JSON)") from exc
