// Peças compartilhadas pelas telas de navegação.
import { api } from '../api.js';
import { diagnose, openPlayer } from '../player.js';
import {
  KIND_LABEL, S, SORT_LABEL, base, canResume, catalog, emit, isFav, isLocked, isBlocked, loadCatalog, progressOf,
  s24, saveSettings, sectionPrefs, sortMode, toggleFav, visibleCategories,
} from '../state.js';
import { btn, clear, copyText, debounce, downloadText, fmtTime, h, ic, iconBtn, menu, modal, pic, pinBox, toast } from '../ui.js';

export const ROUTE_OF = { live: 'live', movie: 'movies', series: 'series' };

// ---------------------------------------------------------------- cabeçalho de seção
export function sectionHeader(title, { search, onSearch, actions = [], back, middle } = {}) {
  const head = h('header.view-head');
  const left = h('div.view-title');
  left.append(h('button.icon-btn.only-mobile.drawer-btn', { type: 'button', 'aria-label': 'Abrir menu', onclick: () => document.body.classList.toggle('drawer') }, ic('menu')));
  if (back) left.append(iconBtn('arrowL', 'Voltar', back));
  left.append(h('h1', title));
  head.append(left);
  if (middle) head.append(middle);
  const right = h('div.view-tools');
  if (onSearch) {
    const input = h('input', { type: 'search', placeholder: search || 'Pesquisar', value: '', 'aria-label': search || 'Pesquisar', autocomplete: 'off' });
    input.addEventListener('input', debounce(() => onSearch(input.value.trim()), 180));
    right.append(h('label.search-box', ic('search'), input));
  }
  actions.forEach((a) => right.append(a));
  head.append(right);
  return head;
}

// ---------------------------------------------------------------- categorias
export async function chooseCategory(kind, catId) {
  if (catId && isBlocked(kind, catId)) {
    const pin = await pinBox('Categoria bloqueada');
    if (pin === null) return false;
    const r = await api.post('/api/parental/verify', { pin });
    if (!r.ok) { toast('PIN incorreto', { type: 'error' }); return false; }
    S.unlocked.add(`${kind}:${catId}`);
  }
  S.cat[kind] = catId;
  emit('cat');
  return true;
}

export function categoryMenu(kind, c) {
  const pinned = (S.user.pinned[kind] || []).includes(c.id);
  const locked = isLocked(kind, c.id);
  const key = kind === 'movie' ? 'movies' : kind;
  const isDefault = S.settings[key]?.defaultCat === c.id;
  return menu([
    { label: pinned ? 'Tirar dos atalhos' : 'Fixar nos atalhos', icon: 'pin', fn: async () => {
      S.user.pinned = await api.post(`${base()}/user/pinned`, { kind, cat: c.id, on: !pinned }); emit('cats');
    } },
    { label: isDefault ? 'Não abrir mais nesta categoria' : 'Abrir sempre nesta categoria', icon: 'check', fn: () => saveSettings({ [key]: { defaultCat: isDefault ? '' : c.id } }) },
    { label: locked ? 'Desbloquear categoria' : 'Bloquear com PIN', icon: locked ? 'unlock' : 'lock', fn: () => lockCategory(kind, c.id, !locked) },
    { label: 'Ocultar categoria', icon: 'eyeOff', fn: async () => {
      S.user.hidden = await api.post(`${base()}/user/hidden`, { kind, cat: c.id, on: true });
      if (S.cat[kind] === c.id) S.cat[kind] = null;
      emit('cats');
      toast('Categoria oculta. Para mostrar de novo, use a engrenagem ao lado de "Todas".');
    } },
  ], { title: c.name });
}

export async function lockCategory(kind, cat, on) {
  if (!S.parental.hasPin) {
    toast('Crie um PIN em Menu › Controle parental primeiro.');
    location.hash = '#/menu/parental';
    return;
  }
  const pin = await pinBox(on ? 'Bloquear categoria' : 'Desbloquear categoria');
  if (pin === null) return;
  try {
    S.parental = await api.post('/api/parental/lock', { pin, src: S.active, kind, cat, on });
    if (!on) S.unlocked.delete(`${kind}:${cat}`);
    if (on && S.cat[kind] === cat) S.cat[kind] = null;
    emit('cats');
    toast(on ? 'Categoria bloqueada' : 'Categoria desbloqueada');
  } catch (e) { toast(e.message, { type: 'error' }); }
}

export function manageCategories(kind) {
  const c = catalog(kind);
  if (!c) return;
  const hidden = new Set(S.user.hidden[kind] || []);
  const list = h('div.manage-list');
  const filter = h('input.input', { type: 'search', placeholder: 'Filtrar categorias' });
  const draw = () => {
    clear(list);
    const q = filter.value.toLowerCase();
    c.categories.filter((x) => !q || x.name.toLowerCase().includes(q)).forEach((x) => {
      const cb = h('input', { type: 'checkbox' });
      cb.checked = !hidden.has(x.id);
      cb.addEventListener('change', () => { if (cb.checked) hidden.delete(x.id); else hidden.add(x.id); });
      list.append(h('label.manage-row', cb, h('span', x.name), isLocked(kind, x.id) ? ic('lock', 'muted') : null));
    });
  };
  filter.addEventListener('input', draw);
  draw();
  {
    const m = modal(h('div',
      h('p.hint', 'Desmarque as categorias que você não quer ver.'),
      filter, list,
      h('div.modal-actions',
        btn('Mostrar todas', { cls: 'ghost', onclick: () => { hidden.clear(); draw(); } }),
        btn('Salvar', { cls: 'primary', onclick: async () => {
          S.user.hidden = await api.post(`${base()}/user/hidden-bulk`, { kind, cats: [...hidden] });
          if (hidden.has(S.cat[kind])) S.cat[kind] = null;
          m.close();
          emit('cats');
        } }))), { title: `Categorias de ${KIND_LABEL[kind]}`, cls: 'wide' });
  }
}

/** Painel de categorias da barra lateral. */
export function catPanel(kind) {
  const wrap = h('div.cat-panel', h('div.catcol-title', 'Categorias'));
  const list = h('div.cat-list', { role: 'listbox', 'aria-label': 'Categorias' });
  const filter = h('input', { type: 'search', placeholder: 'Filtrar categorias', 'aria-label': 'Filtrar categorias' });
  const draw = () => {
    clear(list);
    const c = catalog(kind);
    if (!c) return;
    const q = filter.value.toLowerCase();
    const all = h('div.cat-item.all', { class: S.cat[kind] ? '' : 'on' },
      h('button.cat-name', { type: 'button', onclick: async () => { await chooseCategory(kind, null); document.body.classList.remove('drawer', 'catdrawer'); } }, 'Todas'),
      iconBtn('gear', 'Organizar categorias', () => manageCategories(kind)));
    if (!q) list.append(all);
    visibleCategories(kind).filter((x) => !q || x.name.toLowerCase().includes(q)).forEach((x) => {
      const locked = isLocked(kind, x.id);
      const row = h('div.cat-item', { class: S.cat[kind] === x.id ? 'on' : '' },
        h('button.cat-name', { type: 'button', title: x.name, onclick: async () => {
          if (await chooseCategory(kind, x.id)) document.body.classList.remove('drawer', 'catdrawer');
        } }, x.name, locked ? ic('lock', 'cat-lock') : null),
        iconBtn('more', 'Opções da categoria', () => categoryMenu(kind, x)));
      row.addEventListener('contextmenu', (e) => { e.preventDefault(); categoryMenu(kind, x); });
      list.append(row);
    });
    const on = list.querySelector('.cat-item.on');
    if (on && !q) on.scrollIntoView({ block: 'nearest' });
  };
  filter.addEventListener('input', draw);
  wrap.append(list, h('label.cat-filter', filter, ic('search')));
  wrap.redraw = draw;
  draw();
  return wrap;
}

// ---------------------------------------------------------------- barra de filtros
export function chipsRow(kind, onChange) {
  const row = h('div.chips');
  const draw = () => {
    clear(row);
    const mode = sortMode(kind);
    row.append(h('button.chip.sort', { type: 'button', title: `Ordenar: ${SORT_LABEL[mode]}`, onclick: async () => {
      const opts = kind === 'live' ? ['default', 'az', 'za', 'added'] : ['default', 'az', 'za', 'added', 'rating', 'year'];
      const ch = await menu(opts.map((m) => ({ label: SORT_LABEL[m], value: m, checked: m === mode })), { title: 'Ordenar por' });
      if (ch) { await saveSettings({ lastSort: { ...S.settings.lastSort, [kind]: ch.value } }); onChange(); draw(); }
    } }, ic('sort'), h('span.chip-txt', mode === 'default' ? 'Ordem' : SORT_LABEL[mode].replace(' (mais novos)', ''))));
    row.append(h('span.chips-sep'));
    row.append(h('button.chip.fav', { type: 'button', class: S.favOnly[kind] ? 'on' : '', title: 'Só favoritos', 'aria-pressed': String(S.favOnly[kind]),
      onclick: () => { S.favOnly[kind] = !S.favOnly[kind]; onChange(); draw(); } }, ic('star', S.favOnly[kind] ? 'filled' : '')));
    const c = catalog(kind);
    (S.user.pinned[kind] || []).forEach((id) => {
      const name = c?.catName?.get(id);
      if (!name) return;
      row.append(h('button.chip', { type: 'button', class: S.cat[kind] === id ? 'on' : '', title: name,
        onclick: () => chooseCategory(kind, S.cat[kind] === id ? null : id) }, h('span.chip-txt', name.length > 14 ? name.slice(0, 13) + '…' : name)));
    });
    const cur = S.cat[kind] ? c?.catName?.get(S.cat[kind]) : null;
    row.append(h('button.chip.only-mobile.cat-chip', { type: 'button', onclick: () => document.body.classList.add('catdrawer') },
      ic('listCheck'), h('span.chip-txt', cur || 'Categorias')));
  };
  draw();
  row.redraw = draw;
  return row;
}

// ---------------------------------------------------------------- canais
export function channelMenu(ch, list) {
  const fav = isFav('live', ch.id);
  menu([
    { label: fav ? 'Remover dos favoritos' : 'Adicionar aos favoritos', icon: 'star', fn: async () => { const on = await toggleFav('live', ch.id); toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos'); } },
    { label: 'Programação e replay', icon: 'guide', fn: () => channelGuide(ch, list) },
    { label: 'Abrir em multitela', icon: 'gridPlus', fn: () => { if (!S.multi.some((x) => x?.id === ch.id)) S.multi.push(ch); S.multi = S.multi.slice(-4); location.hash = '#/multi'; } },
    { label: 'Gravar agora', icon: 'record', fn: () => quickRecord(ch) },
    null,
    { label: 'Diagnosticar canal', icon: 'info', fn: () => diagnose(ch) },
    { label: 'Abrir no VLC', icon: 'external', fn: () => externalPlay('live', ch) },
    { label: 'Copiar link', icon: 'copy', fn: async () => { const r = await api.post(`${base()}/play`, { kind: 'live', ref: { id: ch.id, cmd: ch.cmd } }); copyText(r.direct); } },
  ], { title: ch.name });
}

export async function externalPlay(kind, item) {
  try {
    const r = await api.post(`${base()}/play`, { kind, ref: kind === 'episode' ? item : { id: item.id, ext: item.ext, cmd: item.cmd } });
    const url = r.direct.startsWith('http') ? r.direct : location.origin + r.url;
    downloadText(`${(item.name || item.title || 'video').replace(/[^\w\- ]/g, '').slice(0, 40)}.m3u`, `#EXTM3U\n#EXTINF:-1,${item.name || item.title}\n${url}\n`);
  } catch (e) { toast(e.message, { type: 'error' }); }
}

async function quickRecord(ch) {
  const choice = await menu([{ label: '30 minutos', minutes: 30 }, { label: '1 hora', minutes: 60 }, { label: '2 horas', minutes: 120 },
    { label: 'Até eu parar', minutes: 0 }].map((o) => ({ ...o, icon: 'record' })), { title: `Gravar ${ch.name}` });
  if (!choice) return;
  try {
    await api.post('/api/recordings', { src: S.active, ref: { id: ch.id, cmd: ch.cmd, url: ch.url }, meta: { name: ch.name, img: ch.logo }, minutes: choice.minutes });
    toast('Gravando no servidor. Acompanhe em Offline › Gravações.');
  } catch (e) { toast(e.message, { type: 'error' }); }
}

export async function channelGuide(ch, list) {
  const body = h('div.prog-list', h('div.loading', h('span.spin')));
  const m = modal(body, { title: ch.name, cls: 'wide' });
  try {
    const now = Math.floor(Date.now() / 1000);
    const r = await api.post(`${base()}/epg/channel`, { channel: { id: ch.id, epg: ch.epg, name: ch.name }, from: now - 7 * 86400, to: now + 2 * 86400 });
    clear(body);
    const progs = (r.data || []).filter((p) => p.stop > now - (ch.archive ? (ch.archive_days || 3) * 86400 : 3 * 3600));
    if (!progs.length) { body.append(h('p.muted.pad', r.status?.loading ? 'O guia ainda está carregando. Tente em instantes.' : 'Sem programação disponível para este canal.')); return; }
    let lastDay = '';
    progs.forEach((p) => {
      const day = new Date(p.start * 1000).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit' });
      if (day !== lastDay) { body.append(h('div.prog-day', day)); lastDay = day; }
      const isNow = p.start <= now && now < p.stop;
      const past = p.stop <= now;
      const row = h('div.prog-row', { class: isNow ? 'now' : past ? 'past' : '' },
        h('div.prog-time', fmtTime(p.start, s24()), h('small', fmtTime(p.stop, s24()))),
        h('div.prog-txt', h('strong', p.title), p.desc ? h('small', p.desc) : null));
      if (isNow) row.append(h('button.btn.primary.sm', { type: 'button', onclick: () => { m.close(); openPlayer({ kind: 'live', item: ch, list }); } }, ic('play'), h('span', 'Ao vivo')));
      else if (past && ch.archive) row.append(h('button.btn.ghost.sm', { type: 'button', onclick: () => { m.close(); openPlayer({ kind: 'catchup', item: ch, program: p, list }); } }, ic('replay'), h('span', 'Replay')));
      body.append(row);
    });
    body.querySelector('.now')?.scrollIntoView({ block: 'center' });
  } catch (e) { clear(body).append(h('p.muted.pad', e.message)); }
}

export function channelRow(ch, list, rowsMap) {
  const prog = h('div.ch-prog');
  const bar = h('div.bar', h('i'));
  const fav = isFav('live', ch.id);
  const favBtn = h('button.icon-btn.ch-fav', { type: 'button', class: fav ? 'fav-on' : '', 'aria-label': 'Favorito',
    onclick: async (e) => { e.stopPropagation(); const on = await toggleFav('live', ch.id); favBtn.classList.toggle('fav-on', on); clear(favBtn).append(ic('star', on ? 'filled' : '')); } },
  ic('star', fav ? 'filled' : ''));
  const row = h('div.ch-row', { tabindex: '0', role: 'button', 'aria-label': ch.name },
    pic(ch.logo, ch.name, 'ch-logo'),
    h('div.ch-main', h('div.ch-name', ch.num ? h('span.ch-num', String(ch.num)) : null, h('span', ch.name), ch.archive ? h('span.tag', { title: 'Tem replay' }, ic('replay')) : null), prog, bar),
    favBtn,
    h('button.icon-btn.ch-more', { type: 'button', 'aria-label': 'Mais opções', onclick: (e) => { e.stopPropagation(); channelMenu(ch, list); } }, ic('more')));
  const play = () => openPlayer({ kind: 'live', item: ch, list });
  row.addEventListener('click', play);
  row.addEventListener('keydown', (e) => { if (e.key === 'Enter') play(); });
  row.addEventListener('contextmenu', (e) => { e.preventDefault(); channelMenu(ch, list); });
  if (rowsMap) rowsMap.set(ch.id, { prog, bar, row });
  return row;
}

/** Preenche "agora/próximo" nas linhas de canal. */
export function epgFiller(rowsMap) {
  const cache = new Map();
  let timer = null;
  const paint = () => {
    const now = Date.now() / 1000;
    rowsMap.forEach((r, id) => {
      const nn = cache.get(id);
      if (!nn) return;
      let [cur, nxt] = nn;
      if (cur && now >= cur.stop) { cur = nxt && nxt.start <= now ? nxt : null; }
      clear(r.prog);
      if (cur) {
        r.prog.append(h('span', cur.title));
        r.bar.firstChild.style.width = Math.min(100, ((now - cur.start) / (cur.stop - cur.start)) * 100) + '%';
        r.row.classList.add('has-epg');
      } else if (nxt) {
        r.prog.append(h('span.muted', `${fmtTime(nxt.start, s24())} ${nxt.title}`));
      }
    });
  };
  const fetchBatch = async (channels, retries = 3) => {
    if (!channels.length || !S.settings.epg.enabled) return;
    try {
      const r = await api.post(`${base()}/epg/now`, { channels: channels.map((c) => ({ id: c.id, epg: c.epg, name: c.name })) });
      Object.entries(r.data || {}).forEach(([id, nn]) => cache.set(id, nn));
      paint();
      if (r.status && r.status.loading && retries > 0) setTimeout(() => fetchBatch(channels, retries - 1), 4000);
    } catch { /* sem guia */ }
  };
  timer = setInterval(paint, 30000);
  return {
    add(batch) {
      for (let i = 0; i < batch.length; i += 150) fetchBatch(batch.slice(i, i + 150));
    },
    destroy() { clearInterval(timer); },
  };
}

// ---------------------------------------------------------------- capas
export function posterCard(kind, it, opts = {}) {
  const fav = isFav(kind, it.id);
  const prog = kind === 'movie' ? progressOf('movie', it.id) : null;
  const card = h('a.poster', { href: kind === 'movie' ? `#/movie/${encodeURIComponent(it.id)}` : `#/serie/${encodeURIComponent(it.id)}`, title: it.name },
    h('div.poster-art', pic(it.poster, it.name, 'cover'),
      opts.rank ? h('span.rank', `#${opts.rank}`) : null,
      fav ? h('span.poster-fav', ic('star', 'filled')) : null,
      it.rating ? h('span.poster-rate', ic('star', 'filled'), String(it.rating).replace('.', ',')) : null,
      prog && prog.dur ? h('div.poster-prog', h('i', { style: { width: Math.min(100, (prog.pos / prog.dur) * 100) + '%' } })) : null),
    h('div.poster-meta', h('strong', it.name.replace(/\s*[([](19|20)\d\d[)\]]\s*$/, '')), it.year ? h('small', String(it.year)) : null));
  return card;
}

/** Itens de "continuar assistindo", um por filme ou por série (séries agrupadas contam uma vez). */
export function continueEntries(kind) {
  const hist = S.user?.history || [];
  if (kind === 'movie') return hist.filter((x) => x.kind === 'movie' && canResume(x)).slice(0, 20);
  const cat = catalog('series');
  const seen = new Set();
  const out = [];
  for (const x of hist) {
    if (x.kind !== 'episode') continue;
    const group = cat?.byId.get(String(x.seriesId));
    const key = group ? group.id : String(x.seriesId);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ ...x, seriesId: key, seriesName: group ? group.name : x.seriesName, img: group?.poster || x.img, _ids: [String(x.seriesId), key] });
    if (out.length >= 20) break;
  }
  return out;
}

export function continueCard(entry, onRemove) {
  const pct = entry.dur ? Math.min(100, (entry.pos / entry.dur) * 100) : 0;
  const isEp = entry.kind === 'episode';
  const href = isEp ? `#/serie/${encodeURIComponent(entry.seriesId)}` : `#/movie/${encodeURIComponent(entry.id)}`;
  const title = (isEp ? entry.seriesName : entry.name || '').replace(/\s*[([](19|20)\d\d[)\]]\s*$/, '');
  const left = entry.dur ? Math.max(1, Math.round((entry.dur - entry.pos) / 60)) : 0;
  return h('a.cont-card', { href, title },
    h('div.cont-art', pic(entry.img, title, 'cover'), h('div.poster-prog', h('i', { style: { width: pct + '%' } })), h('span.cont-play', ic('play')),
      onRemove ? h('button.cont-x', { type: 'button', title: 'Tirar da lista', 'aria-label': 'Tirar da lista', onclick: (e) => { e.preventDefault(); e.stopPropagation(); onRemove(entry); } }, ic('close')) : null),
    h('div.cont-meta', h('strong', title), h('small', isEp ? `T${entry.season} · E${entry.episode}${left ? ` · ${left} min` : ''}` : `Restam ${left} min`)));
}

/** Faixa com os 4 últimos vídeos vistos, no topo ao lado do título. */
export function continueStrip(kind) {
  const strip = h('div.cont-strip', { 'aria-label': 'Continuar assistindo' });
  strip.sync = () => {
    clear(strip);
    const items = sectionPrefs(kind).showRecent ? continueEntries(kind).slice(0, 4) : [];
    strip.hidden = !items.length;
    items.forEach((e) => {
      const isEp = e.kind === 'episode';
      const title = (isEp ? e.seriesName : e.name || '').replace(/\s*[([](19|20)\d\d[)\]]\s*$/, '');
      const pct = e.dur ? Math.min(100, (e.pos / e.dur) * 100) : 0;
      const href = isEp ? `#/serie/${encodeURIComponent(e.seriesId)}` : `#/movie/${encodeURIComponent(e.id)}`;
      strip.append(h('a.cs-tile', { href, title: `Continuar ${title}` },
        pic(e.img, title, 'cover'),
        h('span.cs-shade'),
        h('span.cs-play', ic('play')),
        h('span.cs-txt', h('strong', title), h('small', isEp ? `T${e.season} · E${e.episode}` : `${Math.max(1, Math.round((e.dur - e.pos) / 60))} min restantes`)),
        h('span.cs-bar', h('i', { style: { width: pct + '%' } })),
        h('button.cs-x', { type: 'button', title: 'Tirar de Continuar assistindo', 'aria-label': 'Tirar de Continuar assistindo',
          onclick: async (ev) => {
            ev.preventDefault(); ev.stopPropagation();
            S.user.history = await api.post(`${base()}/user/forget`, { ids: e._ids || [e.id] });
            window.dispatchEvent(new Event('sintonia:continue'));
          } }, ic('close'))));
    });
  };
  strip.sync();
  window.addEventListener('sintonia:continue', () => { if (strip.isConnected) strip.sync(); });
  return strip;
}

/** Botão no topo que abre o painel flutuante "Continuar assistindo". */
export function continueButton(kind) {
  const count = h('span.badge');
  const btnEl = h('button.cont-btn', { type: 'button', 'aria-haspopup': 'true', 'aria-expanded': 'false', title: 'Continuar assistindo' },
    ic('history'), h('span.cont-btn-txt', 'Continuar'), count);
  let pop = null;
  const sync = () => {
    const n = continueEntries(kind).length;
    count.textContent = String(n);
    btnEl.hidden = !n || !sectionPrefs(kind).showRecent;
  };
  window.addEventListener('sintonia:continue', () => { if (btnEl.isConnected) sync(); });
  const close = () => {
    if (!pop) return;
    pop.remove();
    pop = null;
    btnEl.setAttribute('aria-expanded', 'false');
    document.removeEventListener('pointerdown', outside, true);
    document.removeEventListener('keydown', esc, true);
  };
  const outside = (e) => { if (pop && !pop.contains(e.target) && !btnEl.contains(e.target)) close(); };
  const esc = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  const draw = () => {
    const row = pop.querySelector('.cont-pop-row');
    clear(row);
    const items = continueEntries(kind);
    if (!items.length) { close(); sync(); return; }
    items.forEach((e) => row.append(continueCard(e, async (entry) => {
      S.user.history = await api.post(`${base()}/user/forget`, { ids: entry._ids || [entry.id] });
      draw();
      sync();
      window.dispatchEvent(new Event('sintonia:continue'));
    })));
  };
  btnEl.addEventListener('click', () => {
    if (pop) { close(); return; }
    pop = h('div.cont-pop', { role: 'dialog', 'aria-label': 'Continuar assistindo' },
      h('div.cont-pop-head', h('strong', 'Continuar assistindo'), iconBtn('close', 'Fechar', close)),
      h('div.cont-pop-row'));
    btnEl.closest('.view-head').append(pop);
    btnEl.setAttribute('aria-expanded', 'true');
    draw();
    document.addEventListener('pointerdown', outside, true);
    document.addEventListener('keydown', esc, true);
  });
  sync();
  btnEl.sync = sync;
  return btnEl;
}

export { loadCatalog, KIND_LABEL };
