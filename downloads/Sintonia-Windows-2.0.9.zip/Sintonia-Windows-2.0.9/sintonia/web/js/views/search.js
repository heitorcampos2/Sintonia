import { api } from '../api.js';
import { openPlayer } from '../player.js';
import { base, catalog, itemsFor, loadCatalog, s24 } from '../state.js';
import { chunked, clear, debounce, empty, fmtTime, h, ic, spinner } from '../ui.js';
import { channelRow, epgFiller, posterCard, sectionHeader } from './common.js';

const TABS = [['live', 'TV ao Vivo'], ['epg', 'Programação'], ['movie', 'Filmes'], ['series', 'Séries'], ['cast', 'Atores']];

export function render(root) {
  let q = sessionStorage.getItem('sintonia.q') || '';
  let tab = sessionStorage.getItem('sintonia.qtab') || 'live';
  let chunk = null;
  let filler = null;
  let seq = 0;
  const input = h('input', { type: 'search', placeholder: 'Pesquisar canais, filmes, séries, programas, atores…', value: q, 'aria-label': 'Pesquisar', autocomplete: 'off' });
  const seg = h('div.seg.scroll');
  const out = h('div.search-out');
  root.append(sectionHeader('Pesquisar'), h('div.view-body', h('label.search-box.big', ic('search'), input), seg, out));
  setTimeout(() => input.focus(), 50);

  input.addEventListener('input', debounce(() => {
    q = input.value.trim();
    sessionStorage.setItem('sintonia.q', q);
    // vai para a primeira aba com resultado quando a atual está vazia
    if (q.length >= 2 && ['live', 'movie', 'series'].includes(tab)) {
      const n = (k) => (catalog(k) ? itemsFor(k, { cat: null, favOnly: false, q }).length : 0);
      if (!n(tab)) { const alt = ['live', 'movie', 'series'].find((k) => n(k)); if (alt) tab = alt; }
    }
    draw();
  }, 250));

  function drawTabs(counts = {}) {
    clear(seg);
    TABS.forEach(([id, label]) => seg.append(h('button', { type: 'button', class: tab === id ? 'on' : '',
      onclick: () => { tab = id; sessionStorage.setItem('sintonia.qtab', id); draw(); } }, label, counts[id] !== undefined && q ? h('span.badge', String(counts[id])) : null)));
  }

  async function draw() {
    const my = ++seq;
    if (chunk) chunk.destroy();
    if (filler) filler.destroy();
    clear(out);
    const counts = {};
    if (q.length >= 2) {
      ['live', 'movie', 'series'].forEach((k) => { if (catalog(k)) counts[k] = itemsFor(k, { cat: null, favOnly: false, q }).length; });
    }
    drawTabs(counts);
    if (q.length < 2) { out.append(empty('Comece a digitar para pesquisar')); return; }
    if (tab === 'live' || tab === 'movie' || tab === 'series') {
      const list = itemsFor(tab, { cat: null, favOnly: false, q });
      if (!list.length) {
        const lazy = catalog(tab)?.lazy;
        out.append(empty(`Nada encontrado para "${q}"`, lazy ? 'Neste portal a pesquisa considera só as categorias que você já abriu.' : null));
        return;
      }
      const grid = h(tab === 'live' ? 'div.ch-grid' : 'div.poster-grid');
      out.append(grid);
      if (tab === 'live') {
        const rows = new Map();
        filler = epgFiller(rows);
        chunk = chunked(grid, list, (ch) => channelRow(ch, list, rows), { root: document.querySelector('.main'), onBatch: (b) => filler.add(b) });
      } else {
        chunk = chunked(grid, list, (it) => posterCard(tab, it), { size: 48, root: document.querySelector('.main') });
      }
      return;
    }
    out.append(spinner('Pesquisando…'));
    if (tab === 'epg') {
      const r = await api.get(`${base()}/epg/search?q=${encodeURIComponent(q)}`).catch(() => ({ data: [] }));
      if (my !== seq) return;
      clear(out);
      const live = catalog('live');
      const byEpg = new Map();
      live?.items.forEach((ch) => { if (ch.epg) byEpg.set(ch.epg, ch); });
      const now = Date.now() / 1000;
      const rows = (r.data || []).map((p) => ({ p, ch: byEpg.get(p.channel) })).filter((x) => x.ch);
      if (!rows.length) { out.append(empty(`Nenhum programa com "${q}"`, r.status?.loading ? 'O guia ainda está carregando.' : null)); return; }
      const listEl = h('div.prog-list');
      let lastDay = '';
      rows.forEach(({ p, ch }) => {
        const day = new Date(p.start * 1000).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit' });
        if (day !== lastDay) { listEl.append(h('div.prog-day', day)); lastDay = day; }
        const isNow = p.start <= now && now < p.stop;
        const past = p.stop <= now;
        const act = isNow ? () => openPlayer({ kind: 'live', item: ch, list: [ch] })
          : past && ch.archive ? () => openPlayer({ kind: 'catchup', item: ch, program: p, list: [ch] }) : null;
        listEl.append(h('div.prog-row', { class: (isNow ? 'now ' : past ? 'past ' : '') + (act ? 'click' : ''), onclick: act },
          h('div.prog-time', fmtTime(p.start, s24()), h('small', fmtTime(p.stop, s24()))),
          h('div.prog-txt', h('strong', p.title), h('small', ch.name + (isNow ? ' · agora' : past && ch.archive ? ' · replay disponível' : '')))));
      });
      out.append(listEl);
      return;
    }
    if (tab === 'cast') {
      const r = await api.get(`${base()}/cast?q=${encodeURIComponent(q)}`).catch(() => []);
      if (my !== seq) return;
      clear(out);
      const found = r.map((x) => catalog(x.kind)?.byId.get(x.id) ? { kind: x.kind, it: catalog(x.kind).byId.get(x.id) } : null).filter(Boolean);
      if (!found.length) { out.append(empty(`Nenhum título com "${q}" no elenco`, 'A busca por atores considera os filmes e séries que já tiveram os detalhes abertos.')); return; }
      const grid = h('div.poster-grid');
      found.forEach(({ kind, it }) => grid.append(posterCard(kind, it)));
      out.append(grid);
    }
  }

  drawTabs();
  out.append(spinner('Preparando a pesquisa…'));
  Promise.allSettled(['live', 'movie', 'series'].map((k) => loadCatalog(k))).then(() => draw());
  return () => { if (chunk) chunk.destroy(); if (filler) filler.destroy(); };
}

