// Multitela: até 4 canais ao mesmo tempo
import { api } from '../api.js';
import { attach } from '../engines.js';
import { S, base, catalog, itemsFor, loadCatalog, visibleCategories } from '../state.js';
import { chunked, clear, empty, h, ic, iconBtn, modal, norm, pic, spinner, toast } from '../ui.js';
import { sectionHeader } from './common.js';

const LAYOUTS = [
  { id: 1, label: '1 tela' }, { id: 2, label: '2 telas' }, { id: 3, label: '3 telas' }, { id: 4, label: '4 telas' },
];

export function render(root) {
  let layout = Math.min(4, Math.max(1, +(sessionStorage.getItem('sintonia.multiLayout') || 0) || Math.max(2, S.multi.filter(Boolean).length)));
  let focus = 0;
  const tiles = [];
  const grid = h('div.multi-grid');
  const layoutSel = h('div.seg.small');
  root.append(sectionHeader('Multitela', { back: () => history.back(), actions: [layoutSel] }), h('div.view-body.multi-body', grid));

  function drawLayoutSel() {
    clear(layoutSel);
    LAYOUTS.forEach((l) => layoutSel.append(h('button', { type: 'button', class: l.id === layout ? 'on' : '',
      onclick: () => { layout = l.id; sessionStorage.setItem('sintonia.multiLayout', l.id); build(); } }, String(l.id))));
  }

  function build() {
    tiles.forEach((t) => t.stop());
    tiles.length = 0;
    clear(grid);
    grid.dataset.n = layout;
    drawLayoutSel();
    for (let i = 0; i < layout; i++) {
      const t = tile(i);
      tiles.push(t);
      grid.append(t.el);
      if (S.multi[i]) t.play(S.multi[i]);
    }
    setFocus(Math.min(focus, layout - 1));
  }

  function setFocus(i) {
    focus = i;
    tiles.forEach((t, k) => { t.el.classList.toggle('focus', k === i); t.video.muted = k !== i; });
  }

  function tile(i) {
    const video = h('video', { playsinline: true, autoplay: true, muted: true });
    video.muted = true;
    const label = h('div.mt-label');
    const status = h('div.mt-status');
    const el = h('div.mt-tile', video, status, label);
    let ctrl = null;
    let ch = null;
    const actions = h('div.mt-actions',
      iconBtn('fullscreen', 'Tela cheia', () => el.requestFullscreen?.()),
      iconBtn('refresh', 'Trocar canal', () => pick()),
      iconBtn('close', 'Fechar', () => { stop(); S.multi[i] = null; showEmpty(); }));
    el.append(actions);
    el.addEventListener('click', (e) => { if (!e.target.closest('button')) setFocus(i); });

    function showEmpty() {
      clear(label);
      clear(status).append(h('button.mt-add', { type: 'button', onclick: () => pick() }, ic('plus'), h('span', 'Escolher canal')));
      el.classList.add('empty');
    }
    async function play(c, fmt) {
      stop();
      ch = c;
      S.multi[i] = c;
      el.classList.remove('empty');
      clear(label).append(pic(c.logo, c.name, 'mini'), h('span', c.name), h('span.mt-audio', ic('volume')));
      clear(status).append(h('span.spin'));
      try {
        const info = await api.post(`${base()}/play`, { kind: 'live', ref: { id: c.id, cmd: c.cmd }, fmt });
        if (ch !== c) return;
        ctrl = await attach(video, info);
        ctrl.onFatal(() => {
          if (!fmt) play(c, info.format === 'm3u8' ? 'ts' : 'm3u8');
          else clear(status).append(h('small', 'Não foi possível reproduzir'));
        });
        video.play().catch(() => {});
      } catch (e) {
        if (!fmt && ch === c) { play(c, S.settings.player.liveFormat === 'm3u8' ? 'ts' : 'm3u8'); return; }
        clear(status).append(h('small', e.message === 'lib-indisponivel' ? 'Componente de vídeo indisponível' : 'Não foi possível reproduzir'));
      }
    }
    function stop() {
      if (ctrl) { ctrl.destroy(); ctrl = null; }
      ch = null;
    }
    function pick() {
      pickChannel((c) => { play(c); setFocus(i); });
    }
    video.addEventListener('playing', () => clear(status));
    showEmpty();
    return { el, video, play, stop };
  }

  grid.append(spinner('Carregando canais…'));
  loadCatalog('live').then(build).catch((e) => clear(grid).append(empty('Não foi possível carregar os canais', e.message)));
  return () => tiles.forEach((t) => t.stop());
}

export function pickChannel(onPick) {
  let cat = '';
  let q = '';
  const list = h('div.pick-list');
  const sel = h('select.select', { 'aria-label': 'Categoria' }, h('option', { value: '' }, 'Todas'), h('option', { value: '__fav' }, '★ Favoritos'),
    ...visibleCategories('live').map((c) => h('option', { value: c.id }, c.name)));
  const input = h('input.input', { type: 'search', placeholder: 'Buscar canal' });
  let ch = null;
  const draw = () => {
    if (ch) ch.destroy();
    clear(list);
    const items = itemsFor('live', { cat: cat && cat !== '__fav' ? cat : null, favOnly: cat === '__fav', q }).filter((x) => !q || norm(x.name).includes(norm(q)));
    if (!items.length) { list.append(h('p.muted.pad', 'Nenhum canal')); return; }
    ch = chunked(list, items, (c) => h('button.pick-row', { type: 'button', onclick: () => { m.close(); onPick(c); } }, pic(c.logo, c.name, 'mini'), h('span', c.name)), { root: list, inside: true });
  };
  sel.addEventListener('change', () => { cat = sel.value; draw(); });
  input.addEventListener('input', () => { q = input.value.trim(); draw(); });
  const m = modal(h('div.pick', h('div.pick-tools', input, sel), list), { title: 'Escolher canal', cls: 'wide' });
  if (!catalog('live')) toast('Carregando canais…');
  draw();
}

