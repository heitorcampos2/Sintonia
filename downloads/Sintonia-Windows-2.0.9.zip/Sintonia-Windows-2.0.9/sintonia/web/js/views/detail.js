// Detalhes de filme e de série
import { api } from '../api.js';
import { openPlayer } from '../player.js';
import { S, base, canResume, catalog, isFav, isFinished, lastEpisodeOf, loadCatalog, progressOf, toggleFav } from '../state.js';
import { btn, clear, copyText, empty, fmtDur, h, ic, imgUrl, menu, pic, spinner, toast } from '../ui.js';
import { externalPlay } from './common.js';

function hero(info, item, kind) {
  const bg = info.backdrop || info.poster || item?.poster || '';
  const name = info.name || item?.name || '';
  const meta = [];
  const year = item?.year || (info.release || '').slice(0, 4);
  if (year) meta.push(String(year));
  if (info.genre) meta.push(info.genre);
  const dur = humanDuration(info.duration, info.durationSecs);
  if (dur) meta.push(dur);
  if (info.country) meta.push(info.country);
  const rating = +(info.rating || item?.rating || 0);
  const genres = String(info.genre || '').split(/\s*[,/|]\s*/).filter(Boolean).slice(0, 3);
  const chips = [];
  if (rating > 0) chips.push(h('span.mchip.rate', String(rating.toFixed(1)).replace('.', ','), ic('star', 'filled')));
  if (year) chips.push(h('span.mchip', String(year)));
  genres.forEach((g) => chips.push(h('span.mchip', g)));
  if (dur) chips.push(h('span.mchip', dur));
  const plot = info.plot || item?.plot || '';
  let plotEl = null;
  if (plot) {
    plotEl = h('div.hero-plot-box', h('p.hero-plot.clamp', plot));
    if (plot.length > 260) {
      const more = h('button.link-btn', { type: 'button', onclick: () => {
        const p_ = plotEl.querySelector('.hero-plot');
        p_.classList.toggle('clamp');
        more.textContent = p_.classList.contains('clamp') ? 'Ler mais' : 'Ler menos';
      } }, 'Ler mais');
      plotEl.append(more);
    }
  }
  return h('section.hero',
    h('div.hero-bg', bg ? { style: { backgroundImage: `url("${imgUrl(bg)}")` } } : null),
    h('div.hero-inner',
      pic(info.poster || item?.poster, name, 'hero-poster'),
      h('div.hero-text',
        h('button.btn.ghost.sm.back-btn', { type: 'button', onclick: () => history.back() }, ic('arrowL'), h('span', 'Voltar')),
        h('h1', name.replace(/\s*[([](19|20)\d\d[)\]]\s*$/, '')),
        chips.length ? h('div.hero-chips', ...chips) : null,
        info.country ? h('div.hero-meta', h('span', info.country)) : null,
        plotEl || h('p.hero-plot.muted-plot', 'Sinopse não informada pelo provedor.'),
        info.cast ? h('p.hero-cast', h('b', 'Elenco: '), info.cast) : null,
        info.director ? h('p.hero-cast', h('b', 'Direção: '), info.director) : null,
        h('div.hero-actions', { 'data-kind': kind }))));
}

function humanDuration(text, secs) {
  let s = secs || 0;
  const m = String(text || '').match(/^(\d+):(\d\d)(?::(\d\d))?$/);
  if (!s && m) s = +m[1] * 3600 + +m[2] * 60 + (+m[3] || 0);
  if (!s) return text || '';
  const hh = Math.floor(s / 3600);
  const mm = Math.round((s % 3600) / 60);
  return hh ? `${hh}h ${String(mm).padStart(2, '0')}min` : `${mm} min`;
}

function trailerUrl(t) {
  if (!t) return '';
  return t.startsWith('http') ? t : `https://www.youtube.com/watch?v=${encodeURIComponent(t)}`;
}

async function download(kind, ref, meta) {
  try {
    await api.post('/api/downloads', { src: S.active, kind, ref, meta });
    toast('Download iniciado no servidor. Acompanhe em Offline.', { action: { label: 'Ver', fn: () => { location.hash = '#/offline'; } } });
  } catch (e) { toast(e.message, { type: 'error' }); }
}

function favButton(kind, id) {
  const b = btn('', { cls: 'ghost round', icon: 'star', iconCls: isFav(kind, id) ? 'filled' : '', title: 'Favorito' });
  b.classList.toggle('fav-on', isFav(kind, id));
  b.addEventListener('click', async () => {
    const on = await toggleFav(kind, id);
    b.classList.toggle('fav-on', on);
    b.querySelector('.icw').replaceWith(ic('star', on ? 'filled' : ''));
    toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
  });
  return b;
}

// ---------------------------------------------------------------- filme
// Ao fechar o player, a página de detalhes é redesenhada para mostrar o novo ponto de "continuar".
function refreshOnClose(root, params, fn) {
  const hash = location.hash;
  const onClose = () => { if (location.hash === hash && document.body.contains(root)) { clear(root); fn(root, params, true); } };
  window.addEventListener('sintonia:player-closed', onClose, { once: true });
  return () => window.removeEventListener('sintonia:player-closed', onClose);
}

export function renderMovie(root, params, again) {
  const off = refreshOnClose(root, params, renderMovie);
  const myHash = location.hash;
  const id = decodeURIComponent(params[0]);
  if (!again) root.append(spinner('Carregando…'));
  (async () => {
    let item = catalog('movie')?.byId.get(id);
    if (!item && !catalog('movie')?.lazy) { await loadCatalog('movie').catch(() => {}); item = catalog('movie')?.byId.get(id); }
    let info = {};
    try { info = await api.get(`${base()}/movie/${encodeURIComponent(id)}`); } catch (e) { if (!item) throw e; }
    item = item || { id, name: info.name, poster: info.poster, ext: info.ext };
    if (info.ext) item = { ...item, ext: info.ext };
    if (location.hash !== myHash) return;
    clear(root);
    const hr = hero(info, item, 'movie');
    const acts = hr.querySelector('.hero-actions');
    const prog = progressOf('movie', id);
    const resumable = canResume(prog);
    acts.append(btn(resumable ? `Continuar de ${fmtDur(prog.pos)}` : 'Assistir', { cls: 'primary lg', icon: 'play',
      onclick: () => openPlayer({ kind: 'movie', item, startAt: resumable ? prog.pos : 0 }) }));
    if (resumable) acts.append(btn('Do início', { cls: 'ghost', icon: 'replay', onclick: () => openPlayer({ kind: 'movie', item, startAt: 0 }) }));
    acts.append(favButton('movie', id));
    acts.append(btn('', { cls: 'ghost round', icon: 'download', title: 'Baixar', onclick: () => download('movie', { id, ext: item.ext, cmd: item.cmd, url: item.url },
      { name: item.name, img: item.poster || info.poster, ext: item.ext }) }));
    if (info.trailer) acts.append(btn('Trailer', { cls: 'ghost', icon: 'trailer', onclick: () => window.open(trailerUrl(info.trailer), '_blank', 'noopener') }));
    acts.append(btn('', { cls: 'ghost round', icon: 'moreH', title: 'Mais', onclick: () => menu([
      { label: 'Abrir no VLC', icon: 'external', fn: () => externalPlay('movie', item) },
      { label: 'Copiar link', icon: 'copy', fn: async () => { const r = await api.post(`${base()}/play`, { kind: 'movie', ref: { id, ext: item.ext, cmd: item.cmd } }); copyText(r.direct); } },
    ], { title: item.name }) }));
    root.append(hr);
  })().catch((e) => { if (location.hash === myHash) clear(root).append(empty('Não foi possível abrir este filme', e.message)); });
  return off;
}

// ---------------------------------------------------------------- série
/** Junta as temporadas de uma série que o provedor cadastrou separada (uma "série" por temporada). */
async function loadSeriesData(item, id) {
  if (!item || !item.members) return api.get(`${base()}/series/${encodeURIComponent(id)}`);
  const results = [];
  const queue = item.members.slice();
  const worker = async () => {
    while (queue.length) {
      const m = queue.shift();
      try { results.push({ m, d: await api.get(`${base()}/series/${encodeURIComponent(m.id)}`) }); } catch { /* temporada indisponível */ }
    }
  };
  await Promise.all([worker(), worker(), worker(), worker()]);
  if (!results.length) throw new Error('Não foi possível carregar as temporadas desta série');
  results.sort((a, b) => (a.m.season ?? 0) - (b.m.season ?? 0));
  const seasons = {};
  const seasonMeta = {};
  for (const { m, d } of results) {
    const keys = Object.keys(d.seasons || {});
    for (const k of keys) {
      const target = String(m.season !== null && keys.length === 1 ? m.season : k);
      const list = (seasons[target] = seasons[target] || []);
      for (const ep of d.seasons[k]) list.push({ ...ep, season: +target });
      if (d.seasonMeta?.[k]) seasonMeta[target] = d.seasonMeta[k];
    }
  }
  Object.values(seasons).forEach((l) => l.sort((a, b) => (a.episode || 0) - (b.episode || 0)));
  const withInfo = results.find((r) => r.d.info && (r.d.info.plot || r.d.info.cast)) || results[0];
  return { info: { ...withInfo.d.info }, seasons, seasonMeta };
}

export function renderSeries(root, params, again) {
  const off = refreshOnClose(root, params, renderSeries);
  const myHash = location.hash;
  const id = decodeURIComponent(params[0]);
  if (!again) root.append(spinner('Carregando…'));
  (async () => {
    let item = catalog('series')?.byId.get(id);
    if (!item && !catalog('series')?.lazy) { await loadCatalog('series').catch(() => {}); item = catalog('series')?.byId.get(id); }
    const data = await loadSeriesData(item, id);
    const info = data.info || {};
    if (item && item.members) info.name = item.name;
    if (!info.name && item) info.name = item.name;
    if (!info.poster && item) info.poster = item.poster;
    if (!info.plot && item) info.plot = item.plot;
    const sid = item?.id || id;
    const series = { id: sid, name: info.name || item?.name || '', poster: info.poster || item?.poster || '' };
    const seasons = Object.keys(data.seasons || {}).sort((a, b) => +a - +b);
    const episodes = seasons.flatMap((s) => data.seasons[s]);
    if (location.hash !== myHash) return;
    clear(root);
    const hr = hero(info, item, 'series');
    const acts = hr.querySelector('.hero-actions');
    const last = lastEpisodeOf(sid) || (item?.members || []).map((m) => lastEpisodeOf(m.id)).find(Boolean);
    let startEp = episodes[0];
    let startAt = 0;
    if (last) {
      const ep = episodes.find((e) => String(e.id) === String(last.id));
      if (ep) {
        const done = isFinished(last);
        const i = episodes.indexOf(ep);
        if (done && episodes[i + 1]) startEp = episodes[i + 1];
        else { startEp = ep; startAt = done ? 0 : last.pos; }
      }
    }
    if (startEp) {
      const label = last ? `${startAt ? 'Continuar' : 'Assistir'} T${startEp.season}E${startEp.episode}` : 'Assistir T1E1'.replace('T1E1', `T${startEp.season}E${startEp.episode}`);
      acts.append(btn(label, { cls: 'primary lg', icon: 'play', onclick: () => openPlayer({ kind: 'episode', item: startEp, series, episodes, startAt }) }));
    }
    acts.append(favButton('series', sid));
    if (info.trailer) acts.append(btn('Trailer', { cls: 'ghost', icon: 'trailer', onclick: () => window.open(trailerUrl(info.trailer), '_blank', 'noopener') }));
    root.append(hr);

    if (!seasons.length) { root.append(empty('Esta série ainda não tem episódios')); return; }
    const saved = sessionStorage.getItem('sintonia.season.' + sid);
    let cur = saved && seasons.includes(saved) ? saved : (startEp ? String(startEp.season) : seasons[0]);
    const tabs = h('div.season-tabs');
    // celular em pé: lista suspensa no lugar das abas
    const pick = h('select.season-select', { 'aria-label': 'Temporada' });
    pick.addEventListener('change', () => { cur = pick.value; sessionStorage.setItem('sintonia.season.' + sid, cur); drawSeason(); });
    const list = h('div.ep-list');
    const tools = h('div.season-tools');
    const sPlot = h('p.season-plot');
    const drawSeason = () => {
      clear(tabs);
      seasons.forEach((s) => tabs.append(h('button.chip', { type: 'button', class: s === cur ? 'on' : '', onclick: () => { cur = s; sessionStorage.setItem('sintonia.season.' + sid, s); drawSeason(); } },
        `Temporada ${s}`)));
      clear(pick);
      seasons.forEach((s) => pick.append(h('option', { value: s, selected: s === cur || null }, `Temporada ${s} · ${data.seasons[s].length} episódio${data.seasons[s].length === 1 ? '' : 's'}`)));
      pick.value = cur;
      clear(tools).append(btn('Baixar temporada', { cls: 'ghost sm', icon: 'download', onclick: async () => {
        for (const ep of data.seasons[cur]) {
          await download('episode', ep, { name: `${series.name} - S${String(ep.season).padStart(2, '0')}E${String(ep.episode).padStart(2, '0')}`, img: series.poster, ext: ep.ext, fileName: `${series.name} - S${String(ep.season).padStart(2, '0')}E${String(ep.episode).padStart(2, '0')}` });
        }
      } }));
      const ov = (data.seasonMeta?.[cur]?.overview || '').trim();
      sPlot.textContent = ov && ov !== (info.plot || '').trim() ? ov : '';
      sPlot.hidden = !sPlot.textContent;
      clear(list);
      data.seasons[cur].forEach((ep) => {
        const p = progressOf('episode', ep.id);
        const pct = p && p.dur ? Math.min(100, (p.pos / p.dur) * 100) : 0;
        const clean = String(ep.title || '').replace(series.name.replace(/\s*\[.*\]$/, ''), '').replace(/\b[ST]\d+\s*E\d+(E\d+)*\b/gi, '').replace(/^[\s\-–:|.]*[ST]\d{1,2}\b/i, '').replace(/^[\s\-–:|.]+|[\s\-–:|.]+$/g, '').replace(/\s+-\s+-\s+/g, ' - ').trim();
        const durTxt = ep.durationSecs ? `${Math.round(ep.durationSecs / 60)} min` : (ep.duration || '').replace(/^00:/, '');
        const fn = `${series.name} - S${String(ep.season).padStart(2, '0')}E${String(ep.episode).padStart(2, '0')}`;
        const row = h('div.ep-row', { tabindex: '0', role: 'button', 'aria-label': `Episódio ${ep.episode}` },
          h('div.ep-art', pic(ep.still || series.poster, clean || series.name, 'cover'), h('span.ep-play', ic('play')),
            h('button.ep-dl', { type: 'button', title: 'Baixar episódio', 'aria-label': 'Baixar episódio', onclick: (e) => {
              e.stopPropagation();
              download('episode', ep, { name: fn, img: series.poster, ext: ep.ext, fileName: fn });
            } }, ic('download')),
            durTxt ? h('span.ep-dur', durTxt) : null,
            pct ? h('div.poster-prog', h('i', { style: { width: pct + '%' } })) : null),
          h('div.ep-txt',
            h('strong', h('span.ep-num', `E${ep.episode}`), clean || `Episódio ${ep.episode}`),
            canResume(p) ? h('small.ep-resume', `Parou em ${fmtDur(p.pos)}`) : (ep.air ? h('small', ep.air) : null),
            ep.plot ? h('p', ep.plot) : null));
        const play = () => openPlayer({ kind: 'episode', item: ep, series, episodes });
        row.addEventListener('click', play);
        row.addEventListener('keydown', (e) => { if (e.key === 'Enter') play(); });
        list.append(row);
      });
    };
    drawSeason();
    root.append(h('section.seasons', h('div.season-head', tabs, h('div.season-pick', pick), tools), sPlot, list));
  })().catch((e) => { if (location.hash === myHash) clear(root).append(empty('Não foi possível abrir esta série', e.message)); });
  return off;
}
