// Grade de programação (EPG)
import { api } from '../api.js';
import { openPlayer } from '../player.js';
import { S, base, catalog, itemsFor, loadCatalog, onChange, s24, visibleCategories } from '../state.js';
import { btn, clear, empty, fmtTime, h, ic, iconBtn, modal, pic, spinner } from '../ui.js';
import { chooseCategory, sectionHeader } from './common.js';

const PX_PER_MIN = 4;
const BATCH = 40;

export function render(root) {
  const content = h('div.view-body.guide-body');
  let start = 0;
  let end = 0;
  let channels = [];
  let shown = 0;
  let timer = null;
  const catSel = h('select.select', { 'aria-label': 'Categoria' });
  root.append(sectionHeader('Guia de programação', {
    back: () => { location.hash = '#/live'; },
    actions: [catSel,
      iconBtn('chevL', '3 horas antes', () => shift(-3)),
      btn('Agora', { cls: 'ghost sm', onclick: () => { setWindow(); draw(); } }),
      iconBtn('chevR', '3 horas depois', () => shift(3))],
  }), content);

  function setWindow(base_ = Date.now() / 1000) {
    const t = Math.floor(base_ / 1800) * 1800;
    start = t - 3600;
    end = t + 9 * 3600;
  }
  function shift(hours) {
    const c = start + 3600 + hours * 3600;
    setWindow(c);
    draw();
  }

  function fillCats() {
    clear(catSel);
    catSel.append(h('option', { value: '' }, 'Todas as categorias'));
    catSel.append(h('option', { value: '__fav' }, '★ Favoritos'));
    visibleCategories('live').forEach((c) => catSel.append(h('option', { value: c.id }, c.name)));
    catSel.value = S.favOnly.live ? '__fav' : (S.cat.live || '');
  }
  catSel.addEventListener('change', async () => {
    if (catSel.value === '__fav') { S.favOnly.live = true; S.cat.live = null; draw(); return; }
    S.favOnly.live = false;
    if (!(await chooseCategory('live', catSel.value || null))) fillCats();
  });

  function draw() {
    clear(content);
    clearInterval(timer);
    channels = itemsFor('live');
    shown = 0;
    if (!channels.length) { content.append(empty('Nenhum canal nesta categoria')); return; }
    const width = ((end - start) / 60) * PX_PER_MIN;
    const ruler = h('div.g-ruler', { style: { width: width + 'px' } });
    for (let t = start; t < end; t += 1800) {
      ruler.append(h('span.g-tick', { style: { left: ((t - start) / 60) * PX_PER_MIN + 'px' } },
        new Date(t * 1000).getMinutes() === 0 && new Date(t * 1000).getHours() === 0
          ? new Date(t * 1000).toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit' }) : fmtTime(t, s24())));
    }
    const rows = h('div.g-rows', { style: { width: width + 'px' } });
    const names = h('div.g-names');
    const nowLine = h('div.g-now');
    const scroller = h('div.g-scroll', h('div.g-inner', h('div.g-corner', ic('calendar'), h('span', new Date(start * 1000 + 3600000).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit' }))), ruler, names, rows, nowLine));
    content.append(scroller);
    const placeNow = () => {
      const now = Date.now() / 1000;
      if (now < start || now > end) { nowLine.style.display = 'none'; return; }
      nowLine.style.display = '';
      nowLine.style.left = `calc(var(--g-name-w) + ${((now - start) / 60) * PX_PER_MIN}px)`;
    };
    placeNow();
    timer = setInterval(placeNow, 30000);
    const more = () => {
      const batch = channels.slice(shown, shown + BATCH);
      shown += batch.length;
      const rowEls = new Map();
      batch.forEach((ch) => {
        names.append(h('button.g-name', { type: 'button', title: ch.name, onclick: () => openPlayer({ kind: 'live', item: ch, list: channels }) },
          pic(ch.logo, ch.name, 'mini'), h('span', ch.name)));
        const r = h('div.g-row', h('div.g-empty', 'Sem programação'));
        rows.append(r);
        rowEls.set(ch.id, r);
      });
      api.post(`${base()}/epg/grid`, { channels: batch.map((c) => ({ id: c.id, epg: c.epg, name: c.name })), from: start, to: end })
        .then((r) => {
          const now = Date.now() / 1000;
          batch.forEach((ch) => {
            const progs = (r.data || {})[ch.id];
            const row = rowEls.get(ch.id);
            if (!progs || !progs.length) return;
            clear(row);
            progs.forEach((p) => {
              const s = Math.max(p.start, start);
              const e = Math.min(p.stop, end);
              const left = ((s - start) / 60) * PX_PER_MIN;
              const w = Math.max(2, ((e - s) / 60) * PX_PER_MIN - 3);
              const isNow = p.start <= now && now < p.stop;
              const past = p.stop <= now;
              row.append(h('button.g-prog', { type: 'button', class: (isNow ? 'now ' : '') + (past ? 'past' : ''), style: { left: left + 'px', width: w + 'px' },
                title: p.title, onclick: () => progInfo(ch, p) }, h('strong', p.title), h('small', `${fmtTime(p.start, s24())} – ${fmtTime(p.stop, s24())}`)));
            });
          });
          if (r.status && r.status.loading) setTimeout(() => { if (document.body.contains(scroller)) draw(); }, 5000);
        }).catch(() => {});
      if (shown < channels.length) {
        const sentinel = h('div.g-sentinel');
        names.append(sentinel);
        const obs = new IntersectionObserver((ents) => { if (ents[0].isIntersecting) { obs.disconnect(); sentinel.remove(); more(); } }, { root: scroller, rootMargin: '400px' });
        obs.observe(sentinel);
      }
    };
    more();
    requestAnimationFrame(() => { scroller.scrollLeft = Math.max(0, ((Date.now() / 1000 - start) / 60) * PX_PER_MIN - 120); });
  }

  function progInfo(ch, p) {
    const now = Date.now() / 1000;
    const isNow = p.start <= now && now < p.stop;
    const past = p.stop <= now;
    const acts = h('div.modal-actions');
    let m;
    if (isNow) acts.append(btn('Assistir ao vivo', { cls: 'primary', icon: 'play', onclick: () => { m.close(); openPlayer({ kind: 'live', item: ch, list: channels }); } }));
    if (past && ch.archive) acts.append(btn('Assistir replay', { cls: 'primary', icon: 'replay', onclick: () => { m.close(); openPlayer({ kind: 'catchup', item: ch, program: p, list: channels }); } }));
    if (!isNow) acts.append(btn('Ver canal agora', { cls: 'ghost', icon: 'tv', onclick: () => { m.close(); openPlayer({ kind: 'live', item: ch, list: channels }); } }));
    m = modal(h('div.prog-info',
      h('div.prog-info-ch', pic(ch.logo, ch.name, 'mini'), h('span', ch.name)),
      h('p.prog-info-time', `${new Date(p.start * 1000).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit' })}, ${fmtTime(p.start, s24())} – ${fmtTime(p.stop, s24())}`),
      p.desc ? h('p', p.desc) : null, past && !ch.archive ? h('p.muted', 'Este canal não tem replay.') : null, acts), { title: p.title });
  }

  setWindow();
  content.append(spinner('Carregando o guia…'));
  loadCatalog('live').then(() => { fillCats(); draw(); })
    .catch((e) => clear(content).append(empty('Não foi possível carregar os canais', e.message)));
  const off = onChange((w) => { if ((w === 'cat' || w === 'cats') && catalog('live')) { fillCats(); draw(); } });
  return () => { off(); clearInterval(timer); };
}
