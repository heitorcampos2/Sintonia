import { openPlayer } from '../player.js';
import { S, catalog, itemsFor, loadCatalog, onChange, removeRecent, sectionPrefs } from '../state.js';
import { chunked, clear, empty, h, ic, iconBtn, pic, spinner, toast } from '../ui.js';
import { channelRow, chipsRow, epgFiller, sectionHeader } from './common.js';

let guideOpened = false;

export function render(root) {
  let q = '';
  let chunk = null;
  let filler = null;
  const content = h('div.view-body');
  const chips = chipsRow('live', () => draw());
  root.append(
    sectionHeader('TV ao Vivo', {
      search: 'Pesquisar canais', onSearch: (v) => { q = v; draw(); },
      actions: [
        iconBtn('guide', 'Guia de programação (EPG)', () => { location.hash = '#/guide'; }),
        iconBtn('grid', 'Multitela', () => { location.hash = '#/multi'; }),
        iconBtn('refresh', 'Atualizar lista', async () => { toast('Atualizando a lista…'); await loadCatalog('live', { force: true }); draw(); toast('Lista atualizada', { type: 'ok' }); }),
      ],
    }),
    chips, content);

  function draw() {
    if (chunk) chunk.destroy();
    if (filler) filler.destroy();
    clear(content);
    chips.redraw();
    const list = itemsFor('live', { q });
    const prefs = sectionPrefs('live');
    if (prefs.showRecent && !S.cat.live && !S.favOnly.live && !q && S.user.recent.length) {
      const c = catalog('live');
      const row = h('div.recent-row');
      S.user.recent.slice(0, 12).forEach((id) => {
        const ch = c.byId.get(id);
        if (!ch) return;
        const wrap = h('div.recent-wrap',
          h('button.recent-tile', { type: 'button', title: ch.name, onclick: () => openPlayer({ kind: 'live', item: ch, list }) }, pic(ch.logo, ch.name)),
          h('button.recent-x', { type: 'button', title: 'Tirar do histórico', 'aria-label': `Tirar ${ch.name} do histórico`,
            onclick: async (e) => {
              e.stopPropagation();
              await removeRecent(id);
              wrap.remove();
              if (!row.childElementCount) { row.previousElementSibling?.remove(); row.remove(); }
            } }, ic('close')));
        row.append(wrap);
      });
      if (row.childElementCount) content.append(h('h2.sec-title', 'Assistidos recentemente'), row);
    }
    content.append(h('h2.sec-title', 'Canais', h('span.count', String(list.length))));
    if (!list.length) {
      content.append(S.favOnly.live ? empty('Nenhum canal favorito aqui', 'Toque na estrela de um canal para adicioná-lo.') :
        empty(q ? `Nenhum canal com "${q}"` : 'Nenhum canal nesta categoria'));
      return;
    }
    const grid = h('div.ch-grid');
    content.append(grid);
    const rows = new Map();
    filler = epgFiller(rows);
    chunk = chunked(grid, list, (ch) => channelRow(ch, list, rows), { size: 60, root: document.querySelector('.main'), onBatch: (b) => filler.add(b) });
  }

  content.append(spinner('Carregando canais…'));
  loadCatalog('live').then(() => {
    if (!S.catInit?.live) {
      S.catInit = { ...(S.catInit || {}), live: true };
      const def = sectionPrefs('live').defaultCat;
      if (def && catalog('live').catName.has(def)) S.cat.live = def;
      if (sectionPrefs('live').openGuide && !guideOpened) { guideOpened = true; location.hash = '#/guide'; return; }
    }
    draw();
  }).catch((e) => { clear(content).append(empty('Não foi possível carregar os canais', e.message)); });

  const off = onChange((what) => { if (['cat', 'cats', 'settings'].includes(what) && catalog('live')) draw(); });
  return () => { off(); if (chunk) chunk.destroy(); if (filler) filler.destroy(); };
}
