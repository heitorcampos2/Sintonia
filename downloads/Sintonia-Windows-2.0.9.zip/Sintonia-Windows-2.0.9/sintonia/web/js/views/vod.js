// Filmes e Séries
import { KIND_LABEL, S, catalog, itemsFor, loadCatalog, onChange, sectionPrefs, visibleCategories } from '../state.js';
import { chunked, clear, empty, h, iconBtn, spinner, toast } from '../ui.js';
import { chipsRow, continueButton, continueCard, continueEntries as contOf, continueStrip, posterCard, sectionHeader } from './common.js';

export function render(root, params, kind) {
  let q = '';
  let chunk = null;
  let tab = 'popular';
  const content = h('div.view-body');
  const chips = chipsRow(kind, () => draw());
  const contBtn = continueButton(kind);
  const contStrip = continueStrip(kind);
  root.append(
    sectionHeader(KIND_LABEL[kind], {
      middle: contStrip,
      search: kind === 'movie' ? 'Pesquisar filmes' : 'Pesquisar séries', onSearch: (v) => { q = v; draw(); },
      actions: [contBtn, iconBtn('refresh', 'Atualizar lista', async () => {
        toast('Atualizando…');
        await loadCatalog(kind, { force: true, cat: S.cat[kind] });
        draw();
        toast('Lista atualizada', { type: 'ok' });
      })],
    }),
    chips, content);

  const continueEntries = () => contOf(kind);

  function draw() {
    if (chunk) chunk.destroy();
    clear(content);
    chips.redraw();
    contBtn.sync();
    contStrip.sync();
    const c = catalog(kind);
    if (c.lazy && !S.cat[kind]) {
      const first = visibleCategories(kind)[0];
      if (first) { S.cat[kind] = first.id; loadLazy(); return; }
    }
    const list = itemsFor(kind, { q });
    const prefs = sectionPrefs(kind);
    const home = !S.cat[kind] && !S.favOnly[kind] && !q;

    if (home && prefs.showPopular && list.length > 4) {
      const cont = continueEntries();
      const tabs = [['popular', 'Popular'], ['new', 'Novidades']];
      if (kind === 'series' && cont.length) tabs.push(['watching', 'Assistindo']);
      if (!tabs.some((t) => t[0] === tab)) tab = 'popular';
      const seg = h('div.seg', ...tabs.map(([id, label]) => h('button', { type: 'button', class: tab === id ? 'on' : '', onclick: () => { tab = id; draw(); } }, label)));
      const row = h('div.rank-row');
      let picks;
      if (tab === 'watching') picks = null;
      else if (tab === 'new') picks = list.slice().sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 10);
      else {
        const rated = list.filter((x) => x.rating > 0).sort((a, b) => b.rating - a.rating);
        picks = (rated.length >= 4 ? rated : list).slice(0, 10);
      }
      if (picks) picks.forEach((it, i) => row.append(posterCard(kind, it, { rank: i + 1 })));
      else cont.forEach((e) => row.append(continueCard(e)));
      content.append(seg, row);
    }

    const catName = S.cat[kind] ? c.catName.get(S.cat[kind]) : (S.favOnly[kind] ? 'Favoritos' : KIND_LABEL[kind]);
    content.append(h('h2.sec-title', catName || KIND_LABEL[kind], h('span.count', String(list.length))));
    if (!list.length) {
      content.append(S.favOnly[kind] ? empty('Nenhum favorito aqui ainda', 'Abra um título e toque na estrela para guardar.') :
        empty(q ? `Nada encontrado para "${q}"` : 'Nenhum título nesta categoria'));
      return;
    }
    const grid = h('div.poster-grid');
    content.append(grid);
    chunk = chunked(grid, list, (it) => posterCard(kind, it), { size: 48, root: document.querySelector('.main') });
  }

  async function loadLazy() {
    clear(content).append(spinner('Carregando categoria…'));
    try { await loadCatalog(kind, { cat: S.cat[kind] }); draw(); } catch (e) { clear(content).append(empty('Não foi possível carregar', e.message)); }
  }

  content.append(spinner(kind === 'movie' ? 'Carregando filmes…' : 'Carregando séries…'));
  loadCatalog(kind).then(() => {
    if (!S.catInit?.[kind]) {
      S.catInit = { ...(S.catInit || {}), [kind]: true };
      const def = sectionPrefs(kind).defaultCat;
      if (def && catalog(kind).catName.has(def)) S.cat[kind] = def;
    }
    if (catalog(kind).lazy && S.cat[kind] && !catalog(kind).loadedCats.has(S.cat[kind])) loadLazy();
    else draw();
  }).catch((e) => { clear(content).append(empty('Não foi possível carregar a lista', e.message)); });

  const off = onChange((what) => {
    if (!catalog(kind)) return;
    if (what === 'cat' && catalog(kind).lazy && S.cat[kind] && !catalog(kind).loadedCats.has(S.cat[kind])) { loadLazy(); return; }
    if (['cat', 'cats', 'settings', 'fav'].includes(what)) draw();
  });
  return () => { off(); if (chunk) chunk.destroy(); };
}
