// Primeira configuração e tela de preparo
import { api } from '../api.js';
import { S, base, loadCatalog, loadState, loadUser, saveSettings } from '../state.js';
import { btn, clear, h, ic } from '../ui.js';
import { sourceForm } from './menu.js';
import { deviceFinder, importModal } from './share.js';

export function renderWelcome(root, onDoneRaw) {
  let finished = false;
  const onDone = () => {
    if (finished) return;
    finished = true;
    saveSettings({ syncAsked: true }).catch(() => {});
    onDoneRaw();
  };
  root.append(h('div.welcome',
    h('div.welcome-side',
      h('div.brand.big', h('span.brand-mark', ic('signal')), h('span', 'Sintonia')),
      h('h1', 'Sua TV, seus filmes e suas séries em qualquer tela.'),
      h('p', 'Adicione a lista do seu provedor. Depois é só abrir o Sintonia no celular, no computador ou na TV.'),
      h('ul.welcome-points',
        h('li', ic('tv'), 'TV ao vivo com guia de programação e replay'),
        h('li', ic('film'), 'Filmes e séries com "continuar de onde parou"'),
        h('li', ic('download'), 'Downloads e gravações salvos no aparelho'),
        h('li', ic('devices'), 'Mesmos favoritos em todos os aparelhos'))),
    h('div.welcome-form', h('h2', 'Adicionar fonte'),
      syncChoice(onDone),
      sourceForm({ onSaved: async () => { await loadState(); onDone(); } }),
      h('div.welcome-import', btn('Importar lista de arquivo ou QR', { cls: 'ghost sm', icon: 'upload', onclick: () => {
        importModal();
        const t = setInterval(() => { if (S.sources.length) { clearInterval(t); onDone(); } }, 800);
      } })))));
}

/** Primeira abertura: o usuário escolhe se quer sincronizar com outros Sintonia da rede (opcional). */
function syncChoice(onDone) {
  const box = h('div.welcome-sync');
  const draw = (on) => {
    clear(box).append(
      h('label.welcome-sync-head',
        h('input', { type: 'checkbox', checked: on || null, onchange: async (e) => {
          await saveSettings({ sync: { enabled: e.target.checked }, syncAsked: true });
          draw(e.target.checked);
        } }),
        h('span', h('strong', 'Sincronizar com outros aparelhos desta rede'),
          h('small', 'Opcional. Se você já usa o Sintonia em outro aparelho, as listas e os favoritos vêm de lá, sem digitar nada.'))),
      on ? deviceFinder({ autoStart: true, onSynced: () => { if (S.sources.length) onDone(); } }) : null);
  };
  draw(!!S.settings.sync?.enabled);
  return box;
}

/** Tela "preparando seu espaço" enquanto os catálogos carregam. */
export async function prepare(root) {
  const steps = [
    ['Aplicando suas preferências', async () => { await loadUser(); }],
    ['Reunindo canais, filmes e séries', async () => {
      await loadCatalog('live').catch(() => {});
      await Promise.allSettled([loadCatalog('movie'), loadCatalog('series')]);
    }],
    ['Preparando o guia de programação', async () => {
      const t0 = Date.now();
      while (Date.now() - t0 < 6000) {
        const st = await api.get(`${base()}/epg/status`).catch(() => null);
        if (!st || !st.loading) break;
        await new Promise((r) => setTimeout(r, 700));
      }
    }],
  ];
  const bar = h('i');
  const pct = h('span.prep-pct', '0%');
  const now = h('span.prep-now', steps[0][0] + '…');
  const items = steps.map(([label]) => h('li', h('span.prep-dot'), h('span', label + '…')));
  const el = h('div.prep',
    h('div.prep-kicker', h('span.live-dot'), 'Configuração em andamento'),
    h('div.prep-grid',
      h('div', h('h1', 'Preparando seu espaço…'), h('p.prep-lead', `Conectando a "${(S.sources.find((s) => s.id === S.active) || {}).name || 'sua lista'}".`),
        h('p.muted', 'Na primeira vez pode levar alguns segundos. Depois tudo abre na hora.')),
      h('div.prep-right', h('div.prep-bar', bar), h('div.prep-line', now, pct), h('ol.prep-steps', ...items))));
  root.append(el);
  for (let i = 0; i < steps.length; i++) {
    items[i].classList.add('on');
    now.textContent = steps[i][0] + '…';
    try { await steps[i][1](); } catch { /* segue */ }
    items[i].classList.remove('on');
    items[i].classList.add('done');
    const p = Math.round(((i + 1) / steps.length) * 100);
    bar.style.width = p + '%';
    pct.textContent = p + '%';
  }
  await new Promise((r) => setTimeout(r, 350));
  el.remove();
}
