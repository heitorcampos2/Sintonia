import { api } from './api.js';
import { norm } from './ui.js';

export const S = {
  ready: false,
  version: '',
  settings: null,
  sources: [],
  active: null,
  parental: { hasPin: false, autoAdult: false, locked: {} },
  urls: [],
  user: null,
  catalogs: {},           // kind -> {categories, items, byId, lazy, loadedCats:Set}
  cat: { live: null, movie: null, series: null },
  favOnly: { live: false, movie: false, series: false },
  unlocked: new Set(),
  pinOk: false,
  multi: [],
};

const listeners = new Set();
export function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function emit(what) { listeners.forEach((fn) => fn(what)); }

export const KIND_LABEL = { live: 'TV ao Vivo', movie: 'Filmes', series: 'Séries' };
const ADULT = /(adult|adulto|xxx|\+ ?18|18 ?\+|porn|erotic|er[óo]tic|hot\b|sexo)/i;

export function src() { return S.sources.find((s) => s.id === S.active) || null; }
export function base() { return `/api/src/${S.active}`; }

export async function loadState() {
  const st = await api.get('/api/state');
  S.version = st.version;
  S.settings = st.settings;
  S.sources = st.sources;
  S.active = st.active;
  S.parental = st.parental;
  S.urls = st.urls;
  S.mediaDir = st.mediaDir;
  S.dataDir = st.dataDir;
  S.device = st.device;
  applyTheme();
  return st;
}

export async function loadUser() {
  if (!S.active) { S.user = null; return; }
  S.user = await api.get(`${base()}/user`);
}

export function resetSourceData() {
  S.catalogs = {};
  S.cat = { live: null, movie: null, series: null };
  S.favOnly = { live: false, movie: false, series: false };
  S.unlocked = new Set();
  S.user = null;
}

export function applyTheme() {
  const s = S.settings || {};
  let theme = s.theme || 'dark';
  if (theme === 'auto') theme = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  document.documentElement.dataset.theme = theme;
  document.documentElement.dataset.accent = s.accent || 'azul';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = theme === 'light' ? '#f3f5f9' : '#0b0e14';
}

export async function saveSettings(patch) {
  S.settings = await api.post('/api/settings', patch);
  applyTheme();
  emit('settings');
  return S.settings;
}

// ---------- catálogos ----------
export async function loadCatalog(kind, { force = false, cat = null } = {}) {
  let c = S.catalogs[kind];
  if (c && !force && !(c.lazy && cat && !c.loadedCats.has(cat))) return c;
  const q = new URLSearchParams();
  if (force) q.set('force', '1');
  if (cat) q.set('cat', cat);
  const d = await api.get(`${base()}/catalog/${kind}?${q}`);
  if (!c || force) {
    c = { categories: d.categories, items: [], byId: new Map(), lazy: d.lazy, loadedCats: new Set() };
    S.catalogs[kind] = c;
  }
  if (d.lazy) {
    c.categories = d.categories;
    if (cat) {
      c.loadedCats.add(cat);
      for (const it of d.items) if (!c.byId.has(it.id)) { c.items.push(it); c.byId.set(it.id, it); }
    }
  } else {
    c.items = d.items;
    c.byId = new Map(d.items.map((it) => [it.id, it]));
    if (kind === 'series' && S.settings.series?.group !== false) groupSeries(c);
  }
  c.catName = new Map(c.categories.map((x) => [x.id, x.name]));
  return c;
}

export function catalog(kind) { return S.catalogs[kind]; }

export function isHidden(kind, cat) {
  return !!S.user && (S.user.hidden[kind] || []).includes(String(cat));
}

export function isLocked(kind, cat) {
  const lk = ((S.parental.locked || {})[S.active] || {})[kind] || [];
  if (lk.includes(String(cat))) return true;
  if (S.parental.autoAdult && S.parental.hasPin) {
    const c = S.catalogs[kind];
    const name = c && c.catName ? c.catName.get(String(cat)) : '';
    if (name && ADULT.test(name)) return true;
  }
  return false;
}

export function isBlocked(kind, cat) {
  return isLocked(kind, cat) && !S.unlocked.has(`${kind}:${cat}`);
}

export function visibleCategories(kind) {
  const c = S.catalogs[kind];
  if (!c) return [];
  return c.categories.filter((x) => !isHidden(kind, x.id));
}

export function isFav(kind, id) {
  return !!S.user && (S.user.favorites[kind] || []).includes(String(id));
}

export async function toggleFav(kind, id) {
  const on = !isFav(kind, id);
  S.user.favorites = await api.post(`${base()}/user/fav`, { kind, id, on });
  emit('fav');
  return on;
}

const SORTS = {
  default: (a, b) => (a.num || 0) - (b.num || 0),
  az: (a, b) => a.name.localeCompare(b.name, 'pt-BR'),
  za: (a, b) => b.name.localeCompare(a.name, 'pt-BR'),
  added: (a, b) => (b.added || 0) - (a.added || 0),
  rating: (a, b) => (b.rating || 0) - (a.rating || 0),
  year: (a, b) => (b.year || 0) - (a.year || 0),
};

export const SORT_LABEL = { default: 'Ordem da lista', az: 'A → Z', za: 'Z → A', added: 'Adicionados recentemente',
  rating: 'Melhor avaliação', year: 'Ano (mais novos)' };

export function sortMode(kind) {
  const key = kind === 'movie' ? 'movies' : kind;
  const pref = S.settings[key]?.sort || 'remember';
  if (pref === 'remember') return S.settings.lastSort?.[kind] || 'default';
  return pref;
}

export function sectionPrefs(kind) {
  return S.settings[kind === 'movie' ? 'movies' : kind] || {};
}

/** Itens visíveis de um tipo, já filtrados e ordenados. */
export function itemsFor(kind, { cat = S.cat[kind], favOnly = S.favOnly[kind], q = '' } = {}) {
  const c = S.catalogs[kind];
  if (!c) return [];
  let list = c.items;
  const hidden = new Set((S.user?.hidden[kind] || []).map(String));
  list = list.filter((it) => !hidden.has(String(it.cat)) && !isBlocked(kind, it.cat));
  if (cat) list = list.filter((it) => (it.cats ? it.cats.includes(String(cat)) : String(it.cat) === String(cat)));
  if (favOnly) {
    const fav = new Set(S.user?.favorites[kind] || []);
    list = list.filter((it) => fav.has(it.id));
  }
  if (q) {
    const nq = norm(q);
    list = list.filter((it) => norm(it.name).includes(nq));
  }
  list = list.slice().sort(SORTS[sortMode(kind)] || SORTS.default);
  if (sectionPrefs(kind).favFirst && !favOnly) {
    const fav = S.user?.favorites[kind] || [];
    if (fav.length) {
      const set = new Set(fav);
      list = list.filter((x) => set.has(x.id)).concat(list.filter((x) => !set.has(x.id)));
    }
  }
  return list;
}

export function progressOf(kind, id) {
  if (!S.user) return null;
  return S.user.history.find((x) => x.kind === kind && String(x.id) === String(id)) || null;
}

/** Terminou de assistir? (perto do fim: últimos 30 s ou 5% do vídeo) */
export function isFinished(p) {
  return !!(p && p.dur && p.pos >= p.dur - Math.min(30, p.dur * 0.05));
}

/** Dá para continuar de onde parou? */
export function canResume(p) {
  return !!(p && p.pos >= 10 && !isFinished(p));
}

export function lastEpisodeOf(seriesId) {
  if (!S.user) return null;
  return S.user.history.find((x) => x.kind === 'episode' && String(x.seriesId) === String(seriesId)) || null;
}

export async function saveProgress(entry) {
  const e = await api.post(`${base()}/user/progress`, entry);
  if (S.user) {
    S.user.history = [e, ...S.user.history.filter((x) => !(x.kind === e.kind && String(x.id) === String(e.id)))];
  }
  return e;
}

export async function addRecent(id) {
  const r = await api.post(`${base()}/user/recent`, { id });
  if (S.user) S.user.recent = r;
}

export async function removeRecent(id) {
  const r = await api.post(`${base()}/user/recent/remove`, { id });
  if (S.user) S.user.recent = r;
}

export function s24() { return (S.settings?.timeFormat || '24') === '24'; }

// ---------- séries divididas por temporada ----------
// Muitos provedores cadastram cada temporada como uma série separada ("VIKINGS S01", "VIKINGS S02"…).
// Aqui elas viram uma série só, com as temporadas dentro.
const SEASON_RX = /(?:^|[\s\-–_.:|(\[])(?:s|t|temporada|season|temp\.?)\s*0*(\d{1,2})(?!\d)|(?:^|[\s\-–_.:|(\[])0*(\d{1,2})\s*[ªaº°]?\s*temporada/i;
const TAG_RX = /\b(leg(?:endad[oa])?|dub(?:lad[oa])?|nacional|4k|uhd)\b/gi;

export function splitSeasonName(name) {
  const m = SEASON_RX.exec(name);
  const tags = [...new Set((name.match(TAG_RX) || []).map((t) => t.toUpperCase().replace(/^LEG.*/, 'LEG').replace(/^DUB.*/, 'DUB')))].sort();
  let baseName = name;
  let season = null;
  if (m) {
    season = parseInt(m[1] || m[2], 10);
    baseName = name.slice(0, m.index);
  }
  baseName = baseName.replace(/[\s\-–_.:|(\[]+$/, '').trim() || name.trim();
  return { baseName, season, tags };
}

function hashKey(text) {
  let x = 5381;
  for (let i = 0; i < text.length; i++) x = ((x << 5) + x + text.charCodeAt(i)) >>> 0;
  return x.toString(36);
}

function groupSeries(c) {
  const groups = new Map();
  for (const it of c.items) {
    const { baseName, season, tags } = splitSeasonName(it.name);
    const key = norm(baseName).replace(/[^a-z0-9]+/g, '') + (tags.length ? '|' + tags.join(',') : '');
    if (!key) continue;
    let g = groups.get(key);
    if (!g) { g = { key, baseName, tags, members: [], hasSeason: false }; groups.set(key, g); }
    g.members.push({ id: it.id, season, name: it.name, item: it });
    if (season !== null) g.hasSeason = true;
  }
  const out = [];
  const seen = new Set();
  for (const it of c.items) {
    const { baseName, tags } = splitSeasonName(it.name);
    const key = norm(baseName).replace(/[^a-z0-9]+/g, '') + (tags.length ? '|' + tags.join(',') : '');
    const g = groups.get(key);
    if (!g || (!g.hasSeason && g.members.length < 2)) { out.push(it); continue; }
    if (seen.has(key)) continue;
    seen.add(key);
    const ms = g.members.slice().sort((a, b) => (a.season ?? 0) - (b.season ?? 0));
    const first = ms.find((m) => m.item.poster) || ms[0];
    const gi = {
      id: 'g' + hashKey(key),
      name: g.baseName + (g.tags.length ? ` [${g.tags.join(' ')}]` : ''),
      poster: first.item.poster,
      cat: ms[0].item.cat,
      cats: [...new Set(ms.map((m) => String(m.item.cat)))],
      rating: Math.max(...ms.map((m) => m.item.rating || 0)),
      added: Math.max(...ms.map((m) => m.item.added || 0)),
      year: Math.min(...ms.map((m) => m.item.year || 9999)) % 9999,
      num: Math.min(...ms.map((m) => m.item.num || 1e9)),
      plot: (ms.find((m) => m.item.plot) || ms[0]).item.plot || '',
      members: ms.map((m) => ({ id: m.id, season: m.season, name: m.name })),
    };
    out.push(gi);
    c.byId.set(gi.id, gi);
    ms.forEach((m) => c.byId.set(m.id, gi));
  }
  c.items = out;
}
