"""Guia de programação (XMLTV) indexado em memória."""

import gzip
import os
import pickle
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

from . import net

KEEP_PAST = 4 * 86400
KEEP_FUTURE = 3 * 86400


def parse_xmltv_time(s):
    if not s:
        return None
    s = s.strip()
    try:
        base = s[:14].ljust(14, "0")
        rest = s[14:].strip()
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
        if rest[:1] in ("+", "-") and len(rest) >= 5 and rest[1:5].isdigit():
            sign = -1 if rest[0] == "-" else 1
            secs = int(rest[1:3]) * 3600 + int(rest[3:5]) * 60
            return int(dt.replace(tzinfo=timezone.utc).timestamp()) - sign * secs
        if rest.upper() in ("Z", "UTC", "GMT"):
            return int(dt.replace(tzinfo=timezone.utc).timestamp())
        return int(dt.timestamp())
    except ValueError:
        return None


class EpgIndex:
    def __init__(self, cache_dir, src_id):
        self.dir = Path(cache_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.src_id = src_id
        self.progs = {}          # canal -> [(start, stop, title, desc)]
        self.names = {}          # canal -> nome
        self.loaded_at = 0
        self.loading = False
        self.error = ""
        self.url = None
        self._lock = threading.Lock()
        self._load_pickle()

    @property
    def _pickle(self):
        return self.dir / "epg.pickle"

    def _load_pickle(self):
        try:
            with open(self._pickle, "rb") as fh:
                d = pickle.load(fh)
            self.progs, self.names = d["progs"], d.get("names", {})
            self.loaded_at, self.url = d["at"], d.get("url")
        except Exception:  # noqa: BLE001
            pass

    def status(self):
        return {"loaded": bool(self.progs), "loading": self.loading, "at": self.loaded_at,
                "channels": len(self.progs), "error": self.error}

    def ensure(self, url, max_age_hours=12, force=False):
        if not url:
            return
        fresh = self.progs and self.url == url and time.time() - self.loaded_at < max_age_hours * 3600
        if (fresh and not force) or self.loading:
            return
        with self._lock:
            if self.loading:
                return
            self.loading = True
        threading.Thread(target=self._load, args=(url,), daemon=True).start()

    def _load(self, url):
        tmp = None
        try:
            self.error = ""
            fd, tmp = tempfile.mkstemp(dir=self.dir, suffix=".xml")
            with os.fdopen(fd, "wb") as out, net.open_url(url, timeout=120) as resp:
                while True:
                    chunk = resp.read(256 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
            with open(tmp, "rb") as fh:
                magic = fh.read(2)
            opener = gzip.open if magic == b"\x1f\x8b" else open
            now = time.time()
            lo, hi = now - KEEP_PAST, now + KEEP_FUTURE
            progs, names = {}, {}
            with opener(tmp, "rb") as fh:
                for _, el in ET.iterparse(fh, events=("end",)):
                    tag = el.tag
                    if tag == "programme":
                        start = parse_xmltv_time(el.get("start"))
                        stop = parse_xmltv_time(el.get("stop")) or (start + 1800 if start else None)
                        ch = el.get("channel")
                        if start and ch and stop > lo and start < hi:
                            title = el.findtext("title") or ""
                            desc = el.findtext("desc") or ""
                            progs.setdefault(ch, []).append((start, stop, title.strip(), desc.strip()[:600]))
                        el.clear()
                    elif tag == "channel":
                        cid = el.get("id")
                        if cid:
                            names[cid] = (el.findtext("display-name") or "").strip()
                        el.clear()
            for lst in progs.values():
                lst.sort()
            self.progs, self.names, self.loaded_at, self.url = progs, names, time.time(), url
            with open(self._pickle, "wb") as fh:
                pickle.dump({"progs": progs, "names": names, "at": self.loaded_at, "url": url}, fh)
        except Exception as exc:  # noqa: BLE001
            self.error = str(exc)
        finally:
            self.loading = False
            if tmp:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass

    @staticmethod
    def _p(t, offset=0):
        return {"start": t[0] + offset, "stop": t[1] + offset, "title": t[2], "desc": t[3]}

    def now_next(self, ids, offset=0):
        now = time.time() - offset
        out = {}
        for cid in ids:
            lst = self.progs.get(cid)
            if not lst:
                continue
            cur = nxt = None
            for i, p in enumerate(lst):
                if p[0] <= now < p[1]:
                    cur = p
                    nxt = lst[i + 1] if i + 1 < len(lst) else None
                    break
                if p[0] > now:
                    nxt = p
                    break
            out[cid] = [self._p(cur, offset) if cur else None, self._p(nxt, offset) if nxt else None]
        return out

    def programmes(self, cid, start, end, offset=0):
        lst = self.progs.get(cid) or []
        return [self._p(p, offset) for p in lst if p[1] + offset > start and p[0] + offset < end]

    def search(self, q, offset=0, limit=150):
        q = q.lower().strip()
        if not q:
            return []
        now = time.time()
        out = []
        for cid, lst in self.progs.items():
            for p in lst:
                if p[1] + offset < now - 6 * 3600:
                    continue
                if q in p[2].lower():
                    out.append({"channel": cid, **self._p(p, offset)})
        out.sort(key=lambda x: x["start"])
        return out[:limit]
