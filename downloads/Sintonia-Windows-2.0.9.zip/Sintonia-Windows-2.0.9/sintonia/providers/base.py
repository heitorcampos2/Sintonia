"""Interface comum dos provedores e utilidades de normalização."""

import hashlib
import re

KINDS = ("live", "movie", "series")

_YEAR = re.compile(r"[\(\[](19\d\d|20\d\d)[\)\]]")


def short_hash(text):
    return hashlib.sha1(text.encode("utf-8", "replace")).hexdigest()[:12]


def to_int(v, default=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def to_float(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def year_from(*values):
    for v in values:
        if not v:
            continue
        s = str(v)
        if re.fullmatch(r"(19|20)\d\d", s[:4]) and (len(s) == 4 or not s[4].isdigit()):
            return int(s[:4])
        m = _YEAR.search(s)
        if m:
            return int(m.group(1))
    return 0


def ext_of(url, default=""):
    path = url.split("?", 1)[0].split("#", 1)[0]
    last = path.rsplit("/", 1)[-1]
    if "." in last:
        e = last.rsplit(".", 1)[-1].lower()
        if 1 <= len(e) <= 5 and e.isalnum():
            return e
    return default


class Provider:
    """Cada provedor devolve dados no mesmo formato:

    categorias: {"id", "name"}
    live:   {"id","name","logo","cat","num","epg","archive","archive_days","added"[, "url"]}
    movie:  {"id","name","poster","cat","rating","added","year","ext"[, "url"]}
    series: {"id","name","poster","cat","rating","added","year","plot"}
    """

    kind = "base"
    lazy_kinds = ()  # tipos cujo catálogo é carregado por categoria

    def __init__(self, source):
        self.source = source

    def account(self):
        return {}

    def load(self, kind, cat=None):
        """Devolve {"categories": [...], "items": [...]} para um tipo."""
        raise NotImplementedError

    def movie_info(self, item_id):
        return {}

    def series_info(self, item_id):
        return {"info": {}, "seasons": {}}

    def short_epg(self, item, limit=10):
        return []

    def stream_url(self, kind, item, fmt=None):
        raise NotImplementedError

    def catchup_url(self, item, start_ts, minutes):
        return None

    def epg_url(self):
        return None
