"""Provedor Portal Stalker / Ministra (MAG).

Os portais variam bastante; esta implementação cobre o fluxo mais comum:
handshake -> get_profile -> listas -> create_link.
"""

import threading
import time
import urllib.parse

from .. import net
from .base import Provider, to_float, to_int, year_from

MAG_UA = ("Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) "
          "MAG200 stbapp ver: 2 rev: 250 Safari/533.3")

MAX_PAGES = 60


class StalkerProvider(Provider):
    kind = "stalker"
    lazy_kinds = ("movie", "series")

    def __init__(self, source):
        super().__init__(source)
        self.mac = (source.get("mac") or "").strip().upper()
        self.portal_url = (source.get("url") or "").strip()
        self.token = None
        self.endpoint = None
        self._lock = threading.Lock()
        self._token_at = 0

    # --- sessão -----------------------------------------------------------
    def _candidates(self):
        url = self.portal_url
        if "://" not in url:
            url = "http://" + url
        url = url.rstrip("/")
        if url.endswith(".php"):
            return [url]
        root = url[:-2] if url.endswith("/c") else url
        root = root.rstrip("/")
        out = [f"{root}/portal.php", f"{root}/server/load.php"]
        if "/stalker_portal" not in root:
            out.append(f"{root}/stalker_portal/server/load.php")
        return out

    def _headers(self):
        h = {
            "User-Agent": MAG_UA,
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Cookie": f"mac={urllib.parse.quote(self.mac)}; stb_lang=en; timezone=America%2FSao_Paulo",
            "Referer": self.portal_url.rstrip("/") + "/",
        }
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def _raw(self, endpoint, params):
        params = dict(params)
        params["JsHttpRequest"] = "1-xml"
        url = endpoint + "?" + urllib.parse.urlencode(params)
        d = net.fetch_json(url, headers=self._headers(), timeout=40)
        if isinstance(d, dict) and "js" in d:
            return d["js"]
        return d

    def _handshake(self):
        last = None
        for ep in ([self.endpoint] if self.endpoint else self._candidates()):
            try:
                self.token = None
                js = self._raw(ep, {"type": "stb", "action": "handshake", "token": "", "prehash": "0"})
                tok = (js or {}).get("token") if isinstance(js, dict) else None
                if tok:
                    self.token = tok
                    self.endpoint = ep
                    self._raw(ep, {"type": "stb", "action": "get_profile", "hd": "1",
                                   "ver": "ImageDescription: 0.2.18-r23-250; PORTAL version: 5.6.1",
                                   "num_banks": "2", "stb_type": "MAG250", "image_version": "218",
                                   "auth_second_step": "1", "hw_version": "1.7-BD-00",
                                   "not_valid_token": "0", "device_id": "", "device_id2": "",
                                   "signature": "", "sn": "", "metrics": ""})
                    self._token_at = time.time()
                    return
            except net.FetchError as exc:
                last = exc
        raise net.FetchError(f"O portal não aceitou o MAC informado ({last or 'sem resposta'})")

    def call(self, params):
        with self._lock:
            if not self.token or time.time() - self._token_at > 3000:
                self._handshake()
        try:
            js = self._raw(self.endpoint, params)
        except net.FetchError:
            with self._lock:
                self._handshake()
            js = self._raw(self.endpoint, params)
        return js

    # --- dados ------------------------------------------------------------
    def account(self):
        js = self.call({"type": "account_info", "action": "get_main_info"}) or {}
        if not isinstance(js, dict):
            js = {}
        exp = js.get("end_date") or js.get("phone") or ""
        ts = None
        if exp:
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d.%m.%Y"):
                try:
                    ts = int(time.mktime(time.strptime(str(exp)[:19], fmt)))
                    break
                except ValueError:
                    continue
        return {"status": "Active", "username": self.mac, "expires": ts, "isTrial": False,
                "activeCons": 0, "maxCons": 0, "created": None, "formats": [], "timezone": "",
                "server": self.portal_url}

    def _paged(self, params):
        out = []
        page = 1
        while page <= MAX_PAGES:
            p = dict(params)
            p["p"] = str(page)
            js = self.call(p) or {}
            data = js.get("data") if isinstance(js, dict) else None
            if not data:
                break
            out.extend(data)
            total = to_int(js.get("total_items"), 0)
            per = to_int(js.get("max_page_items"), len(data)) or len(data)
            if total and len(out) >= total:
                break
            if len(data) < per:
                break
            page += 1
        return out

    def load(self, kind, cat=None):
        if kind == "live":
            genres = self.call({"type": "itv", "action": "get_genres"}) or []
            cats = [{"id": str(g.get("id")), "name": g.get("title") or ""}
                    for g in genres if isinstance(g, dict) and str(g.get("id")) != "*"]
            js = self.call({"type": "itv", "action": "get_all_channels"}) or {}
            data = js.get("data") if isinstance(js, dict) else js
            items = []
            for c in data or []:
                items.append({
                    "id": str(c.get("id")), "name": c.get("name") or "", "logo": c.get("logo") or "",
                    "cat": str(c.get("tv_genre_id") or ""), "num": to_int(c.get("number"), 0),
                    "epg": c.get("xmltv_id") or "", "archive": to_int(c.get("tv_archive"), 0) == 1,
                    "archive_days": to_int(c.get("tv_archive_duration"), 0), "added": 0,
                    "cmd": c.get("cmd") or "",
                })
            return {"categories": cats, "items": items}
        stype = "vod" if kind == "movie" else "series"
        raw = self.call({"type": stype, "action": "get_categories"}) or []
        cats = [{"id": str(c.get("id")), "name": c.get("title") or ""}
                for c in raw if isinstance(c, dict) and str(c.get("id")) != "*"]
        if cat is None:
            return {"categories": cats, "items": []}
        rows = self._paged({"type": stype, "action": "get_ordered_list", "category": cat,
                            "genre": "*", "sortby": "added", "fav": "0"})
        items = []
        for r in rows:
            name = r.get("name") or ""
            base = {"id": str(r.get("id")), "name": name, "poster": r.get("screenshot_uri") or "",
                    "cat": str(cat), "rating": round(to_float(r.get("rating_imdb") or r.get("rating_kinopoisk"), 0), 1),
                    "added": 0, "year": year_from(r.get("year"), name), "cmd": r.get("cmd") or ""}
            if kind == "movie":
                base["ext"] = "mp4"
                base["plot"] = r.get("description") or ""
            else:
                base["plot"] = r.get("description") or ""
            items.append(base)
        return {"categories": cats, "items": items}

    def series_info(self, item_id):
        rows = self._paged({"type": "series", "action": "get_ordered_list", "movie_id": item_id,
                            "season_id": "0", "episode_id": "0"})
        seasons = {}
        for r in rows:
            snum = to_int(r.get("season_number") or r.get("id", "").split(":")[-1], len(seasons) + 1)
            eps = r.get("series") or []
            lst = []
            for n in eps:
                n = to_int(n, 0)
                lst.append({"id": f"{r.get('id')}|{n}", "season": snum, "episode": n,
                            "title": f"Episódio {n}", "ext": "mp4", "plot": "", "still": "",
                            "durationSecs": 0, "duration": "", "rating": 0, "air": "",
                            "cmd": r.get("cmd") or "", "series_num": n})
            if lst:
                seasons[str(snum)] = lst
        return {"info": {"id": item_id, "name": "", "plot": "", "cast": "", "director": "", "genre": "",
                         "release": "", "rating": 0, "trailer": "", "poster": "", "backdrop": ""},
                "seasons": seasons, "seasonMeta": {}}

    def short_epg(self, item, limit=10):
        js = self.call({"type": "itv", "action": "get_short_epg", "ch_id": item["id"], "size": str(limit)}) or []
        out = []
        for p in js if isinstance(js, list) else []:
            start = to_int(p.get("start_timestamp"), 0)
            stop = to_int(p.get("stop_timestamp"), 0)
            if start:
                out.append({"start": start, "stop": stop or start + 1800, "title": p.get("name") or "",
                            "desc": p.get("descr") or ""})
        return out

    @staticmethod
    def _clean_cmd(cmd):
        cmd = (cmd or "").strip()
        for prefix in ("ffmpeg ", "ffrt ", "auto "):
            if cmd.startswith(prefix):
                cmd = cmd[len(prefix):]
        return cmd.strip()

    def stream_url(self, kind, item, fmt=None):
        cmd = item.get("cmd") or ""
        if kind == "live":
            js = self.call({"type": "itv", "action": "create_link", "cmd": cmd,
                            "forced_storage": "undefined", "disable_ad": "0"}) or {}
        else:
            params = {"type": "vod", "action": "create_link", "cmd": cmd,
                      "forced_storage": "undefined", "disable_ad": "0"}
            if kind == "episode" and item.get("series_num"):
                params["series"] = str(item["series_num"])
            js = self.call(params) or {}
        link = self._clean_cmd(js.get("cmd") if isinstance(js, dict) else "")
        if not link:
            link = self._clean_cmd(cmd)
        if not link.startswith("http"):
            raise net.FetchError("O portal não devolveu um link reproduzível")
        return link
