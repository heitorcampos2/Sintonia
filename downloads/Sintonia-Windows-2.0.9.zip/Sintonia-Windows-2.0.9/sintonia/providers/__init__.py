import urllib.parse

from .m3u import M3UProvider
from .stalker import StalkerProvider
from .xtream import XtreamProvider

TYPES = {"xtream": XtreamProvider, "m3u": M3UProvider, "stalker": StalkerProvider}


def xtream_from_m3u(url):
    """Lista M3U de um painel Xtream (get.php?username=…&password=…) vira fonte Xtream.

    O modo Xtream dá TV ao vivo em TS e HLS, guia de programação, replay e detalhes de séries.
    """
    try:
        parts = urllib.parse.urlsplit((url or "").strip())
    except ValueError:
        return None
    if not parts.path.lower().endswith(("/get.php", "/playlist.php")):
        return None
    q = dict(urllib.parse.parse_qsl(parts.query))
    user, pw = q.get("username"), q.get("password")
    if not (user and pw):
        return None
    root = parts.path.rsplit("/", 1)[0]
    return {"url": urllib.parse.urlunsplit((parts.scheme, parts.netloc, root, "", "")), "username": user, "password": pw}


def effective_type(source):
    if source.get("type") == "m3u" and xtream_from_m3u(source.get("url")):
        return "xtream"
    return source.get("type")


def make_provider(source):
    if effective_type(source) == "xtream" and source.get("type") == "m3u":
        return XtreamProvider({**source, **xtream_from_m3u(source.get("url"))})
    cls = TYPES.get(source.get("type"))
    if not cls:
        raise ValueError("Tipo de fonte desconhecido")
    return cls(source)
