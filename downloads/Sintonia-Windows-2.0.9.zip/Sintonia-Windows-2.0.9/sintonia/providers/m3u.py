"""Provedor de lista M3U/M3U8 (URL ou arquivo local)."""

import re
from pathlib import Path

from .. import net
from .base import Provider, ext_of, short_hash, to_int, year_from

_ATTR = re.compile(r'([\w-]+)="([^"]*)"')
_SE = re.compile(r"^(.*?)[\s._-]*S(\d{1,2})\s*[\s._-]*E(\d{1,3})\b(.*)$", re.I)
_SE2 = re.compile(r"^(.*?)[\s._-]+(\d{1,2})x(\d{1,3})\b(.*)$", re.I)
_VOD_EXT = {"mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "mpg", "mpeg"}


def parse_m3u(text):
    """Lê a lista e devolve (cabeçalho, entradas)."""
    header = {}
    entries = []
    cur = None
    opts = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#EXTM3U"):
            header.update(dict(_ATTR.findall(line)))
            continue
        if line.startswith("#EXTINF"):
            body = line[len("#EXTINF:"):]
            attrs = dict(_ATTR.findall(body))
            # o nome fica depois da última vírgula fora de aspas
            name = ""
            in_q = False
            split_at = -1
            for i, ch in enumerate(body):
                if ch == '"':
                    in_q = not in_q
                elif ch == "," and not in_q:
                    split_at = i
            if split_at >= 0:
                name = body[split_at + 1:].strip()
            cur = {"attrs": attrs, "name": name or attrs.get("tvg-name", ""), "group": attrs.get("group-title", "")}
            continue
        if line.startswith("#EXTGRP:") and cur is not None:
            cur["group"] = cur["group"] or line[8:].strip()
            continue
        if line.startswith("#EXTVLCOPT:"):
            k, _, v = line[11:].partition("=")
            opts[k.strip().lower()] = v.strip()
            continue
        if line.startswith("#"):
            continue
        if cur is None:
            cur = {"attrs": {}, "name": line.rsplit("/", 1)[-1], "group": ""}
        cur["url"] = line
        if opts:
            cur["opts"] = opts
        entries.append(cur)
        cur = None
        opts = {}
    return header, entries


def classify(entry):
    url = entry["url"]
    low = url.lower()
    if "/series/" in low:
        return "episode"
    if "/movie/" in low:
        return "movie"
    ext = ext_of(url)
    if ext in _VOD_EXT:
        name = entry["name"]
        if _SE.match(name) or _SE2.match(name):
            return "episode"
        return "movie"
    return "live"


class M3UProvider(Provider):
    kind = "m3u"

    def __init__(self, source):
        super().__init__(source)
        self._parsed = None
        self._header = {}

    def _read(self):
        url = (self.source.get("url") or "").strip()
        if url.startswith("file://"):
            url = url[7:]
        if url.startswith("/") or url.startswith("~"):
            return Path(url).expanduser().read_text(encoding="utf-8", errors="replace")
        return net.fetch_text(url, timeout=120)

    def _build(self):
        header, entries = parse_m3u(self._read())
        self._header = header
        data = {k: {"cats": {}, "items": []} for k in ("live", "movie", "series")}
        series_map = {}
        for e in entries:
            kind = classify(e)
            attrs = e["attrs"]
            group = (e.get("group") or "Sem categoria").strip()
            target = "series" if kind == "episode" else kind
            cats = data[target]["cats"]
            cat_id = short_hash(target + ":" + group)
            cats.setdefault(cat_id, group)
            logo = attrs.get("tvg-logo", "")
            if kind == "live":
                data["live"]["items"].append({
                    "id": short_hash(e["url"]), "name": e["name"], "logo": logo, "cat": cat_id,
                    "num": to_int(attrs.get("tvg-chno"), 0), "epg": attrs.get("tvg-id", ""),
                    "archive": bool(attrs.get("catchup") or attrs.get("catchup-source")),
                    "archive_days": to_int(attrs.get("catchup-days") or attrs.get("timeshift"), 0),
                    "added": 0, "url": e["url"], "catchup": attrs.get("catchup", ""),
                    "catchupSource": attrs.get("catchup-source", ""),
                    "ua": (e.get("opts") or {}).get("http-user-agent", ""),
                })
            elif kind == "movie":
                data["movie"]["items"].append({
                    "id": short_hash(e["url"]), "name": e["name"], "poster": logo, "cat": cat_id,
                    "rating": 0, "added": 0, "year": year_from(e["name"]),
                    "ext": ext_of(e["url"], "mp4"), "url": e["url"],
                })
            else:
                m = _SE.match(e["name"]) or _SE2.match(e["name"])
                if m:
                    sname, season, ep, rest = m.group(1).strip(" -._"), int(m.group(2)), int(m.group(3)), m.group(4)
                else:
                    sname, season, ep, rest = e["name"], 1, 0, ""
                sname = sname or e["name"]
                sid = short_hash("series:" + group + ":" + sname.lower())
                s = series_map.get(sid)
                if s is None:
                    s = {"id": sid, "name": sname, "poster": logo, "cat": cat_id, "rating": 0,
                         "added": 0, "year": year_from(sname), "plot": "", "_eps": []}
                    series_map[sid] = s
                    data["series"]["items"].append(s)
                s["_eps"].append({
                    "id": short_hash(e["url"]), "season": season, "episode": ep,
                    "title": rest.strip(" -._") or e["name"], "ext": ext_of(e["url"], "mp4"),
                    "plot": "", "still": logo, "durationSecs": 0, "duration": "", "rating": 0,
                    "air": "", "url": e["url"],
                })
        self._series = series_map
        out = {}
        for kind, d in data.items():
            items = d["items"]
            if kind == "series":
                items = [{k: v for k, v in s.items() if k != "_eps"} for s in items]
            out[kind] = {"categories": [{"id": k, "name": v} for k, v in d["cats"].items()], "items": items}
        self._parsed = out
        return out

    def load(self, kind, cat=None):
        if self._parsed is None:
            self._build()
        return self._parsed[kind]

    def load_all(self):
        return self._build()

    def series_info(self, item_id):
        if self._parsed is None:
            self._build()
        s = self._series.get(item_id)
        if not s:
            return {"info": {}, "seasons": {}}
        seasons = {}
        for e in s["_eps"]:
            seasons.setdefault(str(e["season"]), []).append(e)
        for lst in seasons.values():
            lst.sort(key=lambda x: x["episode"])
        info = {"id": s["id"], "name": s["name"], "plot": "", "cast": "", "director": "", "genre": "",
                "release": "", "rating": 0, "trailer": "", "poster": s["poster"], "backdrop": ""}
        return {"info": info, "seasons": seasons, "seasonMeta": {}}

    def movie_info(self, item_id):
        return {}

    def stream_url(self, kind, item, fmt=None):
        url = item.get("url")
        if not url:
            raise ValueError("Item sem endereço")
        return url

    def catchup_url(self, item, start_ts, minutes):
        """Suporta os modos mais comuns de catchup de listas M3U."""
        src = item.get("catchupSource") or ""
        mode = (item.get("catchup") or "").lower()
        stop = start_ts + int(minutes) * 60
        if src:
            from datetime import datetime
            dt = datetime.fromtimestamp(start_ts)
            repl = {
                "{utc}": str(start_ts), "${start}": str(start_ts), "{start}": str(start_ts),
                "{utcend}": str(stop), "${end}": str(stop), "{end}": str(stop),
                "{lutc}": str(int(__import__("time").time())), "{duration}": str(int(minutes) * 60),
                "{Y}": dt.strftime("%Y"), "{m}": dt.strftime("%m"), "{d}": dt.strftime("%d"),
                "{H}": dt.strftime("%H"), "{M}": dt.strftime("%M"), "{S}": dt.strftime("%S"),
            }
            out = src
            for k, v in repl.items():
                out = out.replace(k, v)
            if out.startswith("?") or out.startswith("&"):
                base = item["url"]
                out = base + ("&" if "?" in base else "?") + out.lstrip("?&")
            return out
        if mode in ("append", "default", "shift", "flussonic", "fs"):
            base = item["url"]
            if mode in ("shift",):
                return base + ("&" if "?" in base else "?") + f"utc={start_ts}&lutc={int(__import__('time').time())}"
            if mode in ("flussonic", "fs"):
                root = base.rsplit("/", 1)[0]
                return f"{root}/archive-{start_ts}-{int(minutes) * 60}.m3u8"
        return None

    def epg_url(self):
        h = self._header or {}
        url = h.get("url-tvg") or h.get("x-tvg-url") or ""
        return url.split(",")[0].strip() or None
