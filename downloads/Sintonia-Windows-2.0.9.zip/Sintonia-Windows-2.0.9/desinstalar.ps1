﻿# Remove o Sintonia do Windows (mantém ou apaga os dados, conforme a escolha)
$dest = Join-Path $env:LOCALAPPDATA 'Sintonia'
$app = Join-Path $dest 'app'
$data = Join-Path $env:APPDATA 'Sintonia'
Write-Host ''
Write-Host '  Desinstalar o Sintonia' -ForegroundColor Cyan
$py = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($py -and (Test-Path $app)) { try { Push-Location $app; & $py.FullName -m sintonia --parar 2>$null | Out-Null } catch {} finally { Pop-Location } }
Start-Sleep -Seconds 1
Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Sintonia.lnk')
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue (Join-Path ([Environment]::GetFolderPath('Programs')) 'Sintonia')
$ans = Read-Host '  Apagar também favoritos, histórico e fontes salvas? (s/N)'
if ($ans -match '^[sS]') { Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $data }
Set-Location $env:TEMP
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $dest
Write-Host '  Sintonia removido. Downloads e gravações em Downloads\Sintonia foram mantidos.' -ForegroundColor Green
Start-Sleep -Seconds 4
