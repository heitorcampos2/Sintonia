﻿# Instalador do Sintonia para Windows
# Copia o programa para %LOCALAPPDATA%\Sintonia, instala o Python se faltar
# e cria os atalhos na Área de Trabalho e no Menu Iniciar.
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'Instalando o Sintonia'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'Sintonia'
$app = Join-Path $dest 'app'

function Say($t, $c = 'White') { Write-Host $t -ForegroundColor $c }

function Test-Py($exe) {
    if (-not $exe -or -not (Test-Path $exe)) { return $false }
    if ($exe -like '*WindowsApps*') { return $false }   # atalho da Microsoft Store, não é o Python de verdade
    try {
        $ok = & $exe -c "import sys; print(sys.version_info >= (3, 9))" 2>$null
        return ($ok -eq 'True')
    } catch { return $false }
}

function Find-Python {
    $cands = @()
    # o PATH deste Windows pode estar incompleto: procura também pelos caminhos padrão
    $launchers = @('py', 'python', "$env:SystemRoot\py.exe", "$env:LOCALAPPDATA\Programs\Python\Launcher\py.exe")
    foreach ($cmd in $launchers) {
        try {
            $pyArgs = if ($cmd -like '*py' -or $cmd -like '*py.exe') { @('-3', '-c', 'import sys; print(sys.executable)') } else { @('-c', 'import sys; print(sys.executable)') }
            $p = & $cmd @pyArgs 2>$null
            if ($LASTEXITCODE -eq 0 -and $p) { $cands += $p.Trim() }
        } catch {}
    }
    $cands += Get-ChildItem -Path "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe", "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending | ForEach-Object { $_.FullName }
    foreach ($c in $cands) { if (Test-Py $c) { return $c } }
    return $null
}

Say ''
Say '  Sintonia - instalação' 'Cyan'
Say '  ---------------------' 'Cyan'
Say ''

# 1) Python
$py = Find-Python
if (-not $py) {
    Say '  O Sintonia precisa do Python. Instalando o Python 3.12 (só para este usuário)...' 'Yellow'
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget -and (Test-Path "$env:LOCALAPPDATA\Microsoft\WindowsApps\winget.exe")) { $winget = "$env:LOCALAPPDATA\Microsoft\WindowsApps\winget.exe" }
    if (-not $winget) {
        Say '  Não encontrei o winget para instalar o Python automaticamente.' 'Red'
        Say '  Abrindo a página do Python: instale, marque "Add python.exe to PATH" e rode este instalador de novo.' 'Red'
        Start-Process 'https://www.python.org/downloads/windows/'
        Read-Host '  Pressione Enter para sair'
        exit 1
    }
    & $winget install --id Python.Python.3.12 -e --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Host
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $py = Find-Python
    if (-not $py) {
        Say '  O Python foi instalado, mas não consegui encontrá-lo. Feche esta janela e rode o instalador de novo.' 'Red'
        Read-Host '  Pressione Enter para sair'
        exit 1
    }
}
$pyw = Join-Path (Split-Path $py) 'pythonw.exe'
if (-not (Test-Path $pyw)) { $pyw = $py }
Say "  Python: $py" 'Gray'

# 2) Para uma versão antiga que esteja aberta
if (Test-Path (Join-Path $app 'sintonia')) {
    try { Push-Location $app; & $py -m sintonia --parar 2>$null | Out-Null } catch {} finally { Pop-Location }
    Start-Sleep -Seconds 1
}

# 3) Copia o programa
Say '  Copiando o Sintonia...'
New-Item -ItemType Directory -Force -Path $app | Out-Null
if (Test-Path (Join-Path $app 'sintonia')) { Remove-Item -Recurse -Force (Join-Path $app 'sintonia') }
Copy-Item -Recurse -Force (Join-Path $here 'sintonia') $app
Copy-Item -Force (Join-Path $here 'sintonia.ico') $dest
Copy-Item -Force (Join-Path $here 'desinstalar.ps1') $dest

# 4) Atalhos
$shell = New-Object -ComObject WScript.Shell
function New-Link($path, $target, $arguments, $icon, $desc) {
    $l = $shell.CreateShortcut($path)
    $l.TargetPath = $target
    $l.Arguments = $arguments
    $l.WorkingDirectory = $app
    $l.IconLocation = $icon
    $l.Description = $desc
    $l.Save()
}
$ico = Join-Path $dest 'sintonia.ico'
$desktop = [Environment]::GetFolderPath('Desktop')
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'Sintonia'
New-Item -ItemType Directory -Force -Path $menu | Out-Null
$run = '-m sintonia --janela --host 127.0.0.1'
New-Link (Join-Path $desktop 'Sintonia.lnk') $pyw $run $ico 'TV ao vivo, filmes e séries'
New-Link (Join-Path $menu 'Sintonia.lnk') $pyw $run $ico 'TV ao vivo, filmes e séries'
New-Link (Join-Path $menu 'Sintonia (aberto na rede).lnk') $pyw '-m sintonia --janela' $ico 'Permite abrir este Sintonia em outro aparelho da rede'
New-Link (Join-Path $menu 'Parar o Sintonia.lnk') $pyw '-m sintonia --parar' $ico 'Fecha o Sintonia que está rodando'
$psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
New-Link (Join-Path $menu 'Desinstalar o Sintonia.lnk') $psExe "-ExecutionPolicy Bypass -File `"$dest\desinstalar.ps1`"" $ico 'Remove o Sintonia'

# 5) Baixa os componentes de vídeo e abre
Say '  Abrindo o Sintonia...'
# abre pelo atalho via explorer.exe: o Sintonia roda como usuário comum mesmo se o instalador
# foi aberto como administrador (assim o atalho "Parar o Sintonia" consegue fechá-lo)
& $pyw -m sintonia --parar 2>$null | Out-Null
Start-Process -FilePath (Join-Path $env:SystemRoot 'explorer.exe') -ArgumentList "`"$(Join-Path $menu 'Sintonia.lnk')`""
Say ''
Say '  Pronto! O Sintonia abre em janela própria.' 'Green'
Say '  Ícone criado na Área de Trabalho e no Menu Iniciar.' 'Green'
Say '  Para instalar como app do Chrome: Menu > Instalar o app e usar em outros aparelhos > Instalar app.' 'Gray'
Say ''
Start-Sleep -Seconds 6
